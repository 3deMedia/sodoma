<div>
    <div class="row">
        <?php if(session('error')): ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth-session-status','data' => ['status' => session('error')]]); ?>
<?php $component->withName('auth-session-status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('error'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        <?php endif; ?>
    </div>
    <div class="row">
        <div class="col-12 mx-auto">

            <?php if($profile->is_vip): ?>
                <a href="<?php echo e(route('admin-delete-vip', $profile->id)); ?>" class="btn btn-danger">Quitar Vip</a>
            <?php else: ?>
                <button class="btn btn-primary crt-agency-vip" data-id="<?php echo e($profile->id); ?>">Crear Vip</button>
            <?php endif; ?>
            <a href="<?php echo e(route('admin-user-show', $profile->User->id)); ?>" class="btn btn-info">Ver Usuario</a>
            <?php if(($profile->type_id == 2) && ($profile->User->coins >= config('app.new_escort_cost')) ): ?>
                <a href="<?php echo e(route('admin-create-escort-for', $profile->id)); ?>" class="btn btn-success">Crear
                    escort</a><br>
                    <?php
                    $escorts_count = $profile->Escorts()->count();
                ?>
                <h3>Nº Escorts: <?php echo e($escorts_count); ?></h3>
                <?php if($escorts_count > 0): ?>
                    <p>
                        <a href="<?php echo e(route('admin-show-agency-escorts', $profile->id)); ?>" class="btn btn-secondary">Ver
                            Escorts</a>
                    </p>
                <?php endif; ?>

            </div>
            <?php endif; ?>

            <?php if($profile->verified): ?>
            <a href="<?php echo e(route('admin.verify', $profile->id)); ?>" class="btn btn-danger">Quitar Verificado</a>

            <?php else: ?>
            <a href="<?php echo e(route('admin.verify', $profile->id)); ?>" class="btn btn-success">Verificar</a>

            <?php endif; ?>
            <!-- Button trigger modal -->
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modelId">
              Cambiar slug
            </button>

            <a href="<?php echo e(route('download-profile-images',$profile->id)); ?>" class="btn btn-success"><i class="fas fa-file-archive" aria-hidden="true"></i> &nbsp; Imagenes</a>

            <!-- Modal -->
            <div class="modal fade" id="modelId" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <form action="<?php echo e(route('admin-change-slug',$profile->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                        <div class="modal-header">
                            <h5 class="modal-title">Cambiar slug</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                        </div>
                        <div class="modal-body">


                                <div class="form-group">
                                    <label for="">sLUG</label>
                                    <input type="text" name="slug" id="" class="form-control" value="<?php echo e($profile->uid); ?>"placeholder="tu-puta-preferida-69" aria-describedby="helpId">
                                    <small id="helpId" class="text-muted">Help text</small>
                                  </div>


                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\sodoma\resources\views/components/admin-top-buttons.blade.php ENDPATH**/ ?>