    <div class="container">
       <div class="l-filtros">
           <form>
               <label>Ciudad: </label>
               <select id="selector_ciudad">
                <option value="escorts-ibiza">Seleccionar</option>
                   <option value="<?php echo e(route('show-escorts','barcelona')); ?>">Barcelona</option>
                   <option value="<?php echo e(route('show-escorts','madrid')); ?>">Madrid</option>
                   <option value="<?php echo e(route('show-escorts','ibiza')); ?>">Ibiza</option>
                   <option value="<?php echo e(route('show-escorts','valencia')); ?>">Valencia</option>
                   <option value="<?php echo e(route('show-escorts','bilbao')); ?>">Bilbao</option>
               </select>
       </div>
    </div>

<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/guest/layouts/filtros.blade.php ENDPATH**/ ?>