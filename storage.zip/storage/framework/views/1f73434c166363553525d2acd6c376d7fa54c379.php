<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminLayout::class, []); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container pt-5 px-2">
        <div class="row">
            <?php if(session('success')): ?>
                <div class="col-12">
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                </div>

            <?php endif; ?>
            <div class="col-12 col-md-10 ">
                <table id="reviews_table" class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>Fecha</th>
                            <th>Imagen</th>
                            <th>Tipo de perfil</th>
                            <th>Ver perfil</th>
                            <th>Aprobar Foto</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $revs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td scope="row"><?php echo e($rev->created_at->format('d-m-Y')); ?></td>
                                <td scope="row">

                                    <?php
                                     $photo= $rev->Photo;
                                     $profile_type=$rev->profile_type;
                                    ?>

                                    <img src="<?php echo e(asset("storage/escort_photos/$photo->path/$photo->filename")); ?>" alt="" height="100" >
                                </td>
                                <td><?php echo e($profile_type===1 ? 'Escort': 'Agencia'); ?></td>
                                 <td>
                                     <?php if($profile_type===1): ?>
                                         <a href="<?php echo e(route('admin-escort-show',$rev->profile_id)); ?>"><?php echo e($rev->Profile->email); ?></a>
                                     <?php else: ?>
                                     <a href="<?php echo e(route('admin-agency-show',$rev->profile_id)); ?>"><?php echo e($rev->Profile->email); ?></a>
                                     <?php endif; ?>
                                    </td>

                                <td><a class="btn btn-success" href="<?php echo e(route('approve-escort-photo',$rev->id)); ?>">
                                    <i class="fa fa-check-circle" aria-hidden="true"></i></a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </tbody>

                </table>


            </div>
        </div>
    </div>

 <?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/admin/reviews/fotos.blade.php ENDPATH**/ ?>