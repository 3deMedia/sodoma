<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GuestLayout::class, []); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startPush('meta'); ?>
        <meta name="description" content="<?php echo e($seo->seo_description); ?>" />
        <meta name="keywords" content="<?php echo e($seo->seo_keywords); ?>" />
        <title><?php echo e(config('app.name')); ?> | <?php echo e($seo->seo_title); ?></title>
    <?php $__env->stopPush(); ?>
    <div class="container py-4">
        <div class="row">
            <div class="col-12 ">
                <div id="" class="faq">
                    <?php
                        $faqs = \App\Models\Faqs::all();
                    ?>
                    <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item">
                            <div class="question pointer">
                                <?php echo e($item->question); ?> <span class="float-right mcolor"><i
                                        class="fas fa-caret-down"></i></span>
                            </div>
                            <div class="answer">
                                <?php echo $item->answer; ?>

                            </div>
                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
    </div>
    <?php $__env->startPush('js'); ?>
        <script>
            $(".question").click(function() {


                return $(this).next().slideToggle();

            });
        </script>

    <?php $__env->stopPush(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/legal/faqs.blade.php ENDPATH**/ ?>