<div>
    name: <?php echo e($data->name); ?> <br><br>
    email: <?php echo e($data->email); ?><br><br>
    message: <?php echo e($data->message); ?>

</div>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/mails/contact.blade.php ENDPATH**/ ?>