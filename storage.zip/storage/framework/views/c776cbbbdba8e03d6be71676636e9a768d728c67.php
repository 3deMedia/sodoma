<div>
    <form action="<?php echo e(route('admin-update-texts',$ctext->id)); ?>" method="post" style="    display: flex;
        align-items: center;
        justify-content: space-around;">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
    <input name="name" type="text" value="<?php echo e($ctext->name); ?>" class="form-control  mx-2">
    <textarea name="description_1" class="form-control mx-2" >
        <?php echo $ctext->description_1; ?>

    </textarea>
    <textarea name="description_2" class="form-control  mx-2">
        <?php echo $ctext->description_2; ?>

    </textarea>
    <button type="submit" class="btn btn-primary  mx-2">Guardar</button>
    </form>
</div>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/components/category-text.blade.php ENDPATH**/ ?>