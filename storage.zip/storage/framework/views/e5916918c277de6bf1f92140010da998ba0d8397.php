<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminLayout::class, []); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <div class="container pt-5 px-2">
        <div class="row">
            <div>
                <?php if($profile->is_vip): ?>
                    <a href="<?php echo e(route('admin-delete-agency-vip', $profile->id)); ?>"
                        class="btn btn-danger">Quitar Vip</a>
                <?php else: ?>
                <button class="btn btn-primary crt-agency-vip" data-id="<?php echo e($profile->id); ?>">Crear Vip</button>
                <?php endif; ?>
                <a href="<?php echo e(route('admin-user-show', $profile->User->id)); ?>"
                    class="btn btn-info">Ver Usuario</a>
                <a href="<?php echo e(route('admin-create-escort-for',$profile->id)); ?>" class="btn btn-success">Crear escort</a>
            </div>
        </div>
        <div class="row">
            <div class="col-12 col-md-10 col-xl-8 pt-3">
                <?php
                    $escorts_count= $profile->Escorts()->count();
                ?>
                <h3>Nº Escorts: <?php echo e($escorts_count); ?></h3>
                <?php if($escorts_count>0): ?>
                <p>
                    <a href="<?php echo e(route('admin-show-agency-escorts',$profile->id)); ?>" class="btn btn-secondary">Ver Escorts</a>
                </p>
                <?php endif; ?>

            </div>
            <div class="col-12 col-md-10 col-xl-8">
                <?php if(!$profile->approved): ?>

                    <a href="<?php echo e(route('approve-profile', $profile->id) . '?type=2'); ?>" class="btn btn-block btn-info">
                        <?php echo e(__('Aprovar ')); ?></a>
                <?php endif; ?>



                <form action="<?php echo e(route('admin-agency-update', $profile->id)); ?>" method="post"
                    enctype="multipart/form-data" id="agency-form" class="pt-3 mx-auto ">

                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <!-- LBasic-->
                    <div class="container">
                        <div class="row">
                            <div class="col-12">
                                <h3 class="fs-3 fw-bold text-mgray border-bottom border-mcolor w-100">
                                    <?php echo e(__('forms.profile.Basic')); ?></h3>
                            </div>

                            <div class="d-flex">
                                <label for="active" class="p-2 m-2">Aprovado
                                    <select name="approved" id="" class="form-control">
                                        <option value="1" <?php if($profile->approved): ?> selected <?php endif; ?>>Si</option>
                                        <option value="0" <?php if(!$profile->approved): ?> selected <?php endif; ?>>No</option>
                                    </select>
                                </label>

                            </div>

                            <div class="col-12 ">
                                <div class="d-flex flex-wrap flex-md-nowrap">

                                    <label for="" class="p-2 d-flex flex-column w-100 ">
                                        <span class="form-label"><?php echo e(__('forms.profile.Name')); ?></span>
                                        <input type="text" class="w-100 form-control" name="name"
                                            value="<?php echo e($profile->name); ?>" />
                                    </label>
                                    <label for="" class="p-2 d-flex flex-column w-100">
                                        <span class="form-label"><?php echo e(__('forms.profile.Email')); ?></span>
                                        <input type="text" name="email" class="form-control"
                                            value="<?php echo e($profile->email); ?>" />
                                    </label>
                                </div>
                                <div class="d-flex flex-wrap flex-md-nowrap">
                                    <label for="" class="p-2 d-flex flex-column w-100">
                                        <span class="form-label"><?php echo e(__('forms.profile.Phone')); ?></span>
                                        <input type="text" name="phone" class="form-control"
                                            value="<?php echo e($profile->phone); ?>" />
                                    </label>
                                    <label for="" class="p-2 d-flex flex-column w-100">
                                        <span class="form-label"><?php echo e(__('forms.profile.web')); ?></span>
                                        <input type="text" name="website" class="form-control"
                                            value="<?php echo e($profile->website); ?>" />
                                    </label>
                                </div>
                            </div>


                    <div class="col-12 col-md-6">
                                <?php
                                $photo=$profile->Photo()
                                 ?>
                                <?php if($photo): ?>

                                    <label for="agency_photo">
                                        <img loading="lazy" id="previewer" class="w-100 py-4" height="300" width="200"
                                            src=<?php echo e(asset("storage/agency_photos/$photo->path/$photo->filename")); ?> />
                                    </label>
                                    <input type="file" name="agency_photo" id="agency_main_photo" onchange="readURL(this);"
                                        class=" w-100">
                                <?php else: ?>

                                    <label for="agency_photo" class="w-100">
                                        <img loading="lazy" id="previewer" class="w-100 py-4" height="300" width="200"
                                            src="https://via.placeholder.com/300x150" />
                                        <input type="file" name="agency_photo" id="agency_main_photo"
                                            onchange="readURL(this);" class=" w-100">
                                    </label>

                                <?php endif; ?>



                            </div>
                            <div class="col-12 col-md-6">

                                <label for="" class="form-label w-100">
                                    <p class="mx-2"><?php echo e(__('forms.profile.Description')); ?></p>
                                    <textarea name="description" id=""
                                        class="w-100 rounded  form-control"><?php echo e($profile->description ? $profile->description : old('description')); ?></textarea>
                                </label>

                            </div>

                            <div class="col-12">
                                <!--Direccion -->
                                <h3 class="fs-3 fw-bold text-mgray border-bottom border-mcolor w-100">
                                    <?php echo e(__('forms.profile.Address')); ?></h3>
                            </div>

                            <div class="col-12 col-md-6">
                                <label for="" class="w-100 w-md-25 d-flex flex-column px-2">
                                    <span class="form-label"><?php echo e(__('forms.profile.Country')); ?></span>
                                    <select class="js-example-basic-single w-100 " name="country_id"
                                        id="a-country-select">
                                        <?php $countries= DB::table('countries')->get() ?>
                                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($country->id); ?>"
                                                <?php echo e(($profile->country_id ? $profile->country_id : old('country_id')) == $country->id ? 'selected' : ''); ?>>
                                                <?php echo e(__("geodata.countries.$country->name")); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </label>
                                <label for="" class="w-100 w-md-25 d-flex flex-column px-2">
                                    <span class="form-label"><?php echo e(__('forms.profile.Region')); ?></span>
                                    <select class="js-example-basic-single w-100" name="region_id" id="a-region-select">

                                        <?php if(isset($profile->region_id)): ?>
                                            <option value="<?php echo e($profile->region_id); ?>" selected>
                                                <?php echo e(DB::table('regions')->where('id', $profile->region_id)->first()->name); ?>

                                            </option>
                                        <?php endif; ?>
                                    </select>
                                </label>
                            </div>
                            <div class="col-12 col-md-6">
                                <label for="" class="w-100 d-flex flex-column px-2">
                                    <span class="form-label"><?php echo e(__('forms.profile.City')); ?></span>
                                    <select class="js-example-basic-single w-100" name="city_id" id="a-cities-select">
                                        <?php if(isset($profile->city_id)): ?>
                                            <option value="<?php echo e($profile->city_id); ?>" selected>
                                                <?php echo e(DB::table('cities')->where('id', $profile->city_id)->first()->name); ?>

                                            </option>
                                        <?php endif; ?>
                                    </select>
                                </label>
                                <div class="w-100 p-2 my-2">
                                    <label for="" class="w-100">
                                        <span><?php echo e(__('forms.profile.Address')); ?> <span
                                                class="text-red-400">*</span></span>
                                        <input type="text" name="address" class="w-100"
                                            value="<?php echo e($profile ? $profile->address : old('address')); ?>" />
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-12">

                                <div class="p-2 text-center py-4 w-100 md:w-96 mx-auto">
                                    <input type="submit" value="<?php echo e(__('Modificar')); ?>"
                                        class="rounded btn-block bg-pink text-white btn mx-auto btn-submit">
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

 <?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/admin/agencies/show.blade.php ENDPATH**/ ?>