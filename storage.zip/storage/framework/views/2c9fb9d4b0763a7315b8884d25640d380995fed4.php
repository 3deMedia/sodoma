<div class="l-topbanner">
    <div class="container">
        <div class="d-flex flex-auto" >
        <?php
            $agencies_left=App\Models\Profile::where('is_vip',0)->where('type_id',2)->get()->random(3);
            $n = '0';
        ?>
              <?php $__currentLoopData = $agencies_left; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_left): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php
                  $n = $n+1;
              ?>
              <div class="topban-<?php echo e($n); ?>" style="margin:0 auto;">
              <a href="<?php echo e(route('show-an-agency',$item_left->uid)); ?>">
              <img src="<?php echo e(asset('storage')); ?>/agency_photos/<?php echo e($item_left->MainPhoto()->path); ?>/<?php echo e($item_left->MainPhoto()->filename); ?>" alt="" />
              </a></div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/guest/layouts/bannerstop.blade.php ENDPATH**/ ?>