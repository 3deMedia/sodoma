<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <div style="min-height:75vh;">

        <div class="container-fluid">
            <div class="row">
                <div class="col-12 mx-auto">
                    <div class="container">
                        <div class="row">
                            <div class="col-12 mx-auto">

                                <h3 class="fs-3 fw-bold text-mgray text-center pt-4">
                                    <?php echo e(__('general.Vip_gifts_title')); ?></h3>
                                <?php if($profile->is_vip ): ?>
                                    <p class="text-sm mcolor">
                                        <span class="text-muted"><?php echo __('general.vip.ends_at_message'); ?> </span>
                                        <strong class="fw-bold"> <?php echo e($profile->Vip()->ends_at->format('d-m-Y')); ?>

                                        </strong>
                                    </p>
                                <?php endif; ?>
                            </div>
                            <div class="p-2 col-12 col-lg-4">
                                <div class="card card-stats shadow">

                                    <!-- Card body -->
                                    <div class="card-body">

                                        <div class="row">
                                            <div class="col">
                                                <h5 class="card-title text-uppercase text-muted mb-0 text-sm">VISITAS
                                                </h5>
                                                <span class="h4 font-weight-bold mb-0">x500</span>
                                            </div>
                                            <div class="col-auto">
                                                <div class="icon icon-shape bg-pink text-white rounded-circle shadow">
                                                    <i class="ni ni-glasses-2"></i>
                                                </div>
                                            </div>
                                        </div>


                                    </div>
                                </div>

                            </div>
                            <div class="p-2 col-12 col-lg-4">
                                <div class="card card-stats shadow">
                                    <!-- Card body -->
                                    <div class="card-body">

                                        <div class="row">
                                            <div class="col">
                                                <h5 class="card-title text-uppercase text-muted mb-0 text-sm">Contacts
                                                </h5>
                                                <span class="h4 font-weight-bold mb-0">x100</span>
                                            </div>
                                            <div class="col-auto">
                                                <div
                                                    class="icon icon-shape bg-default text-white rounded-circle shadow">
                                                    <i class="ni ni-email-83"></i>
                                                </div>
                                            </div>
                                        </div>


                                    </div>
                                </div>
                            </div>
                            <div class="p-2 col-12 col-lg-4">
                                <div class="card card-stats shadow">
                                    <!-- Card body -->
                                    <div class="card-body">

                                        <div class="row">
                                            <div class="col">
                                                <h5 class="card-title text-uppercase text-muted mb-0 text-sm">Popular
                                                </h5>
                                                <span class="h4 font-weight-bold mb-0">X20</span>
                                            </div>
                                            <div class="col-auto">
                                                <div class="icon icon-shape bg-green text-white rounded-circle shadow">
                                                    <i class="ni ni-sound-wave"></i>
                                                </div>
                                            </div>
                                        </div>


                                    </div>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="row py-4">
                                    <div class="col-12 col-lg-3 mx-auto">

                                        <img loading="lazy" src="<?php echo e(asset('images/vip-image.png')); ?>"
                                            class="w-100">

                                    </div>
                                    <div class="col-12 col-lg-9 mx-auto align-self-center">
                                        <div class="p-2">
                                            <?php echo __('general.Vip_gifts_text'); ?>

                                        </div>
                                        <div class="py-4 w-100">
                                            <table class="table table-striped text-center">
                                                <thead class="thead-dark">
                                                    <tr>
                                                        <th><span class="mcolor fw-bold">Perfil</span></th>
                                                        <th><span class="mcolor fw-bold">Coste</span></th>

                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>Escort</td>
                                                        <td scope="row">200 coins / mes </td>

                                                    </tr>
                                                    <tr>
                                                        <td>Agencia</td>
                                                        <td scope="row">100 coins / mes</td>


                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        <?php if(!$profile->is_vip && !$has_enough_coins): ?>
                                            <div class="py-4 w-100">
                                                <p>Quieres probar el sistema de suscripción VIP ? <a
                                                        href="<?php echo e(route('buy-coins')); ?>" class="fw-bold mcolor">Compra
                                                        SecreCoins</a></p>
                                            </div>
                                        <?php endif; ?>
                                    </div>

                                </div>
                            </div>

                            <div class="col-12 col-md-6 mx-auto pb-5">

                                <?php if($profile->approved && !$profile->is_vip && $has_enough_coins): ?>

                                        <button class="w-100 btn bg-rosa btn-submit agency-make-vip" style="" data-render="<?php echo e($profile->id); ?>">

                                            <span
                                                class="fs-3 fs-md-4 fw-bold text-white text-center"><?php echo e(__('general.Become_vip')); ?></span>
                                        </button>

                                <?php elseif(!$profile->approved && !$profile->is_vip): ?>
                                    <div class="col-12 mx-auto text-center py-2 border border-mcolor">
                                        <span class="w-100 text-mgray fs-3 m-0">
                                            <?php echo e(__('general.need_profile')); ?></span>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>



            </div>
        </div>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/user/become-vip.blade.php ENDPATH**/ ?>