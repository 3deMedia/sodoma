<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GuestLayout::class, []); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php echo $__env->make('guest.layouts.filtros', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="pt-4 pt-md-4 container" style="min-height:75vh;">
        <div class="row bg-white">
            <div class="w-100">

                <div id="map" style="min-height:70vh;width:100%"></div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('js'); ?>
        <script>
            let center = <?php echo json_encode($center); ?>;
            let geodata = <?php echo json_encode($geo_escorts); ?>

        </script>
        <script src="<?php echo e(mix('js/maps.js')); ?>"></script>

        <script src="https://maps.googleapis.com/maps/api/js?key=<?php echo e(env('MAPS_GOOGLE_MAPS_ACCESS_TOKEN2')); ?>"></script>
    <?php $__env->stopPush(); ?>



    <!-- Async script executes immediately and must be after any DOM elements used in callback. -->

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\sodoma\resources\views/guest/map.blade.php ENDPATH**/ ?>