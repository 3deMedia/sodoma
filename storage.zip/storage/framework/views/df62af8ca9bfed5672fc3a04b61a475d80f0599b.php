<div>
    <div class="row">
        <div class="col-12 col-md-10 mx-auto">

            <?php if($admin): ?>
                <form action="<?php echo e(route('admin-profile-update', $profile->id)); ?>" method="post"
                    enctype="multipart/form-data" id="agency-form" class="pt-3 mx-auto ">
            <?php else: ?>

                <form action="<?php echo e(route('profile.update', $profile->id)); ?>" method="post"
                    enctype="multipart/form-data" id="agency-form" class="pt-3 mx-auto ">
            <?php endif; ?>

                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <!-- LBasic-->
                <div>
                    <div class="row">
                        <div class="col-12 pb-5">
                            <h3 class="fs-3 fw-bold text-333 border-bottom border-mcolor w-100">
                                <?php echo e(__('forms.profile.Basic')); ?></h3>
                        </div>

                        <div class="col-12 ">
                            <div class="d-flex flex-wrap flex-md-nowrap">

                                <label for="" class="p-2 d-flex flex-column w-100 ">
                                    <span class="form-label"><?php echo e(__('forms.profile.Name')); ?></span>
                                    <input required name="name" type="text" class="w-100 form-control"
                                        value="<?php echo e(old('name') ?? $profile->name); ?>" />
                                </label>
                                <label for="" class="p-2 d-flex flex-column w-100">
                                    <span class="form-label"><?php echo e(__('forms.profile.Email')); ?></span>
                                    <input required type="text" name="email" class="form-control"
                                        value="<?php echo e(old('email') ?? $profile->email); ?>" />
                                </label>
                            </div>
                            <div class="d-flex flex-wrap flex-md-nowrap">
                                <label for="" class="p-2 d-flex flex-column w-100">
                                    <span class="form-label"><?php echo e(__('forms.profile.Phone')); ?></span>
                                    <input required type="text" name="phone" class="form-control"
                                        value="<?php echo e(old('phone') ?? $profile->phone); ?>" />
                                </label>
                                <label for="" class="p-2 d-flex flex-column w-100">
                                    <span class="form-label"><?php echo e(__('forms.profile.web')); ?></span>
                                    <input type="text" name="web" class="form-control"
                                        value="<?php echo e(old('web') ?? $profile->web); ?>" />
                                </label>
                            </div>
                        </div>

                    </div>

                    <div class="row ">
                        <div class="col-12">

                            <label for="" class="form-label w-100">
                                <p class="mx-2"><?php echo e(__('forms.profile.Description')); ?></p>
                                <textarea required required name="description" id=""
                                    class="w-100 rounded  form-control"><?php echo e(old('description') ?? $profile->description); ?></textarea>
                            </label>

                        </div>
                        <div class="col-12 py-4 pb-5">
                            <h3 class="fs-3 fw-bold text-333 border-bottom border-mcolor w-100">
                                <?php echo e(__('forms.profile.Gallery')); ?>

                                <?php if(!$admin): ?>  <span class="mcolor text-sm">
                                    <i class="fas fa-question-circle"></i> &nbsp; Si cambias la imagen, tu perfil quedará desactivado hasta nueva revisión.Esto no afectará a tus Escorts</span>

                                <?php endif; ?>
                            </h3>

                            <?php
                                $photo = $profile->MainPhoto();
                            ?>

                                <img src="<?php echo e(asset("/storage/agency_photos/$photo->path/$photo->filename")); ?>"
                                     width="300">
                                <hr>

                                <script>
                                    const main_source = "<?php echo e(url("/storage/agency_photos/$photo->path/$photo->filename")); ?>"
                                </script>

                            <input type="file" name="photo" id="agency_photo" class=" w-100">


                        </div>

                    </div>
                    <div class="row">
                        <div class="col-12 pb-5">
                            <!--Direccion -->
                            <h3 class="fs-3 fw-bold text-333 border-bottom border-mcolor w-100">
                                <?php echo e(__('forms.profile.Address')); ?></h3>
                        </div>

                        <div class="col-12 ">
                            <div class="d-flex flex-wrap flex-md-nowrap">
                                <label for="" class="w-100 w-md-25 d-flex flex-column px-2">
                                    <span class="form-label"><?php echo e(__('forms.profile.Country')); ?></span>
                                    <select required class="js-example-basic-single w-100 " name="country_id"
                                        id="a-country-select">
                                        <?php $countries= DB::table('countries')->get() ?>
                                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($country->id); ?>"
                                                <?php echo e((old('country_id') ?? $profile->Address->country_id) == $country->id ? 'selected' : ''); ?>>
                                                <?php echo e(__("geodata.countries.$country->name")); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </label>
                                <label for="" class="w-100 w-md-25 d-flex flex-column px-2">
                                    <span class="form-label"><?php echo e(__('forms.profile.Region')); ?></span>
                                    <select required class="js-example-basic-single w-100" name="region_id"
                                        id="a-region-select">
                                            <option value="<?php echo e($profile->Address->region_id); ?>" selected>
                                                <?php echo e(DB::table('regions')->where('id', $profile->Address->region_id)->first()->name); ?>

                                            </option>
                                    </select>
                                </label>

                                <label for="" class="w-100 d-flex flex-column px-2">
                                    <span class="form-label"><?php echo e(__('forms.profile.City')); ?></span>
                                    <select required class="js-example-basic-single w-100" name="city_id"
                                        id="a-cities-select">
                                            <option value="<?php echo e($profile->Address->city_id); ?>" selected>
                                                <?php echo e(DB::table('cities')->where('id', $profile->Address->city_id)->first()->name); ?>

                                            </option>
                                    </select>
                                </label>
                            </div>

                        </div>
                        <div class="col-12 ">
                            <div class="w-100 p-2 my-2">
                                <label for="" class="w-100">
                                    <span><?php echo e(__('forms.profile.Address')); ?> <span
                                            class="text-red-400">*</span></span>
                                    <input required type="text" name="address" class="w-100"
                                        value="<?php echo e(old('address') ?? $profile->Address->address); ?>" />
                                </label>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12 my-4">

                            <div class="p-2 text-center py-4 w-100 d-flex">
                                <input type="submit" name="save"
                                    class="btn rounded w-100 bg-rosa text-white px-4 py-2 mx-auto btn-submit"
                                    value="<?php echo e(__('general.Save')); ?>">
                            </div>
                        </div>
                    </div>

                </div>
        </div>
        <!-- LBasic-->

        </form>
    </div>

</div>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/components/forms/update-agency.blade.php ENDPATH**/ ?>