<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GuestLayout::class, []); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startPush('meta'); ?>
        <meta name="description" content="<?php echo e($seo->seo_description); ?>" />
        <meta name="keywords" content="<?php echo e($seo->seo_keywords); ?>" />
        <title><?php echo e(config('app.name')); ?> | <?php echo e($seo->seo_title); ?></title>
    <?php $__env->stopPush(); ?>
    <div class="container">
        <div class="row">
            <div class="col-12 text-center mt-6">
                <h1 class="text-center mcolor display-3">Agencias</h1>
            </div>
            <?php $__currentLoopData = $agencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $photo= $agen->MainPhoto();
            ?>
            <div class="col-12 col-sm-6 col-lg-4 my-2">
                <div class="bg-white shadow-lg p-2 rounded text-center">
                    
                        <a href="<?php echo e(route('show-an-agency',$agen->uid)); ?>">
                        <div><img src='<?php echo e(asset("storage/agency_photos/$photo->path/$photo->filename")); ?>' height="100" alt="<?php echo e($agen->name); ?>"></div></a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>

<?php /**PATH C:\laragon\www\sodoma\resources\views/guest/agencies.blade.php ENDPATH**/ ?>