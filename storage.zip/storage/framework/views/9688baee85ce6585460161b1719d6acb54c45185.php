<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminLayout::class, []); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php
    $u_type=$user->user_type_id ;
    ?>

    <div class="container pt-2 pt-md-5">
        <div class="row">
            <div class="col-12 col-md-10 col-lg-6 mx-auto">
                <form action="<?php echo e(route('admin-user-update',$user->id)); ?>" method="post" class="p-2 border border-2">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="p-2">
                    <div class="form-group">
                        <label for="email">Correo</label><br>
                        <input type="email" name="email" id="name" class="form-control"  value="<?php echo e($user->email); ?>">
                    </div>
                    <div class="form-group">
                      <label for="">Coins</label>
                      <input type="text"
                          class="form-control form-control-sm" name="coins" id="" aria-describedby="helpId" value="<?php echo e($user->coins); ?>">

                    </div>
                    <div class="form-group">
                        <label for="">Contraseña</label>
                        <input type="text"
                            class="form-control form-control-sm" name="contrasena" >

                      </div>
                    <div class="form-group">
                        <label for="">tipo</label>
                      <p><?php echo e($u_type == 1 ? 'escort':'agency'); ?></p>
                      </div>
                </div>
                <button type="submit" class="btn btn-primary">Actualizar</button>

                </form>
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/admin/users/show.blade.php ENDPATH**/ ?>