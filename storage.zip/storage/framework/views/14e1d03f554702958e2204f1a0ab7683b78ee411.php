<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <div style="min-height:75vh;">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 mx-auto">
                    <div class="container">
                        <div class="row">
                            <div class="col-12 mx-auto">

                                <h3 class="fs-3 fw-bold text-mgray text-center pt-4">
                                    <?php echo e(__('general.Vip_gifts_title')); ?></h3>

                                <?php if($profile && $profile->is_vip ): ?>
                                    <p class="text-sm mcolor text-center">
                                        <span class="text-muted"><?php echo __('general.vip.ends_at_message'); ?> </span>
                                        <strong class="fw-bold"> <?php echo e($profile->Vip()->ends_at->format('d-m-Y')); ?>

                                        </strong>
                                    </p>
                                <?php endif; ?>
                            </div>
                            <div class="col-12">
                                <div class="row py-6">
                                            <div class="col-lg-4">

                                              <div class="card card-pricing bg-verd text-center mb-4 border-0" >
                                            <div class="card-header bg-white">
                                              <h6 class="text-uppercase ls-1 text-pink py-3 mb-0"><?php echo e(__('general.Profile_Vip')); ?></h6>
                                            </div>
                                            <div class="card-body">
                                              <div class="display-2 text-white"><?php echo e($vip_cost); ?> €</div>
                                              <span class="text-white"><?php echo e(__('general.monthly')); ?></span>
                                              <ul class="list-unstyled my-4">
                                                <li class="py-2">
                                                    <div class="d-flex align-items-center">
                                                      <div>
                                                        <div class="icon icon-xs icon-shape bg-white shadow rounded-circle text-vip">
                                                          <i class="ni ni-trophy"></i>
                                                        </div>
                                                      </div>
                                                      <div>
                                                        <span class="pl-2 text-sm text-white"><?php echo e(__('general.feature1')); ?></span></div>
                                                    </div>
                                                  </li>
                                                <li class="py-2">
                                                  <div class="d-flex align-items-center">
                                                    <div>
                                                      <div class="icon icon-xs icon-shape bg-white shadow rounded-circle text-vip">
                                                        <i class="ni ni-camera-compact"></i>
                                                      </div>
                                                    </div>
                                                    <div>
                                                      <span class="pl-2 text-sm text-white"><?php echo e(__('general.feature2')); ?></span></div>
                                                  </div>
                                                </li>
                                                <li class="py-2">
                                                  <div class="d-flex align-items-center">
                                                    <div>
                                                      <div class="icon icon-xs icon-shape bg-white shadow rounded-circle text-vip">
                                                        <i class="ni ni-world-2"></i>
                                                      </div>
                                                    </div>
                                                    <div>                                                     <span class="pl-2 text-sm text-white"><?php echo e(__('general.feature3')); ?></span>
                                                    </div>
                                                  </div>
                                                </li>
                                                <li class="py-2">
                                                  <div class="d-flex align-items-center">
                                                    <div>
                                                      <div class="icon icon-xs icon-shape bg-white shadow rounded-circle text-vip">
                                                        <i class="ni ni-map-big"></i>
                                                      </div>
                                                    </div>
                                                    <div>
                                                      <span class="pl-2 text-sm text-white"><?php echo e(__('general.feature4')); ?></span>
                                                    </div>
                                                  </div>
                                                </li>
                                              </ul>
                                              <div class="mx-auto pb-5 pt-3">

                                                <?php if($profile && $profile->approved && !$profile->is_vip && $has_enough_coins): ?>
                                                        <p class="text-white"><?php echo e(__('general.updateper')); ?></p>
                                                        <button class="btn btn-coins btn-sm" style="" data-render="<?php echo e($profile->id); ?>">
                                                            <span  class="fw-bold text-white text-center"><?php echo e(__('general.Become_vip')); ?></span>
                                                        </button>

                                                <?php else: ?>
                                                   <div class="text-center">
                                                        <span class="text-white fs-6">
                                                            <?php echo e(__('general.need_coins2')); ?> <br/> & <br/> <?php echo e(__('general.need_coins')); ?> </span>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                            </div>
                                            <div class="card-footer bg-transparent">
                                              <a href="<?php echo e(route('buy-coins')); ?>" class="btn saldolink border-white"> <?php echo e(__('general.Buy_coins_title')); ?></a>
                                            </div>
                                          </div>
                                    </div>
                                    <div class="col-12 col-lg-8 mx-auto align-self-center">
                                        <div class="p-2">
                                            <?php echo __('general.Vip_gifts_text'); ?>

                                        </div>
                                        <div class="py-4 w-100">
                                            <table class="table table-striped text-center">
                                                <thead class="thead-dark">
                                                    <tr>
                                                        <th><span class="text-white fw-bold"><?php echo e(__('general.profile')); ?></span></th>
                                                        <th><span class="text-white fw-bold"><?php echo e(__('general.price')); ?></span></th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        
                                                        <td> <?php if(auth()->user()->user_type_id == 1): ?> <?php echo e(__('general.independent_escort')); ?> <?php else: ?> <?php echo e(__('general.Agency')); ?> <?php endif; ?></td>
                                                        <td scope="row"><?php echo e($vip_cost); ?> / <?php echo e(__('general.month')); ?></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        <?php if($profile && !$profile->is_vip && !$has_enough_coins): ?>
                                            <div class="py-4 w-100">
                                                <p><?php echo e(__('general.test_vip')); ?><a href="<?php echo e(route('buy-coins')); ?>" class="fw-bold mcolor"> <?php echo e(__('general.Buy_coins_title')); ?></a></p>
                                            </div>
                                        <?php endif; ?>
                                        <?php if($profile &&  $profile->approved && !$profile->is_vip && $has_enough_coins): ?>
                                            <button class="w-100 btn bg-verd btn-submit user-wants-vip" style="" data-render="<?php echo e($profile->id); ?>">
                                            <span  class="fw-bold text-white text-center"><?php echo e(__('general.Become_vip')); ?></span>
                                            </button>
                                        <?php elseif($profile &&  !$profile->approved && !$profile->is_vip): ?>
                                             <div class="col-12 mx-auto text-center py-2 border border-mcolor">
                                                 <span class="w-100 text-mgray fs-3 m-0"><?php echo e(__('general.need_profile')); ?></span>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\sodoma\resources\views/user/become-vip.blade.php ENDPATH**/ ?>