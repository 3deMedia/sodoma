<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GuestLayout::class, []); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startPush('meta'); ?>
    <meta name="description" content="<?php echo e($seo->seo_description); ?>" />
    <meta name="keywords" content="<?php echo e($seo->seo_keywords); ?>" />
    <title><?php echo e(config('app.name')); ?> | <?php echo e($seo->seo_title); ?></title>
<?php $__env->stopPush(); ?>
    <div class="container pt-5 pt-md-2">
        <div class="row">
            <div class="col-12 text-white fw-bold">
                <div class="row">
                    <div class="col-12 col-md-6">
                        <?php
                        $photo=$profile->MainPhoto()
                         ?>
                          <img loading="lazy" id="previewer" class="w-100 py-4" height="300" width="200"
                          src=<?php echo e(asset("storage/agency_photos/$photo->path/$photo->filename")); ?> />

                    </div>
                    <div class="col-12 col-md-6">
                        <p><?php echo e($profile->name); ?></p>
                        <p><?php echo e($profile->phone); ?></p>
                        <p><?php echo e($profile->web); ?></p>
                        <p><?php echo e($profile->description); ?></p>
                    </div>
                </div>

                <?php if($profile->Escorts()->count()>0): ?>
                <div class="row">

                    <h4 class=" mcolor display-4 w-100 border-bottom pt-4 mb-2">Escorts</h4>
                    <div class="col-12 d-flex flex-wrap">
                        <?php $__currentLoopData = $profile->Escorts(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scrt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($scrt->approved && $scrt->active): ?>
                        <div class="shadow-lg p-2 rounded text-center profile-view">
                            <div class="bg-white">
                                <a href="<?php echo e(route('show-escorts', $scrt->Address->Region->slug,$scrt->uid)); ?>" class="w-100 ">
                                    <div style="width: 100%; position: relative;" <?php if($scrt->is_vip): ?> class="corner" <?php endif; ?>>
                                        <?php
                                            $image=$scrt->Mainphoto()->filename;
                                            $path= $scrt->Mainphoto()->path;
                                        ?>
                                        <img loading="lazy" src='<?php echo e(asset("storage/escort_photos/$path/$image")); ?>'>
                                        <div class="custom-layer" style="display: none">
                                            <div class="description">
                                                <ul>
                                                    <li>Age :<span class="text-white">
                                                            <?php echo e($scrt->Features->age); ?></span> </li>
                                                    <li>Height :<span class="text-white">
                                                            <?php echo e($scrt->Features->height); ?> cm</span> </li>

                                                    <li>Eyes color :<span class="text-white">
                                                            <?php echo e($scrt->Features->Eyes()); ?></span> </li>

                                                    <li>Hair :<span class="text-white">
                                                            <?php echo e($scrt->Features->Hair()); ?></span> </li>

                                                    <li>Etnia :<span class="text-white">
                                                            <?php echo e($scrt->Features->Ethnic()); ?></span> </li>

                                                    <li>Weight :<span class="text-white">
                                                            <?php echo e($scrt->Features->weight); ?> kg</span> </li>

                                                    <li>Breast Size :<span class="text-white">
                                                            <?php echo e($scrt->Features->breast_size); ?></span> </li>

                                                    <li>Breast Type :<span class="text-white">
                                                            <?php echo e($scrt->Features->breast_type ? 'Silicona' : 'Natural'); ?></span> </li>




                                                </ul>
                                            </div>
                                        </div>
                                    </div>

                                </a>

                                <p class="profile-name"><?php echo e($scrt->name); ?> </p>

                            </div>
                        </div>
                        <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php else: ?>
                    no tiene escorts
                <?php endif; ?>

            </div>
        </div>
    </div>
    <?php $__env->startPush('js'); ?>
    <script defer>
        $('.profile-view').hover(function() {

            let elem = $(this).find('.custom-layer');

            elem.slideToggle('normal')
        }, function() {
            let elem = $(this).find('.custom-layer');

            elem.slideToggle('normal')
        })
    </script>

<?php $__env->stopPush(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/guest/agency-show.blade.php ENDPATH**/ ?>