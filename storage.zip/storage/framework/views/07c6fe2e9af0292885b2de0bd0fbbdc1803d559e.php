<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminLayout::class, []); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <div class="container pt-5">
        <div class="row">
            <div class="col-8 mx-auto">
                <h1 class="tracking-widest font-bold text-base md:text-3xl border-b-4 border-blue-700 ">
                    <?php echo app('translator')->get('general.Last_Posts'); ?>

                </h1>
                <div class="float-right">
                    <a href="<?php echo e(route('posts.create')); ?>" class="btn btn-info"
                        style="position: relative;bottom:5px;">Crear Post</a>
                </div>
            </div>

            <div class="col-8">
                <table id="users_table" class="table table-striped">
                    <thead>
                        <tr class="border-b-2 text-black">
                            <th class=""> Publicación</th>
                            <th> Titulo</th>
                            <th>Editar</th>
                            <th> Borrar</th>
                            <th>Visible</th>
                        </tr>
                    </thead>

                    <tbody class="bg-gray-300 text-gray-700">
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->publish_at->format('d-m-Y')); ?></td>
                                <td><?php echo e($item->title); ?></td>
                                <td> <a href="<?php echo e(route('posts.edit', $item->id)); ?>" class="btn btn-warning"><i
                                            class="fas fa-edit    "></i></a></td>
                                <td>
                                    <form action="<?php echo e(route('posts.destroy', $item->id)); ?>" method="POST" >
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i></button>
                                    </form>
                                </td>

                                <td><?php echo e($item->active ? 'visible' : 'oculto'); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>


                </table>
            </div>
        </div>
    </div>




 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/admin/blog/index.blade.php ENDPATH**/ ?>