<footer class="footer " style="padding-top:1rem; padding-bottom:1rem;">
    <div class="container">
        <?php echo $__env->make('layouts.footers.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

</footer>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/layouts/footers/auth.blade.php ENDPATH**/ ?>