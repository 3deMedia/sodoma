
<?php $attributes = $attributes->exceptProps(['pending']); ?>
<?php foreach (array_filter((['pending']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class="py-3">
    <div class="container ">

        <div class="row">
            <div class="col-12">
                <div class="table-responsive">
                    <table class="table align-items-center table-flush">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col" class="sort" data-sort="name">#</th>
                                <th scope="col" class="sort" data-sort="name"><?php echo e(__('agency.Escort_name')); ?></th>
                                <th scope="col" class="sort" data-sort="name"><?php echo e(__('agency.Escort_created')); ?></th>
                                <th scope="col" class="sort" data-sort="budget"><?php echo e(__('general.Edit')); ?></th>
                            </tr>
                        </thead>
                        <tbody class="list">
                            <?php $__currentLoopData = $pending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pnd_scrt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td scope="row">
                                    <div class="">
                                        <a href="#" class="mavatar mr-3">
                                            <?php
                                            $mfoto = $pnd_scrt->MainPhoto();
                                            ?>
                                            <?php if($mfoto): ?>
                                            <img loading="lazy"  style="border-radius:8px"   src="<?php echo e(asset("storage/escort_photos/$mfoto->path/$mfoto->filename")); ?>">
                                            <?php endif; ?>
                                        </a>

                                    </div>
                                </td>
                                <td>
                                    <div class="media-body">
                                        <span class="name mb-0 text-sm"><?php echo e($pnd_scrt->name); ?></span>
                                    </div>
                                </td>
                                <td class="budget">
                                    <?php echo e($pnd_scrt->created_at); ?>

                                </td>
                                <td>
                                    <a href="<?php echo e(route('agency-escort-edit',$pnd_scrt->id)); ?>" class="btn btn-warning">
                                        <i class="fas fa-user-edit"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>


<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/user/agency/tabs/pending-escorts.blade.php ENDPATH**/ ?>