<div>
    <div class="row">
        <div class="col-12 col-md-10 mx-auto">


            <?php if($admin): ?>
            <form action="<?php echo e(route('admin-profile-store')); ?>" method="post" autocomplete="off"
            enctype="multipart/form-data" id="Escortform">
            <?php else: ?>
            <form action="<?php echo e(route('profile.store')); ?>" method="post" autocomplete="off"
            enctype="multipart/form-data" id="NewEscortForm" class="container py-4">
            <?php endif; ?>
                <?php echo csrf_field(); ?>

                <?php if($admin): ?>
                <input type="hidden" name="user_type_id" value="2">

                <?php endif; ?>
                <div>
                     
                    <div class="row">
                        <div class="col-12">
                            <h3 class="fs-3 fw-bold text-mgray border-bottom border-mcolor w-100">
                                <?php echo e(__('forms.profile.Basic')); ?></h3>
                        </div>

                        <div class="col-12 ">
                            <div class="d-flex flex-wrap flex-md-nowrap">

                                <label for="" class="p-2 d-flex flex-column w-100 ">
                                    <span class="form-label"><?php echo e(__('forms.profile.Name')); ?></span>
                                    <input required name="name" type="text" class="w-100 form-control"
                                        value="<?php echo e(old('name')); ?>" />
                                </label>
                                <label for="" class="p-2 d-flex flex-column w-100">
                                    <span class="form-label"><?php echo e(__('forms.profile.Email')); ?></span>
                                    <input required type="text" name="email" class="form-control"
                                        value="<?php echo e(old('email')); ?>" />
                                </label>
                            </div>
                            <div class="d-flex flex-wrap flex-md-nowrap">
                                <label for="" class="p-2 d-flex flex-column w-100">
                                    <span class="form-label"><?php echo e(__('forms.profile.Phone')); ?></span>
                                    <input required type="text" name="phone" class="form-control"
                                        value="<?php echo e(old('phone')); ?>" />
                                </label>
                                <label for="" class="p-2 d-flex flex-column w-100">
                                    <span class="form-label"><?php echo e(__('forms.profile.web')); ?></span>
                                    <input type="text" name="web" class="form-control"
                                        value="<?php echo e(old('web')); ?>" />
                                </label>
                            </div>
                        </div>

                        <div class="col-12">

                            <label for="" class="form-label w-100">
                                <p class="mx-2"><?php echo e(__('forms.profile.Description')); ?></p>
                                <textarea required required  name="description" id=""
                                    class="w-100 rounded  form-control"><?php echo e(old('description')); ?></textarea>
                            </label>

                        </div>

                    </div>
                    
                     
                    <div class="row">
                        <div class="col-12 py-4">

                            <script>
                                const main_source = null
                            </script>

                            <input type="file" name="photo" id="agency_photo"  class="w-100">


                        </div>
                    </div>
                    

                    
                    <div class="row">
                        <div class="col-12">

                            <h3 class="fs-3 fw-bold text-mgray border-bottom border-mcolor w-100">
                                <?php echo e(__('forms.profile.Address')); ?></h3>
                        </div>
                        <div class="col-12">
                            <div class="d-flex flex-wrap flex-md-nowrap">
                                <label for="" class="w-100 w-md-25 d-flex flex-column px-2">
                                    <span class="form-label"><?php echo e(__('forms.profile.Country')); ?></span>
                                    <select required  class="js-example-basic-single w-100 " name="country_id"
                                        id="a-country-select">
                                        <?php $countries= DB::table('countries')->get() ?>
                                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($country->id); ?>" <?php echo e(old('country_id') == $country->id ? 'selected' : ''); ?>>
                                            <?php echo e(__("geodata.countries.$country->name")); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </label>
                                <label for="" class="w-100 w-md-25 d-flex flex-column px-2">
                                    <span class="form-label"><?php echo e(__('forms.profile.Region')); ?></span>
                                    <select required  class="js-example-basic-single w-100" name="region_id"
                                        id="a-region-select">
                                        <?php if(old('region_id')): ?>
                                        <option value="<?php echo e(old('region_id')); ?>" selected>
                                            <?php echo e(DB::table('regions')->where('id', intval(old('region_id')))->first()->name); ?>

                                        </option>
                                        <?php endif; ?>

                                    </select>
                                </label>

                                <label for="" class="w-100 d-flex flex-column px-2">
                                    <span class="form-label"><?php echo e(__('forms.profile.City')); ?></span>
                                    <select required class="js-example-basic-single w-100" name="city_id"
                                        id="a-cities-select">
                                        <?php if(old('city_id')): ?>
                                        <option value="<?php echo e(old('city_id')); ?>" selected>
                                            <?php echo e(DB::table('cities')->where('id', intval(old('city_id')))->first()->name); ?>

                                        </option>
                                        <?php endif; ?>
                                    </select>
                                </label>
                            </div>

                        </div>
                        <div class="col-12">
                            <div class="w-100 p-2 my-2">
                                <label for="" class="w-100">
                                    <span><?php echo e(__('forms.profile.Address')); ?> <span
                                            class="text-red-400">*</span></span>
                                    <input required  type="text" name="address" class="w-100"
                                        value="<?php echo e(old('address')); ?>" />
                                </label>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-12">

                            <div class="p-2 text-center py-4 w-100 d-flex">
                                <input type="submit" name="save"
                                class=" btn rounded w-100 bg-mcolor text-white px-4 py-2 mx-auto btn-submit" value="<?php echo e(__('general.Save')); ?>">

                            </div>
                        </div>
                    </div>

                </div>
        </div>
        <!-- LBasic-->

        </form>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/components/forms/create-agency.blade.php ENDPATH**/ ?>