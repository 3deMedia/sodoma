<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GuestLayout::class, []); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startPush('meta'); ?>
        <meta name="description" content="<?php echo e($seo->seo_description); ?>" />
        <meta name="keywords" content="<?php echo e($seo->seo_keywords); ?>" />
        <title><?php echo e(config('app.name')); ?> | <?php echo e($seo->seo_title); ?></title>
    <?php $__env->stopPush(); ?>
    <?php if(count($posts) !== 0): ?>
        <div class="container">
            <div class="text-center my-8"><h1>Blog</h1></div>
            <div class="row">

                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 col-md-4">
                        <div class="card">
                            <div class="card-header text-center">
                                <a href="<?php echo e(route('show-post', $post->slug)); ?>"><img class="w-100"
                                src="<?php echo e(asset('storage/posts')); ?>/<?php echo e($post->img_file); ?>" alt="content"></a>
                            </div>

                            <div class="card-body">
                                <a href="<?php echo e(route('show-post', $post->slug)); ?>" class="blogtitle"><?php echo e($post->title); ?></a>
                                <br /><span><?php echo e(\Carbon\Carbon::parse($post->created_at)->format('d / m / Y')); ?></span>
                                <p class="mb-4 text-base">
                                    <?php echo mb_strimwidth($post->content, 0, 400, '...'); ?></p>
                                <a href="<?php echo e(route('show-post', $post->slug)); ?>"
                                    class="btn btn-primary">Leer más</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <?php echo e($posts->links()); ?>

        </div>
    <?php else: ?>
        <p class="font-bold text-center py-4 text-white"><?php echo app('translator')->get('main.Nothing to show'); ?></p>
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\sodoma\resources\views/guest/blog/index.blade.php ENDPATH**/ ?>