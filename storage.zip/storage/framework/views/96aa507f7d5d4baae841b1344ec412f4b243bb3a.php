<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <?php echo $__env->yieldPushContent('meta'); ?>
        <!-- Favicon -->
        <link href="<?php echo e(asset('images//favicon.jpg')); ?>" rel="icon" type="image/png">
        <!-- Styles -->
        <link type="text/css" href="<?php echo e(asset('argon')); ?>/css/argon.css?v=1.0.0" rel="stylesheet">
        
        <link type="text/css" rel="stylesheet" href="<?php echo e(mix('css/secrets_front.css')); ?>">
        <!-- Icons -->
        <link href="<?php echo e(asset('argon')); ?>/vendor/nucleo/css/nucleo.css" rel="stylesheet">
        <link href="<?php echo e(asset('argon')); ?>/vendor/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet">
        <!-- Argon CSS -->

    </head>
    <body class="<?php echo e($class ?? ''); ?>">


        <div class="container-fluid px-0">
                <?php echo $__env->make('guest.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div>

                <div class="order-0 order-sm-1 main-content mx-0 pb-4">
                    <?php echo e($slot); ?>

                </div>
                
                </div>


        </div>


            <?php echo $__env->make('layouts.footers.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <script src="<?php echo e(asset('argon')); ?>/vendor/jquery/dist/jquery.min.js"></script>
        <script src="<?php echo e(asset('argon')); ?>/vendor/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
        <?php echo $__env->yieldPushContent('js'); ?>
        <!-- Argon JS -->
        <script src="<?php echo e(asset('argon')); ?>/js/argon.js?v=1.0.0"></script>
        <script src="<?php echo e(asset('js/lozad.js')); ?>"></script>

    </body>
</html>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/layouts/guest.blade.php ENDPATH**/ ?>