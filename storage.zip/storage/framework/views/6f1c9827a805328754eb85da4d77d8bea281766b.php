<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminLayout::class, []); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginalac09df57349bd019565ada4b240c9ec027a8956f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Head\TinymceConfig::class, []); ?>
<?php $component->withName('head.tinymce-config'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalac09df57349bd019565ada4b240c9ec027a8956f)): ?>
<?php $component = $__componentOriginalac09df57349bd019565ada4b240c9ec027a8956f; ?>
<?php unset($__componentOriginalac09df57349bd019565ada4b240c9ec027a8956f); ?>
<?php endif; ?>
    <div class="container pt-5">

        <?php if(session('success')): ?>
            <div class="bg-green-500 p-3 my-2 w-100 rounded text-white"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="bg-danger p-3 my-2 w-100 rounded text-white"><?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <div class="row">
            <div class="col-12">
                <h1 class="text-info"><?php echo app('translator')->get('New Post'); ?> </h1>
                <form action="<?php echo e(route('posts.store')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                        <div class="form-group w-25">
                            <label for="title" class="block label"><?php echo app('translator')->get('Title'); ?></label>
                            <input type="text" name="title" value="<?php echo e(old('title')); ?>" class="form-control">
                        </div>

                        <div class="form-group w-25 ">
                            <label for="title" class="block"><?php echo app('translator')->get('Meta keywords'); ?></label>
                            <input type="text" name="keywords" value="<?php echo e(old('keywords')); ?>" class="form-control"
                                >
                        </div>
                        <div class="form-group w-25">
                            <label for="title" class="block"><?php echo app('translator')->get('Meta Description'); ?></label>
                            <input type="text" name="description" value="<?php echo e(old('description')); ?>"
                                class="form-control" >
                        </div>
                        <div class="form-group w-25">
                            <label for="active">
                                <input type="checkbox" name="active" id="active"> Visible
                            </label>
                            <label for="publish_at" class=" mx-4">
                                <?php echo app('translator')->get('publish_at'); ?><br>
                                <input type="date" name="publish_at" id="" class="form-control"
                                    value=<?php echo e(old('publish_at')); ?>>
                            </label>
                            <label for="image_file">Imagen portada
                                <input type="file" name="image_file" id="image_file"
                                    class="rounded text-xs md:text-base">
                            </label>

                        </div>



                        <?php
                            $content= old('content') ? old('content'):null;
                        ?>
                    <?php if (isset($component)) { $__componentOriginalfa6f1724b3c1942a6d14fbc543b5026d337a982c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Forms\TinymceEditor::class, ['content' => $content]); ?>
<?php $component->withName('forms.tinymce-editor'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfa6f1724b3c1942a6d14fbc543b5026d337a982c)): ?>
<?php $component = $__componentOriginalfa6f1724b3c1942a6d14fbc543b5026d337a982c; ?>
<?php unset($__componentOriginalfa6f1724b3c1942a6d14fbc543b5026d337a982c); ?>
<?php endif; ?>

                    <button type="submit" class="btn btn-primary my-2" >Guardar</button>

                </form>
            </div>

        </div>



    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\sodoma\resources\views/admin/blog/create.blade.php ENDPATH**/ ?>