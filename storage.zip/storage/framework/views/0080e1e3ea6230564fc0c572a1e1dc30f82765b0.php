<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminLayout::class, []); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container pt-5 px-2">
        <div class="row">
            <div class="col-12 col-md-10 ">
                <table id="users_table" class="table table-striped ">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Fecha creación</th>
                            <th>Nombre</th>
                            <th>Tipo</th>
                            <th>Perfil</th>
                            <th>Coins</th>
                            <td>Borrar</td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $u_type=$user->user_type_id ;
                        ?>
                        <tr>
                            <td><?php echo e($user->id); ?></td>
                            <td><?php echo e($user->created_at->format('d-m-Y')); ?></td>
                            <td scope="row">
                                <a href="<?php echo e(route('admin-user-show', $user->id)); ?>" ><?php echo e($user->email); ?></a>
                                </td>
                            <td> <?php echo e($u_type== 1 ? 'escort' :'agency'); ?> </td>
                            <td>
                                <?php if($user->Profile()): ?>
                                <a href="<?php echo e(route('admin-profile-show', $user->Profile()->id)); ?>"
                                    class="btn btn-warning"><i class="fa fa-eye" aria-hidden="true"></i></a>
                                <?php else: ?>
                                    No tiene
                                <?php endif; ?>

                            </td>
                            <td><?php echo e($user->coins); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin-user-delete', $user->id)); ?>"
                                    class="btn btn-danger"><i class="fa fa-trash" aria-hidden="true"></i></a>
                            </td>

                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>


 <?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/admin/users/index.blade.php ENDPATH**/ ?>