<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminLayout::class, []); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container pt-2 pt-md-5">
        <div class="row">
            <div class="col-12 col-md-10 ">
                <!-- Button trigger modal -->
                <button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#modelId">
                    Nueva categoria
                </button>

                <!-- Modal -->
                <div class="modal fade" id="modelId" tabindex="-1" role="dialog" aria-labelledby="modelTitleId"
                    aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Nueva Categoria</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form action="<?php echo e(route('admin-post-texts')); ?>" method="post" class="d-flex flex-column">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group d-flex flex-column">
                                        <label for="">Nombre categoria</label>
                                        <input type="text" name="name">

                                    </div>
                                    <div class="form-group d-flex flex-column">
                                        <label for="">Descriptcion 1</label>
                                        <textarea name="description_1">  </textarea>
                                    </div>
                                    <div class="form-group d-flex flex-column">
                                        <label for="">Descriptcion 2</label>
                                        <textarea name="description_2"></textarea>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary">Save</button>
                                    </div>
                                </form>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="container pt-5 pb-8">

                    <div class="row">

                        <p class="col-3">Categoria</p>
                        <p class="col-3">Descripción 1</p>
                        <p class="col-3">Descripcion 2</p>
                        <p class="col-1"></p>
                    </div>

                    <div class="row">
                        <?php $__currentLoopData = $category_texts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ctext): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if (isset($component)) { $__componentOriginal60f26ec880bf01ff4c5047fe98d3b148966bd109 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CategoryText::class, ['ctext' => $ctext]); ?>
<?php $component->withName('category-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal60f26ec880bf01ff4c5047fe98d3b148966bd109)): ?>
<?php $component = $__componentOriginal60f26ec880bf01ff4c5047fe98d3b148966bd109; ?>
<?php unset($__componentOriginal60f26ec880bf01ff4c5047fe98d3b148966bd109); ?>
<?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </div>
                </div>
            </div>
        </div>
    </div>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\sodoma\resources\views/admin/texts/index.blade.php ENDPATH**/ ?>