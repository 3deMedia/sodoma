<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GuestLayout::class, []); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php $__env->startPush('meta'); ?>
<meta name="description" content="<?php echo e($post->description); ?>" />
<meta name="keywords" content="<?php echo e($post->keywords); ?>" />
<title><?php echo e(config('app.name')); ?> | <?php echo e($post->title); ?></title>
<?php $__env->stopPush(); ?>

    <div class="container pt-5 bg-black">
        <div class="text-center my-8"><a href="<?php echo e(route('show-blog')); ?>"><h1> <?php echo e($post->title); ?></h1></a></div>
        <div class="row">
                <div class="col-12 text-center">
                    <img class="w-100"
                        alt="<?php echo e(config('app.name')); ?> | <?php echo e($post->title); ?>" src="<?php echo e(asset('storage/posts')); ?>/<?php echo e($post->img_file); ?>" height="420">
                </div>
                <div class="col-12 col-md-10 mx-auto my-6">
                    <h1><?php echo e(strtoupper($post->title)); ?></h1>
                    <span class="text-muted p-2">Posted on <?php echo e(\Carbon\Carbon::parse($post->created_at)->format('d / m / Y')); ?></span>
                    <div class="p-2 mcolor mt-3">
                        <?php echo $post->content; ?>

                    </div>
                </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\sodoma\resources\views/guest/blog/show.blade.php ENDPATH**/ ?>