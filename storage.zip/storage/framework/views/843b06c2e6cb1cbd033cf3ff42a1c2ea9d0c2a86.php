
<?php
    $num = $relacionadas->count();
?>
<?php if($num >= 4): ?>{
    <div class="container">
        <h2 class="text-center pt-6 pb-3">También puede interesarte</h2>

        <div class="row my-4">
            <div class="d-flex flex-wrap mx-auto">
                <?php $__currentLoopData = $relacionadas->random(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scrt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                      $mainPhoto = $scrt->MainPhoto();

                    ?>
                    <div class="p-2 rounded text-center profile-view2">
                        <div class="bg-white">
                            <a href="<?php echo e(route('show-escorts', [$scrt->Address->City->slug,$scrt->uid])); ?>" class="w-100 ">
                                <div style="width: 100%; position: relative;"  class="<?php if($scrt->is_vip): ?> corner <?php endif; ?>" >
                                    <div  <?php if($scrt->verified): ?> class="verified" <?php endif; ?>>
                                         <img loading="lazy" src='<?php echo e(asset("storage/escort_photos/$mainPhoto->path/$mainPhoto->filename")); ?>' alt="<?php echo e($scrt->name); ?>" />
                                    </div>
                                </div>
                            </a>
                            <p class="profile-name"><?php echo e($scrt->name); ?> <br /><span class="profile-under">
                                 <?php if(!empty($scrt->Features->age)): ?> <i class="fa fa-square-full icosquare"></i> <?php echo e($scrt->Features->age); ?> años <?php endif; ?>
                                 <?php if(!empty($scrt->Features->height)): ?> <i class="fa fa-square-full icosquare mleft"></i> <?php echo e($scrt->Features->height); ?> cm <?php endif; ?>
                                 <?php if(!empty($scrt->Rates->one_hour)): ?><i class="fa fa-square-full icosquare mleft"></i> <?php echo e($scrt->Rates->one_hour); ?> €<?php endif; ?> </span></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
 <?php else: ?>

 <?php endif; ?>

<?php /**PATH C:\laragon\www\sodoma\resources\views/components/relacionadas.blade.php ENDPATH**/ ?>