        <div class="mx-2 my-4">
        <div id="demo" class="collapse show"  style="min-height: 70px;">
        <div><a class="nav-enlace" href="<?php echo e(route('my-account')); ?>"><?php echo e(__('general.My account')); ?> </a>
        <a class="nav-enlace" href="<?php echo e(route('my-profile')); ?>"><?php if(auth()->user()->user_type_id ==2): ?>Editar Agencia <?php else: ?> <?php echo e(__('general.PublishAd')); ?> <?php endif; ?></a>
         <?php if(auth()->user()->user_type_id ==2): ?>
               <a class="nav-enlace" href="<?php echo e(route('my-escorts')); ?>">Mis Anuncios </a>
         <?php endif; ?>
        </div>
        </div>
        <div id="botcambi" class="boti "><a class="botiop" data-toggle="collapse" data-target="#demo"   aria-expanded="true"> <i class="cambi ni ni-bold-up text-xl"></i> </a>
        </div>

<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/user/layouts/botones.blade.php ENDPATH**/ ?>