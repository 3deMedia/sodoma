<div class="col-12 col-md-10 ">
    <table id="users_table" class="table table-striped ">

        <thead>
            <tr>
                <th>#</th>
                <th>Fecha creacion</th>
                <th>Nombre</th>
                <th>Email</th>
                <th>Ver</th>
                <th>Es Vip?</th>
                <th>Escorts</th>

            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($profile->id); ?></td>
                <td><?php echo e($profile->created_at->format('d-m-Y')); ?></td>
                <td scope="row"> <?php echo e($profile->name); ?></td>
                <td> <?php echo e($profile->email); ?> </td>
                <td><a href="<?php echo e(route('admin-profile-show',$profile->id)); ?>" class="btn btn-info"><i class="fa fa-eye" aria-hidden="true"></i> </a></td>
                <td><?php echo e($profile->is_vip ? 'si':'no'); ?></td>
                <td>
                  <?php echo e($profile->Escorts()->count()); ?>

                </td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

</table>
</div>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/components/tables/admin-agencies.blade.php ENDPATH**/ ?>