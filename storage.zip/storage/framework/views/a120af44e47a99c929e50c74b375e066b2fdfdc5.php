<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
      <div class="container pb-5">
        <div class="row">
            <div class="col-12">
                <h2 class="fw-bold mb-4 text-center pb-4"> <?php echo e(__('general.Payments')); ?></h2>
            </div>
        <div class="row">
            <div class="col-12 col-md-10 col-xl-8 mx-auto overflow-auto">
                <table class="table" id="users_table">
                    <thead>
                        <tr>
                            <th><?php echo e(__('general.Date')); ?></th>
                            <th class="text-center"><?php echo e(__('general.Quantity')); ?></th>

                            <th class="text-center"><?php echo e(__('general.Pay_ticket')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td scope="row"><?php echo e($purch->created_at->format('d-m-Y')); ?></td>
                            <td class="text-center"><?php echo e($purch->amount); ?> €</td>
                            <td class="text-center"><a target="_blank" href="<?php echo e(route('pdf-payment',$purch->id)); ?>" class="btn btn-danger"><i class="fa fa-file-pdf" aria-hidden="true"></i></a></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </tbody>
                </table>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\sodoma\resources\views/user/payments.blade.php ENDPATH**/ ?>