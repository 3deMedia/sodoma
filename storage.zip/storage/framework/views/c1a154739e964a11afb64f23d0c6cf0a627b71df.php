<nav class="navbar navbar-horizontal navbar-expand-md navbar-light bg-white" id="sidenav-main">
    <div class="container-fluid">
        <!-- Toggler -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <!-- Brand -->

        <a class="navbar-brand pt-0" href="<?php echo e(route('home')); ?>">
            <img src="<?php echo e(asset('images/escortssecrets-logo.png')); ?>" style="height: 63px" alt="Escorts Secrets Publicidad"/>
        </a>
        <!-- User -->

        <ul class="nav align-items-center d-md-none">
            <li class="nav-item dropdown">
                <a class="nav-link" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <div class="media align-items-center">

                        
                        <i class="ni ni-single-02 text-lg text-black"></i>2222
                    </div>
                </a>
                <div class="dropdown-menu dropdown-menu-arrow dropdown-menu-right">
                    <div class=" dropdown-header noti-title">
                        <h6 class="text-overflow m-0"><?php echo e(__('Cuenta')); ?></h6>
                    </div>
                    <a href="<?php echo e(route('my-account')); ?>" class="dropdown-item">
                        <i class="ni ni-single-02"></i>
                        <span><?php echo e(__('general.My account')); ?></span>
                    </a>

                    <a href="<?php echo e(route('contact-us')); ?>" class="dropdown-item">
                        <i class="ni ni-support-16"></i>
                        <span><?php echo e(__('general.Support')); ?></span>
                    </a>
                    <div class="dropdown-divider"></div>
                    <a href="<?php echo e(route('logout')); ?>" class="dropdown-item" onclick="event.preventDefault();
                    document.getElementById('logout-form').submit();">
                        <i class="ni ni-button-power"></i>
                        <span><?php echo e(__('general.Logout')); ?></span>
                    </a>
                </div>
            </li>
        </ul>
        <!-- Collapse -->
        <div class="collapse navbar-collapse" id="sidenav-collapse-main">
            <!-- Collapse header -->
            <div class="navbar-collapse-header d-md-none">
                <div class="row">
                    <div class="col-6 collapse-brand">
                        <a href="/">
                            <img src="<?php echo e(asset('images/escortssecrets-logo.png')); ?>" style="height: 63px" alt="Escorts Secrets Publicidad"/>
                        </a>
                    </div>
                    <div class="col-6 collapse-close">
                        <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle sidenav">
                            <span></span>
                            <span></span>
                        </button>
                    </div>
                </div>
            </div>
            <!-- Navigation -->
            <ul class="navbar-nav align-items-right">
                
                <li class="nav-item">
                    <a class="nav-link  <?php if(request()->routeIs('my-profile')): ?> fw-bold  text-black <?php endif; ?>" href="<?php echo e(route('my-profile')); ?>">
                        <i class="ni ni-circle-08" style="color: #B142A1;"></i> <?php echo e(__('general.Manage_profile')); ?>

                    </a>
                </li>

                <?php if(auth()->user()->user_type_id ==2): ?>

                <li class="nav-item ">
                    <a class="nav-link  <?php if(request()->routeIs('my-escorts')): ?> fw-bold  text-black <?php endif; ?>" href="<?php echo e(route('my-escorts')); ?>">
                        <i class="fas fa-chess-king text-pink"></i>  <?php echo e(__('general.My_escorts')); ?>

                    </a>
                </li>


                <?php endif; ?>


                <li class="nav-item">
                    <a class="nav-link  <?php if(request()->routeIs('become-vip')): ?> fw-bold  text-black <?php endif; ?>" href="<?php echo e(route('become-vip')); ?>">
                        <i class="fas fa-star text-blue"></i> <?php echo e(__('general.Become_vip')); ?>

                    </a>
                </li>
                <li class="nav-item ">
                    <a class="nav-link  <?php if(request()->routeIs('buy-coins')): ?> fw-bold  text-black <?php endif; ?>" href="<?php echo e(route('buy-coins')); ?>">
                        <i class="fas fa-donate text-orange"></i> <?php echo e(__('general.Buy_coins')); ?>

                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link  <?php if(request()->routeIs('payments')): ?> fw-bold  text-black <?php endif; ?>" href="<?php echo e(route('payments')); ?>">
                        <i class="far fa-credit-card text-green"></i>
                      <span class="nav-link-text"> <?php echo e(__('general.Payments')); ?></span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link  <?php if(request()->routeIs('my-messages')): ?> fw-bold  text-black <?php endif; ?>" href="<?php echo e(route('my-messages')); ?>">
                        <i class="far fa-envelope text-yellow"></i>
                      <span class="nav-link-text"> <?php echo e(__('general.Messages')); ?></span>
                    </a>
                </li>
                
                

            </ul>
            <!-- Divider -->

        </div>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/user/layouts/sidebarOLD.blade.php ENDPATH**/ ?>