<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GuestLayout::class, []); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <?php $__env->startPush('meta'); ?>
        <meta name="description" content="<?php echo $seo->seo_description; ?>" />
        <meta name="keywords" content="<?php echo e($seo->seo_keywords); ?>" />
        <title><?php echo e($seo->seo_title); ?></title>
    <?php $__env->stopPush(); ?>



    <div class="container py-4">
        <div class="row">
        <div class="title py-4 mx-auto col-12 ">
            <h1 class="text-center"><?php echo e(__('general.navs.publishads')); ?></h1>
            <p class="text-center text-black"><em><?php echo e(__('general.Welcome_text')); ?></em></p>
        </div>



            <div class="col-12 col-md-8 col-lg-6 mx-auto my-4">
                <div class="rounded shadow">
                    <ul class="nav nav-tabs text-center" id="accountTab" role="tablist">
                        <li class="nav-item w-50" role="presentation">
                            <a class="nav-link active py-3" id="login-tab" data-toggle="tab" href="#login" role="tab" aria-controls="login" aria-selected="true"><?php echo e(__('general.navs.login')); ?></a>
                          </li>
                          <li class="nav-item w-50" role="presentation">
                            <a class="nav-link py-3" id="register-tab" data-toggle="tab" href="#register" role="tab" aria-controls="register" aria-selected="true"><?php echo e(__('general.navs.register')); ?></a>
                          </li>
                    </ul>
                    <div class="tab-content bg-white rounded" id="accountTabContent">
                        <div class="tab-pane fade show active rounded" id="login" role="tabpanel" aria-labelledby="login-tab">

                            <div class="card-body">

                                <form role="form" method="POST" action="<?php echo e(route('login')); ?>" class="">
                                    <?php echo csrf_field(); ?>

                                    <div class="form-group<?php echo e($errors->has('email') ? ' has-danger' : ''); ?> mb-3">
                                        <div class="input-group input-group-alternative">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text"><i class="ni ni-email-83"></i></span>
                                            </div>
                                            <input class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>"
                                                placeholder="<?php echo e(__('Email')); ?>" type="email" name="email"
                                                value="<?php echo e(old('email')); ?>" value="admin@argon.com" required autofocus>
                                        </div>
                                        <?php if($errors->has('email')): ?>
                                            <span class="invalid-feedback" style="display: block;" role="alert">
                                                <strong><?php echo e($errors->first('email')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group<?php echo e($errors->has('password') ? ' has-danger' : ''); ?>">
                                        <div class="input-group input-group-alternative">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text"><i class="ni ni-lock-circle-open"></i></span>
                                            </div>
                                            <input class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>"
                                                name="password" placeholder="<?php echo e(__('Contraseña')); ?>" type="password"
                                                required>
                                                <span class="p-viewer">
                                                    <i class="fa fa-eye" aria-hidden="true"></i>
                                                  </span>
                                        </div>
                                        <?php if($errors->has('password')): ?>
                                            <span class="invalid-feedback" style="display: block;" role="alert">
                                                <strong><?php echo e($errors->first('password')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="custom-control custom-control-alternative custom-checkbox">
                                        <input class="custom-control-input" name="remember" id="customCheckLogin"
                                            type="checkbox" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                        <label class="custom-control-label" for="customCheckLogin">
                                            <span class="text-muted">Recordarme</span>
                                        </label>
                                    </div>
                                    <div class="text-center">
                                        <button type="submit" class="btn btn-primary my-4">Entrar</button>
                                    </div>
                                </form>
                                <div class="mt-3">
                                        <?php if(Route::has('password.request')): ?>
                                            <a href="<?php echo e(route('password.request')); ?>">
                                                <small>¿Has olvidado tu contraseña?</small>
                                            </a>
                                        <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade rounded " id="register" role="tabpanel" aria-labelledby="register-tab">

                            <div class="card-body px-lg-4 py-lg-4">

                                <form role="form" method="POST" action="<?php echo e(route('register')); ?>" id="register-form">
                                    <?php echo csrf_field(); ?>
                                    <div>
                                        <?php if($errors->has('user_type_id')): ?>
                                            <span class="invalid-feedback" style="display: block;" role="alert">
                                                <strong><?php echo e($errors->first('user_type_id')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                        <div class="form-group d-flex justify-content-around">
                                            <div class="form-group form-check">
                                                <input type="radio" class="form-check-input" name="user_type_id" value="1"
                                                    checked required>
                                                <label class="form-check-label"
                                                    for="exampleCheck1"><?php echo e(__('general.Escort')); ?></label>
                                            </div>
                                            <div class="form-group form-check">
                                                <input type="radio" class="form-check-input" name="user_type_id"
                                                    value="2">
                                                <label class="form-check-label" for=""><?php echo e(__('general.Agency')); ?></label>
                                            </div>

                                        </div>
                                    </div>


                                    <div class="form-group<?php echo e($errors->has('email') ? ' has-danger' : ''); ?>">
                                        <div class="input-group input-group-alternative mb-3">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text"><i class="ni ni-email-83"></i></span>
                                            </div>
                                            <input class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>"
                                                placeholder="<?php echo e(__('Email')); ?>" type="email" name="email"
                                                value="<?php echo e(old('email')); ?>" required>
                                        </div>
                                        <?php if($errors->has('email')): ?>
                                            <span class="invalid-feedback" style="display: block;" role="alert">
                                                <strong><?php echo e($errors->first('email')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group<?php echo e($errors->has('password') ? ' has-danger' : ''); ?>">
                                        <div class="input-group input-group-alternative">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text"><i class="ni ni-lock-circle-open"></i></span>
                                            </div>
                                            <input class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>"
                                                placeholder="Contraseña" type="password" name="password" required>
                                                <span class="p-viewer">
                                                    <i class="fa fa-eye" aria-hidden="true"></i>
                                                  </span>
                                        </div>
                                        <?php if($errors->has('password')): ?>
                                            <span class="invalid-feedback" style="display: block;" role="alert">
                                                <strong><?php echo e($errors->first('password')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="form-group">
                                        <div class="input-group input-group-alternative">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text"><i class="ni ni-lock-circle-open"></i></span>
                                            </div>
                                            <input class="form-control" placeholder="Confirmar Contraseña" type="password"
                                                name="password_confirmation" required>
                                                <span class="p-viewer">
                                                    <i class="fa fa-eye" aria-hidden="true"></i>
                                                  </span>
                                        </div>
                                    </div>

                                    <div class="row my-4">
                                        <div class="col-12">
                                            <div class="custom-control custom-control-alternative custom-checkbox">
                                                <input class="custom-control-input" id="accept_policy" type="checkbox"
                                                    name="accept_policy" required checked>
                                                <label class="custom-control-label" for="customCheckRegister">
                                                    <span class="text-muted">Estoy de acuerdo con la <a href="#!">Política
                                                            de Privacidad</a></span>
                                                </label>
                                            </div>
                                            <span class="invalid-feedback d-none" style="display: block;" role="alert"
                                                id="policy-check">
                                                <strong><?php echo e(__('general.must_accept_policy')); ?></strong>
                                            </span>

                                        </div>
                                    </div>
                                    <div class="text-center">
                                        <button type="submit" class="btn btn-primary mt-4 btn-submit">Crear Cuenta</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

            </div>


        </div>
        <div class="row">
            <div class="pb-5 pt-5">

                <h2 class="text-xl"><?php echo e(__('general.howto_title')); ?></h2>
                <p><?php echo e(__('general.howto_text_main')); ?></p>
                <p><?php echo e(__('general.howto_text_contact')); ?><a
                        href="mailto:info@escortssecrets.com"> <?php echo e(config('app.contact_email')); ?></a></p>
                <p><?php echo e(__('general.howto_text_wassap')); ?> <a
                        href="https://api.whatsapp.com/send?phone=0034663763606&amp;text=Quiero Anunciarme"><i
                            class="icon-whatsapp"></i> <?php echo e(config('app.contact_phone')); ?></a></p>
            </div>
        </div>

        <?php $__env->startPush('js'); ?>
            <script>
                $('#register-form').on('submit', function(e) {
                    if ($('#accept_policy:checked').length === 0) {
                        $('#policy-check').removeClass('d-none')
                        e.preventDefault();
                    }
                });
                $('.p-viewer').on('click',function(){
                    let nu_type= $(this).siblings()[1].getAttribute('type')== 'text' ? 'password':'text';
                    $('.p-viewer').each( function(){
                        $(this).siblings()[1].setAttribute('type',nu_type)
                    });
                })
            </script>
        <?php $__env->stopPush(); ?>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\sodoma\resources\views/guest/home.blade.php ENDPATH**/ ?>