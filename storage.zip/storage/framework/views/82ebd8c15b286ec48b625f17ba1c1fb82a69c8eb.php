    <div class="container">

       <div class="l-filtros d-flex justify-content-between">
           <form>
               <label>Ciudad: </label>
               <select id="selector_ciudad">
                <option value="escorts-ibiza">Seleccionar</option>
                   <option value="<?php echo e(route('show-escorts','barcelona/')); ?>">Barcelona</option>
                   <option value="<?php echo e(route('show-escorts','madrid/')); ?>">Madrid</option>
                   <option value="<?php echo e(route('show-escorts','ibiza/')); ?>">Ibiza</option>
                   <option value="<?php echo e(route('show-escorts','valencia/')); ?>">Valencia</option>
                   <option value="<?php echo e(route('show-escorts','bilbao/')); ?>">Bilbao</option>
               </select>
           </form>


           <div class="buscatab d-flex justify-content-between">
            <?php if(Route::is('show-escorts')): ?>
                 <?php if($city): ?>
                      <div class="buscamap"><a href="<?php echo e(route('search.map',$city->slug)); ?>"><i class="fa fa-map"></i> Mapa</a> </div>
                <?php endif; ?>
             <?php endif; ?>
             <div class="buscatab"><form action="">
                <input type="search" name="q" id="" class="form-control form-control-flush" placeholder="<?php echo app('translator')->get('general.Search'); ?>...">
            </form></div>
           </div>
       </div>
    </div>

<?php /**PATH C:\laragon\www\sodoma\resources\views/guest/layouts/filtros.blade.php ENDPATH**/ ?>