<footer class="mt-5 container pt-2 border border-t " style="background-color: #fafafa; border-radius:8px;">
    <div class="d-flex p-2 justify-content-between flex-wrap">
        <div class="px-4">
            <img src="<?php echo e(asset('images/escortssecrets.png')); ?>" style="height: 79px"  alt="Escorts Secrets" />
            <p> Directorio de citas relax con mujeres con clase. </p>
        </div>
        <div class="px-4">

            <ul class="navbar-nav ml-lg-auto">
                <li class="nav-item">
                    <a class="nav-link nav-link-icon" href="<?php echo e(route('show-escorts', 'barcelona')); ?>">

                        <span class="nav-link-inner--text"><i class="fa fa-caret-right flechika"></i> Escorts Barcelona</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link nav-link-icon" href="<?php echo e(route('show-escorts', 'madrid')); ?>">

                        <span class="nav-link-inner--text"><i class="fa fa-caret-right flechika"></i> Escorts Madrid</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link nav-link-icon"  href="<?php echo e(route('show-escorts', 'ibiza')); ?>">

                        <span class="nav-link-inner--text"><i class="fa fa-caret-right flechika"></i> Escorts Ibiza</span>
                    </a>
                </li></ul>
        </div>
        <div class="px-4">

            <ul class="navbar-nav ml-lg-auto">
                <li class="nav-item">
                    <a class="nav-link nav-link-icon" href="<?php echo e(route('show-all-escorts')); ?>">

                        <span class="nav-link-inner--text"><i class="fa fa-caret-right flechika"></i> Otras Ciudades</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link nav-link-icon" href="<?php echo e(route('show-blog')); ?>">

                        <span class="nav-link-inner--text"><i class="fa fa-caret-right flechika"></i> Blog</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link nav-link-icon" href="<?php echo e(route('show-all-escorts')); ?>">

                        <span class="nav-link-inner--text"><i class="fa fa-caret-right flechika"></i> Contacto</span>
                    </a>
                </li></ul>
        </div>

    </div>

    <div class="pt-4">
        <?php echo $__env->make('layouts.footers.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>


</footer>
<?php /**PATH C:\laragon\www\sodoma\resources\views/layouts/footers/guest.blade.php ENDPATH**/ ?>