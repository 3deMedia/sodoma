<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 mx-auto">

                <div class="text-xs px-4">
                    <?php if($profile->approved): ?>

                        <?php if($profile->active): ?>
                            
                        <?php endif; ?>

                    <?php elseif($profile->ReviewRequest() && ($profile->ReviewRequest()->status=='pending' ||
                    $profile->ReviewRequest()->status=='request_again') ): ?>

                    <p class="text-xs p-2 fw-bold bg-purple text-white rounded mt-5">
                        <?php echo __('general.Request_review_inprocess'); ?>

                    </p>

                    <?php elseif($profile->ReviewRequest() && $profile->ReviewRequest()->status=='processed' ): ?>
                    <div class=" align-items-center bg-warning p-2 rounded my-2 mt-5">
                        <p class="my-0"> <i class="fas fa-exclamation-triangle"></i> <?php echo e(__('general.Request_review_response')); ?>


                            <span class="p-2 fw-bold "><?php echo e($profile->ReviewRequest()->message); ?></span>
                        </p>
                    </div>

                    <?php else: ?>

                    <p class="text-xs p-2 fw-bold mt-5">
                        <?php echo __('general.Request_review_text'); ?>

                    </p>

                    <?php endif; ?>
                </div>


                <form action="<?php echo e(route('Escort.update',$profile->id)); ?>" method="post" autocomplete="off"
                    enctype="multipart/form-data" id="Escortform">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="row">
                        <div><h2 class="fw-bold mb-6 text-center">Edita tu anuncio</h2></div>
                        <?php if($profile->active): ?>
                        <div class="col-12 col-md-8 col-lg-6 bg-white rounded-md block center px-4 py-3 mb-5">
                            <div style="float: right"><span class="coinsleft"><?php echo e(auth()->user()->coins); ?></span><br /><span class="saldoleft">saldo</span></div>
                                            <p><strong>Anuncio: </strong> <i class="fa fa-circle text-green"></i> Activo</p>
                            <p><strong>Renovación:</strong> 22/02/2022</p>
                        </div>
                        <?php endif; ?>
                        <p>Rellena los datos tal y como quieres que aparezcan en tu ficha que será publicada en la Web. Puedes inventarte el nombre que quieras, pero en el resto de datos y descripción ajustate lo más posible a la realidad.</p>

                    </div>
                    <!--Basico -->
                    <div class="row">
                        <h3 class="fs-3 fw-bold text-333 border-bottom border-mcolor w-75 montserrat my-5">
                            <?php echo e(__('forms.profile.Basic')); ?>

                        </h3>

                        <div class="col-12  py-2 d-flex flex-wrap flex-md-nowrap">
                            <div class="d-flex flex-wrap w-100">
                                <label for="name" class="p-0 p-md-2 d-flex flex-column w-100 form-label">
                                    <span class=""><?php echo e(__('forms.profile.Name')); ?>

                                        <span class="text-danger">*</span></span>
                                    <input required  type="text" name="name" class="form-control"
                                        value="<?php echo e($profile->name ? $profile->name : old('name')); ?>" />
                                </label>
                                <label for="phone" class="p-0 p-md-2 d-flex flex-column w-100 form-label">
                                    <span class=""><?php echo e(__('forms.profile.Phone')); ?> <span
                                            class="text-danger">*</span></span>
                                    <input required  type="text" name="phone" class="form-control"
                                        value="<?php echo e($profile->phone ? $profile->phone : old('phone')); ?>" />
                                </label>
                            </div>
                            <div class="d-flex flex-wrap w-100">

                                <label for="email" class="d-flex flex-column p-0 p-md-2 w-100 form-label">
                                    <span class=""><?php echo e(__('forms.profile.Email')); ?></span>
                                    <input required  type="text" name="email" class="form-control"
                                        value="<?php echo e($profile->email ? $profile->email : old('email')); ?>" />
                                </label>

                                <label for="gender" class="p-0 p-md-2 d-flex flex-column w-100 form-label">
                                    <span class=""><?php echo e(__('forms.profile.Gender')); ?>

                                        <span class="text-danger">*</span> </span>
                                    <select required class="myselect" name="gender">
                                        <option value="0" <?php echo e(($profile->gender ? $profile->gender : old('gender')) == 0
                                            ? 'selected' : ''); ?>>
                                            <?php echo e(__('forms.profile.Female')); ?></option>
                                        <option value="1 " <?php echo e(($profile->gender ? $profile->gender : old('gender')) == 1
                                            ? 'selected' : ''); ?>>
                                            <?php echo e(__('forms.profile.Male')); ?>

                                        </option>
                                        <option value="2" <?php echo e(($profile->gender ? $profile->gender : old('gender')) == 2
                                            ? 'selected' : ''); ?>>
                                            <?php echo e(__('forms.profile.Trans')); ?></option>
                                    </select>
                                </label>

                            </div>
                        </div>



                        <div class="col-12">

                            <label for="description" class="form-label w-100">
                                <p class="mx-2"><?php echo e(__('forms.profile.Description')); ?>

                                </p>
                                <textarea required name="description" id=""
                                    class="w-100 rounded  form-control"><?php echo e($profile->description ? $profile->description : old('description')); ?></textarea>
                            </label>

                        </div>
                        <div class="col-12 mt-5 ">
                            <h3 class="fs-3 fw-bold text-333 border-bottom border-mcolor w-100 pt-md-4 my-5"><?php echo e(__('forms.profile.Gallery')); ?>

                                <span class="mcolor text-sm"><i class="fas fa-question-circle"></i> Deberás solicitar una revisión de las fotos que subas para que sean visibles</span>
                            </h3>

                            <?php if($profile->Photos()->count() > 0): ?>
                            <label for="main_photo"><?php echo e(__('general.main_photo')); ?>

                                <div class="d-flex flex-wrap flex-lg-nowrap w-100">
                                    <?php $__currentLoopData = $profile->Photos(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="d-flex flex-column p-2">
                                        <img src="<?php echo e(asset("storage/escort_photos/$photo->path/$photo->filename")); ?>" data-render="<?php echo e($photo->id); ?>" class="mb-1 profile-image <?php if($photo->is_main): ?>profile-main-image <?php endif; ?>" alt="">
                                        <div class="d-flex justify-content-center">

                                        <a href="<?php echo e(route('delete-escort-image',$photo->id)); ?>" class="btn btn-danger "><i class="fa fa-trash" aria-hidden="true"></i></a>
                                        <?php if(!$photo->approved and !$photo->Review ): ?>
                                        <a href="<?php echo e(route('request-photo-review',$photo->id)); ?>" class="btn bg-purple text-white">
                                            <i class="far fa-check-circle"></i>
                                        </a>
                                        <?php elseif($photo->Review): ?>
                                        <span class="mcolor text-sm"><i class="fas fa-lock"></i> En revisión</span>
                                        <?php endif; ?>

                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>

                                <input  type="hidden" name="main_photo" value=" <?php if($profile->MainPhoto()): ?> <?php echo e($profile->MainPhoto()->id); ?>     <?php endif; ?>">


                            </label>

                            <?php endif; ?>

                            <input  type="file" name="photos[]" id="escort_photos"  multiple data-max-file-size="3MB">

                        </div>
                    </div>

                    <!-- Fin Basico -->



                    <!--Estetica -->
                    <div class="row mt-5">
                        <h3 class="fs-3 fw-bold text-333 border-bottom border-mcolor w-75 pt-2 pt-md-4 my-5">
                            <?php echo e(__('forms.profile.Estetic')); ?></h3>

                        <div class="col-12 ">
                            <div class="d-flex flex-wrap flex-md-nowrap w-100">
                                <label for="nationality_id" class="p-0 p-md-2 d-flex flex-column w-100 form-label">
                                    <span class=""><?php echo e(__('forms.profile.nationality')); ?>

                                        <span class="text-danger">*</span></span>
                                    <select required class="js-example-basic-single" name="nationality_id">
                                        <?php $nationalities= DB::table('nationalities')->get() ?>
                                        
                                        <?php $__currentLoopData = $nationalities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $origin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($origin->id); ?>" <?php echo e(($profile->nationality_id ?
                                            $profile->nationality_id : old('nationality_id')) == $origin->id ?
                                            'selected' : ''); ?>>
                                            <?php echo e(__("geodata.nationalities.$origin->name")); ?>

                                        </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </label>
                                <label for="ethnicity_id" class="p-0 p-md-2 d-flex flex-column w-100 form-label">
                                    <span class="m"><?php echo e(__('forms.profile.Ethnicity')); ?>

                                        <span class="text-danger">*</span></span>
                                    <select required class="js-example-basic-single" name="ethnicity_id">
                                        <?php $ethnies= DB::table('ethnicities')->get() ?>
                                        <?php $__currentLoopData = $ethnies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eth): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($eth->id); ?>" <?php echo e(($profile->ethnicity_id ?
                                            $profile->ethnicity_id : old('ethnicity_id')) == $eth->id ? 'selected' : ''); ?>>
                                            <?php echo e(__("forms.profile.$eth->name")); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </label>
                            </div>
                            <div class="d-flex flex-wrap flex-md-nowrap w-100">
                                <label for="eye_color_id" class="p-0 p-md-2 d-flex flex-column w-100 form-label">
                                    <span class=""><?php echo e(__('forms.profile.eye_color')); ?>

                                        <span class="text-danger">*</span></span>
                                    <select required class="js-example-basic-single" name="eye_color_id">
                                        <?php $eyecolors= DB::table('eye_colors')->get() ?>
                                        <?php $__currentLoopData = $eyecolors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ecolor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($ecolor->id); ?>" <?php echo e(($profile->eye_color_id ?
                                            $profile->eye_color_id : old('eye_color_id')) == $ecolor->id ? 'selected'
                                            : ''); ?>>
                                            <?php echo e(__("forms.profile.$ecolor->name")); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </label>

                                <label for="hair_color_id" class="p-0 p-md-2 d-flex flex-column w-100 form-label">
                                    <span class=""><?php echo e(__('forms.profile.Hair_color')); ?>

                                        <span class="text-danger">*</span></span>
                                    <select required class="js-example-basic-single" name="hair_color_id">
                                        <?php $hcolors= DB::table('hair_colors')->get() ?>
                                        <?php $__currentLoopData = $hcolors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hcolor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($hcolor->id); ?>" <?php echo e(($profile->hair_color_id ?
                                            $profile->hair_color_id : old('hair_color_id')) == $hcolor->id ? 'selected'
                                            : ''); ?>>
                                            <?php echo e(__("forms.profile.$hcolor->name")); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </label>
                            </div>
                        </div>

                    </div>


                    

                    
                    <div class="row mt-5">
                        <h3 class="fs-3 fw-bold text-333 border-bottom border-mcolor w-75 my-5">
                            <?php echo e(__('forms.profile.Measures')); ?></h3>

                        <div class="col-12 ">
                            <div class="d-flex flex-wrap flex-md-nowrap w-100">
                                <label for="age" class="p-0 p-md-2 d-flex flex-column w-100 form-label">
                                    <span class=""><?php echo e(__('forms.profile.age')); ?> <span
                                            class="text-danger">*</span></span>
                                    <select required class="js-example-basic-single" name="age" id="age-sel">
                                        <?php for($i = 18; $i < 45; $i++): ?> <option value="<?php echo e($i); ?>" <?php echo e(($profile->age ?
                                            $profile->age : old('age')) == $i ? 'selected' : ''); ?>>
                                            <?php echo e($i); ?>

                                            </option>
                                            <?php endfor; ?>
                                    </select>
                                </label>
                                <label for="height" class="p-0 p-md-2 d-flex flex-column w-100 form-label">
                                    <span class=""><?php echo e(__('forms.profile.height')); ?>

                                        <span class="text-danger">*</span></span>
                                    <select required class="js-example-basic-single" name="height">
                                        <?php for($j = 150; $j < 190; $j++): ?> <option value="<?php echo e($j); ?>" <?php echo e(($profile->height ?
                                            $profile->height : old('height')) == $j ? 'selected' : ''); ?>>
                                            <?php echo e($j); ?> cm</option>
                                            <?php endfor; ?>
                                    </select>
                                </label>
                                <label for="weight" class="p-0 p-md-2 d-flex flex-column w-100 form-label">
                                    <span class=""><?php echo e(__('forms.profile.weight')); ?>

                                        <span class="text-danger">*</span></span>
                                    <select required class="js-example-basic-single" name="weight">
                                        <?php for($k = 50; $k < 75; $k++): ?> <option value="<?php echo e($k); ?>" <?php echo e(($profile->weight ?
                                            $profile->weight : old('weight')) == $k ? 'selected' : ''); ?>>
                                            <?php echo e($k); ?> kg</option>
                                            <?php endfor; ?>
                                    </select>
                                </label>

                            </div>
                            <div class="w-100 d-flex flex-wrap flex-md-nowrap">

                                <label for="breast_size" class="p-0 p-md-2 d-flex flex-column w-100 form-label">
                                    <span class=""><?php echo e(__('forms.profile.breast_size')); ?>

                                        <span class="text-danger">*</span></span>
                                    <select required class="js-example-basic-single" name="breast_size">
                                        <?php for($l = 63; $l < 112; $l++): ?> <option value="<?php echo e($l); ?>" <?php echo e(($profile->
                                            breast_size ? $profile->breast_size : old('breast_size')) == $l ? 'selected'
                                            : ''); ?>>
                                            <?php echo e($l); ?> cm</option>
                                            <?php endfor; ?>
                                    </select>
                                </label>
                                <label for="breast_type" class="p-0 p-md-2 d-flex flex-column w-100 form-label">
                                    <span class=""><?php echo e(__('forms.profile.breast_type')); ?>

                                        <span class="text-danger">*</span></span>
                                    <select required class="js-example-basic-single" name="breast_type">
                                        <option value="0" <?php echo e(($profile->breast_type ? $profile->breast_type :
                                            old('breast_type')) == 0 ? 'selected' : ''); ?>>
                                            Natural
                                        </option>
                                        <option value="1" <?php echo e(($profile->breast_type ? $profile->breast_type :
                                            old('breast_type')) == 1 ? 'selected' : ''); ?>>
                                            Silicona
                                        </option>
                                    </select>
                                </label>
                            </div>
                        </div>

                    </div>


                    



                    
                    <div class="row mt-5">
                        <h3 class="fs-3 fw-bold text-333 border-bottom border-mcolor w-75 my-5">
                            <?php echo e(__('forms.profile.Additional')); ?></h3>
                        <div class=" col-12">
                            <div class="d-flex flex-wrap flex-md-nowrap w-100">
                                <label for="smoker" class="d-flex flex-column p-0 p-md-2 w-100 form-label">
                                    <span class=""><?php echo e(__('forms.profile.smoker')); ?>

                                        <span class="text-danger">*</span></span>
                                    <select required class="js-example-basic-single" name="smoker">
                                        <option value="0" <?php echo e(($profile->smoker ? $profile->smoker : old('smoker')) == 0
                                            ? 'selected' : ''); ?>>
                                            <?php echo e(__('general.No')); ?></option>
                                        <option value="1" <?php echo e(($profile->smoker ? $profile->smoker : old('smoker')) == 1
                                            ? 'selected' : ''); ?>>
                                            <?php echo e(__('general.Yes')); ?></option>
                                    </select>
                                </label>


                                <label for="" class="p-0 p-md-2 d-flex flex-column w-100 form-label">
                                    <span class="is_pornstar"><?php echo e(__('forms.profile.pornstar')); ?>

                                        <span class="text-danger">*</span></span>
                                    <select required class="js-example-basic-single" name="is_pornstar">
                                        <option value="0" <?php echo e(($profile->is_pornstar ? $profile->is_pornstar :
                                            old('is_pornstar')) == 0 ? 'selected' : ''); ?>>
                                            <?php echo e(__('general.No')); ?></option>
                                        <option value="1" <?php echo e(($profile->is_pornstar ? $profile->is_pornstar :
                                            old('is_pornstar')) == 1 ? 'selected' : ''); ?>>
                                            <?php echo e(__('general.Yes')); ?></option>
                                    </select>
                                </label>
                                <label for="sexual_orientation_id" class="p-0 p-md-2 d-flex flex-column w-100 form-label">
                                    <span class=""><?php echo e(__('forms.profile.orientation')); ?>

                                        <span class="text-danger">*</span></span>
                                    <select required class="js-example-basic-single" name="sexual_orientation_id">
                                        <?php $sorients= DB::table('sexual_orientations')->get() ?>
                                        <?php $__currentLoopData = $sorients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sorient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($sorient->id); ?>" <?php echo e(($profile->sexual_orientation_id ?
                                            $profile->sexual_orientation_id : old('sexual_orientation_id')) ==
                                            $sorient->id ? 'selected' : ''); ?>>
                                            <?php echo e(__("forms.profile.$sorient->name")); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </label>
                            </div>
                        </div>


                        <div class=" col-12">
                            <div class="d-flex flex-wrap flex-md-nowrap w-100">
                                <label for="private_apartament" class="d-flex flex-column p-0 p-md-2 w-100 form-label">
                                    <span class=""><?php echo e(__('forms.profile.private_apartament')); ?>

                                        <span class="text-danger">*</span></span>
                                    <select required class="js-example-basic-single" name="private_apartament">
                                        <option value="0" <?php echo e(($profile->private_apartament ? $profile->private_apartament : old('private_apartament')) == 0
                                            ? 'selected' : ''); ?>>
                                            <?php echo e(__('general.No')); ?></option>
                                        <option value="1" <?php echo e(($profile->private_apartament ? $profile->private_apartament : old('private_apartament')) == 1
                                            ? 'selected' : ''); ?>>
                                            <?php echo e(__('general.Yes')); ?></option>
                                    </select>
                                </label>


                                <label for="creditcard_acceptance" class="p-0 p-md-2 d-flex flex-column w-100 form-label">
                                    <span class="creditcard_acceptance"><?php echo e(__('forms.profile.creditcard_acceptance')); ?>

                                        <span class="text-danger">*</span></span>
                                    <select required class="js-example-basic-single" name="creditcard_acceptance">
                                        <option value="0" <?php echo e(($profile->creditcard_acceptance ? $profile->creditcard_acceptance :
                                            old('creditcard_acceptance')) == 0 ? 'selected' : ''); ?>>
                                            <?php echo e(__('general.No')); ?></option>
                                        <option value="1" <?php echo e(($profile->creditcard_acceptance ? $profile->creditcard_acceptance :
                                            old('creditcard_acceptance')) == 1 ? 'selected' : ''); ?>>
                                            <?php echo e(__('general.Yes')); ?></option>
                                    </select>
                                </label>

                                <label for="" class="p-0 p-md-2 d-flex flex-column w-100 form-label">
                                    <span class="whatsapp_acceptance"><?php echo e(__('forms.profile.whatsapp_acceptance')); ?>

                                        <span class="text-danger">*</span></span>
                                    <select required class="js-example-basic-single" name="whatsapp_acceptance">
                                        <option value="0" <?php echo e(($profile->whatsapp_acceptance ? $profile->whatsapp_acceptance :
                                            old('whatsapp_acceptance')) == 0 ? 'selected' : ''); ?>>
                                            <?php echo e(__('general.No')); ?></option>
                                        <option value="1" <?php echo e(($profile->whatsapp_acceptance ? $profile->whatsapp_acceptance :
                                            old('whatsapp_acceptance')) == 1 ? 'selected' : ''); ?>>
                                            <?php echo e(__('general.Yes')); ?></option>
                                    </select>
                                </label>

                            </div>
                        </div>

                        <div class="col-12">
                            <div>
                                <label for="languages[]" class="d-flex flex-column p-0 p-md-2 form-label">
                                    <span class=""><?php echo e(__('forms.profile.languages')); ?>

                                        <span class="text-danger">*</span></span>
                                    <select required class="js-example-basic-multiple w-100" name="languages[]" multiple>
                                        <?php $ulangs= DB::table('user_languages')->get() ?>
                                        <?php $__currentLoopData = $ulangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ulang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($ulang->id); ?>"
                                            <?php if($profile->languages): ?> <?php echo e(in_array($ulang->id,$profile->languages) ? 'selected' : ''); ?>

                                            <?php elseif(old('languages')): ?> <?php echo e(in_array($ulang->id,old('languages')) ? 'selected': ''); ?> <?php endif; ?>>
                                            <?php echo e(__("geodata.langs.$ulang->name")); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </label>
                            </div>
                        </div>
                    </div>


                    


                    
                    <div class="row mt-5">
                        <h3 class="fs-3 fw-bold text-333 border-bottom border-mcolor w-75 form-label my-5">
                            <?php echo e(__('forms.profile.services')); ?> <span class="text-danger">*</span></h3>

                        <div class="col-12 ">
                            <div class="d-flex flex-wrap p-0 p-md-2">

                                <?php $db_services= DB::table('services')->get() ?>

                                <?php $__currentLoopData = $db_services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $db_serv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label for="services" class="d-flex  mx-2 p-0 p-md-2 align-items-center form-label">

                                    <input   type="checkbox" value="<?php echo e($db_serv->id); ?>" name="services[]" class="rounded"
                                        style="appearance: auto"
                                            <?php if($profile->services): ?> <?php echo e(in_array($db_serv->id,$profile->services) ? 'checked' : ''); ?>

                                            <?php elseif(old('services')): ?> <?php echo e(in_array($db_serv->id,old('services')) ? 'checked': ''); ?> <?php endif; ?> >

                                    <span class="mx-1"><?php echo e(__("forms.services.$db_serv->name")); ?>

                                    </span>
                                </label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>


                    

                    
                    <div class="row mt-5">
                        <h3 class="fs-3 fw-bold text-333 border-bottom border-mcolor w-75 my-5">
                            <?php echo e(__('forms.prices.prices')); ?></h3>

                        <div class="col-12 ">
                            <div class="d-flex flex-wrap flex-md-nowrap">
                                <div class="w-100 ">
                                    <label for="half_hour_price" class="w-100 d-flex flex-column p-0 p-md-2 form-label">
                                        <span class="">
                                            <?php echo e(__('forms.prices.one_hour')); ?>

                                            <span class="text-danger">*</span></span>
                                        <input required  type="text" name="one_hour" class="form-control"
                                            value="<?php echo e($profile->Rates ? $profile->Rates->one_hour : old('one_hour')); ?>" />
                                    </label>
                                    <label for="" class="w-100  d-flex flex-column p-0 p-md-2 form-label">
                                        <span class=""> <?php echo e(__('forms.prices.added_hour')); ?>

                                            <span class="text-danger">*</span></span>
                                        <input required  type="text" name="added_hour" class="form-control"
                                            value="<?php echo e($profile->Rates ? $profile->Rates->added_hour : old('added_hour')); ?>" />
                                    </label>
                                </div>
                                <div class="w-100 ">
                                    <label for="weekend_price" class="w-100  d-flex flex-column p-0 p-md-2 form-label">
                                        <span class=""><?php echo e(__('forms.prices.half_day')); ?>

                                            <span class="text-danger">*</span></span>
                                        <input required  type="text" name="half_day" class="form-control"
                                            value="<?php echo e($profile->Rates  ? $profile->Rates->half_day : old('half_day')); ?>" />
                                    </label>
                                    <label for="day_price" class="w-100  d-flex flex-column p-0 p-md-2 form-label">
                                        <span class=""><?php echo e(__('forms.prices.one_day')); ?>

                                            <span class="text-danger">*</span></span>
                                        <input required  type="text" name="one_day" class="form-control"
                                            value="<?php echo e($profile->Rates ? $profile->Rates->one_day : old('one_day')); ?>" />
                                    </label>


                                </div>
                            </div>
                        </div>
                    </div>


                    

                    <!--Direccion -->
                    <div class="row mt-5">
                        <h3 class="fs-3 fw-bold text-333 border-bottom border-mcolor w-75 my-5">
                            <?php echo e(__('forms.profile.Address')); ?></h3>

                        <div class="col-12">
                            <div class="d-flex flex-wrap flex-md-nowrap w-100">
                                <label for="country_id" class="p-0 p-md-2 w-100 d-flex flex-column form-label">
                                    <span class=""><?php echo e(__('forms.profile.Country')); ?>

                                        <span class="text-danger">*</span></span>
                                    <select required class="js-example-basic-single w-100 " name="country_id"
                                        id="e-country-select">
                                        <?php $countries= DB::table('countries')->get() ?>
                                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($country->id); ?>" <?php echo e(($profile ? $profile->country_id :
                                            old('country_id')) == $country->id ? 'selected' : ''); ?>>
                                            <?php echo e(__("geodata.countries.$country->name")); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </label>
                                <label for="region_id" class="p-0 p-md-2 w-100 d-flex flex-column form-label">
                                    <span class="mx-2"><?php echo e(__('forms.profile.Region')); ?>

                                        <span class="text-danger">*</span></span>
                                    <select required class="js-example-basic-single w-100 " name="region_id"
                                        id="e-region-select">

                                        <?php if($profile->region_id): ?>
                                        <option value="<?php echo e($profile->region_id); ?>" selected>
                                            <?php echo e(DB::table('regions')->where('id', $profile->region_id)->first()->name); ?>

                                        </option>
                                        <?php elseif(old('region_id')): ?>
                                            <?php $regions= DB::table('regions')->get() ?>
                                            <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($region->id); ?>" <?php echo e(old('region_id')==$region->id ?'selected' :''); ?>>
                                                <?php echo e($region->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </label>
                                <label for="city_id" class="p-0 p-md-2 w-100 d-flex flex-column form-label">
                                    <span class="mx-2"><?php echo e(__('forms.profile.City')); ?>

                                        <span class="text-danger">*</span></span>
                                    <select required class="js-example-basic-single w-100 " name="city_id" id="e-cities-select">
                                        <?php if($profile->city_id): ?>
                                        <option value="<?php echo e($profile->city_id); ?>" selected>
                                            <?php echo e(DB::table('cities')->where('id', $profile->city_id)->first()->name); ?>

                                        </option>
                                        <?php elseif(old('city_id')): ?>
                                        <?php $cities= DB::table('cities')->get() ?>
                                        <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($city->id); ?>" <?php echo e(old('city_id')==$city->id ?'selected' :''); ?>>
                                            <?php echo e($city->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                    </select>
                                </label>
                            </div>

                            <div class="w-100 p-0 p-md-2">
                                <label for="address" class="w-100 form-label">
                                    <span><?php echo e(__('forms.profile.Address')); ?> <span class="text-danger">*</span></span>
                                    <input required  type="text" name="address" class="w-100"
                                        value="<?php echo e($profile->address ?? old('address')); ?>" />
                                </label>
                            </div>
                        </div>
                        <div class="col-12">
                            <label for="trave_range_id" class="p-0 p-md-2 w-100 d-flex flex-column form-label">
                                <span class=""><?php echo e(__('forms.profile.Travel')); ?> <span
                                        class="text-danger">*</span></span>
                                <select required class="js-example-basic-single" name="travel_range_id">
                                    <?php $tranges= DB::table('travel_ranges')->get() ?>

                                    <?php $__currentLoopData = $tranges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trange): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($trange->id); ?>" <?php echo e(($profile->travel_range_id ?
                                        $profile->travel_range_id : old('travel_range_id')) == $trange->id ? 'selected' : ''); ?>>
                                        <?php echo e(__("forms.profile.$trange->name")); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </label>
                        </div>
                        <div class="col-12">
                            
                        </div>
                    </div>
                    <!-- Fin Direccion -->

                    <div class="row mt-5">
                        <div class="p-0 p-md-2 text-center py-4 col-12 col-md-6 mx-auto d-flex">
                            <input type="submit" name="save"
                            class=" btn rounded w-100 bg-rosa text-white px-4 py-2 mx-auto btn-submit" value="<?php echo e(__('general.Save')); ?>">
                            <?php if(!$profile->ReviewRequest() && $profile->approved == 0 && $profile->can_be_reviewed == 1): ?>
                            <input type="submit"  name="save_review" class="btn rounded w-100 mcolor bg-white ml-2 px-4 py-2 border-mcolor"  value=" Guardar y <?php echo e(__('general.Request_review_title')); ?>">

                            <?php elseif($profile->ReviewRequest() && $profile->ReviewRequest()->status=='processed' ): ?>
                            <input type="submit"  name="save_review" class="btn rounded w-100 mcolor bg-white ml-2 px-4 py-2 border-mcolor"  value=" Guardar y <?php echo e(__('general.Request_review_title')); ?>">

                            <?php endif; ?>
                        </div>
                    </div>



                </form>
            </div>
        </div>
        <?php $__env->startPush('js'); ?>
        <script>

            $('.profile-image').on('click',function(){
                $('.profile-image').removeClass('profile-main-image');
                $(this).addClass('profile-main-image')
                let photo_id= $(this).attr('data-render');
                $('input[name=main_photo]').val(photo_id)
            });

        </script>

    <?php $__env->stopPush(); ?>
    </div>


 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/user/escort/escort-form.blade.php ENDPATH**/ ?>