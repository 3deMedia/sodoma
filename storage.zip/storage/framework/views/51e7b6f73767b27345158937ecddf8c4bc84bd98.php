<tr>
<td class="header">
<a href="<?php echo e($url); ?>" style="display: inline-block;">
<?php if(trim($slot) === 'Laravel'): ?>
<img loading="lazy"  src="https://laravel.com/img loading="lazy" /notification-logo.png" class="logo" alt="Laravel Logo">
<?php else: ?>
<?php echo e($slot); ?>

<?php endif; ?>
</a>
</td>
</tr>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/vendor/mail/html/header.blade.php ENDPATH**/ ?>