
<?php $attributes = $attributes->exceptProps(['page']); ?>
<?php foreach (array_filter((['page']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<form action="<?php echo e(route('admin-seo-update',$page->id)); ?>" method="POST"class="container">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="row">

<div class="col-2">
    <span> <?php echo e($page->view); ?></span>
</div>
<div class="col-3">
    <input type="text" name="seo_title" value="<?php echo e($page->seo_title); ?>" class="form-control"/>
</div>
<div class="col-3">
    <input type="text" name="seo_description" value="<?php echo e($page->seo_description); ?>" class="form-control"/>
</div>
<div class="col-3">
    <span> <?php echo e($page->explanation); ?></span>
</div>
<div class="col-1">
    <button type="submit" class=" btn btn-success"><i class="fas fa-save    "></i></button>
</div>
    </div>

</form>
<?php /**PATH C:\laragon\www\sodoma\resources\views/components/seo-page.blade.php ENDPATH**/ ?>