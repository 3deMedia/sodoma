<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php
    $active_tab = true;
    $active_tab_add = null;
    $active_tab_pending = null;
    $url= url()->full();
    if(str_contains($url,'add-escort')){
        $active_tab_add = true;
        $active_tab=false;
    }
    if(str_contains($url,'pending')){
        $active_tab_pending = true;
        $active_tab=false;
    }

?>
<div class="container-fluid" style="min-height: 70vh;">
    <div class="row mb-4">
        <div><h2 class="fw-bold mb-4 text-center">Tus Anuncios</h2></div>

        <p>Estos son todos los anuncios que tienes, activos, inactivos y pendientes. También puedes añadir un nuevo anuncio.</p>

    </div>
    <ul class="nav nav-tabs" id="myTab" role="tablist" class="w-100">
        <li class="nav-item " role="presentation">
            <button class="nav-link <?php if($active_tab): ?>active <?php endif; ?>" id="actived-tab" data-bs-toggle="tab" data-bs-target="#actived"
                type="button" role="tab" aria-controls="actived" aria-selected="<?php if($active_tab): ?>true <?php else: ?> false <?php endif; ?>">
              <span class="panel-link">  <?php echo e(__('agency.Active_escorts')); ?></span>
            </button>

        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link " id=inactive-tab" data-bs-toggle="tab" data-bs-target="#unactive" type="button"
                role="tab" aria-controls="inactive" aria-selected="false">
                <span class="panel-link"><?php echo e(__('agency.Deactivated_escorts')); ?></span>
            </button>

        </li>
        
        <li class="nav-item " role="presentation">
            <button class="nav-link <?php if($active_tab_pending): ?> active <?php endif; ?>" id="unapproved-tab" data-bs-toggle="tab" data-bs-target="#unapproved"
                type="button" role="tab" aria-controls="unapproved" aria-selected="<?php if($active_tab_pending): ?>true <?php else: ?> false <?php endif; ?>">
                <span class="panel-link"> <?php echo e(__('agency.Pending_escorts')); ?> </span>
            </button>

        </li>

        <li class="nav-item" role="presentation">
            <button class="nav-link nav-link-new <?php if($active_tab_add): ?> active <?php endif; ?>" id="newescort-tab" data-bs-toggle="tab" data-bs-target="#newescort"
                type="button" role="tab" aria-controls="newescort" aria-selected="<?php if($active_tab_add): ?> true <?php else: ?> false <?php endif; ?>">
               <span class="panel-link"><?php echo e(__('agency.addEscort')); ?></span>
            </button>

        </li>

    </ul>

    <div class="tab-content w-100" id="myEscortTabs">
        <div class="tab-pane fade <?php if($active_tab): ?> show active <?php endif; ?>" id="actived" role="tabpanel" aria-labelledby="actived-tab">

            <?php if($actived->count()): ?>
            <?php if (isset($component)) { $__componentOriginal5bb0425a8602ffb3d4badc48799e4bab8b302575 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ActiveEscorts::class, ['active' => $actived]); ?>
<?php $component->withName('active-escorts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal5bb0425a8602ffb3d4badc48799e4bab8b302575)): ?>
<?php $component = $__componentOriginal5bb0425a8602ffb3d4badc48799e4bab8b302575; ?>
<?php unset($__componentOriginal5bb0425a8602ffb3d4badc48799e4bab8b302575); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <?php else: ?>
            <p class="font-bold text-lg p-2 pt-5"><?php echo e(__('agency.No_escorts_in_list')); ?></p>

            <?php endif; ?>

        </div>
        <div class="tab-pane fade" id="unactive" role="tabpanel" aria-labelledby="unactive-tab">

            <?php if($unactive->count()): ?>
            <?php if (isset($component)) { $__componentOriginalc9f4168c74b35b95b3e6dc8a3752e27286bace1c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\InactiveEscorts::class, ['unactive' => $unactive]); ?>
<?php $component->withName('inactive-escorts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc9f4168c74b35b95b3e6dc8a3752e27286bace1c)): ?>
<?php $component = $__componentOriginalc9f4168c74b35b95b3e6dc8a3752e27286bace1c; ?>
<?php unset($__componentOriginalc9f4168c74b35b95b3e6dc8a3752e27286bace1c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <?php else: ?>
            <p class="font-bold text-lg p-2 pt-5"><?php echo e(__('agency.No_escorts_in_list')); ?></p>

            <?php endif; ?>
        </div>
        <div class="tab-pane fade <?php if($active_tab_pending): ?> show active <?php endif; ?>" id="unapproved" role="tabpanel" aria-labelledby="unapproved-tab">

            <?php if($pending->count()): ?>
            <?php if (isset($component)) { $__componentOriginal419832204025124a7cfd9237e01f970da205f5e4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\PendingEscorts::class, ['pending' => $pending]); ?>
<?php $component->withName('pending-escorts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal419832204025124a7cfd9237e01f970da205f5e4)): ?>
<?php $component = $__componentOriginal419832204025124a7cfd9237e01f970da205f5e4; ?>
<?php unset($__componentOriginal419832204025124a7cfd9237e01f970da205f5e4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <?php else: ?>
            <p class="font-bold text-lg p-2 pt-5"><?php echo e(__('agency.No_escorts_in_list')); ?></p>

            <?php endif; ?>
        </div>
        <div class="tab-pane fade <?php if($active_tab_add): ?> show active <?php endif; ?>" id="newescort" role="tabpanel" aria-labelledby="newescort-tab">
            <?php if($can_purchase): ?>

            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.forms.create-escort','data' => ['admin' => false,'agency' => $profile->id]]); ?>
<?php $component->withName('forms.create-escort'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['admin' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false),'agency' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($profile->id)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <?php else: ?>
            <p class="font-bold text-lg p-2 pt-5">
            <?php echo e(__('general.needs_profile_or_coins')); ?>

            </p>
            <?php endif; ?>

        </div>
    </div>
</div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/user/agency/agency-escorts-tabpanel.blade.php ENDPATH**/ ?>