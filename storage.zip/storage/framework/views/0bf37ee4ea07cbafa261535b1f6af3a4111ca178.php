<nav class="navbar navbar-vertical fixed-left navbar-expand-md navbar-light bg-white" id="sidenav-main">
    <div class="container-fluid">
        <!-- Toggler -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <!-- Brand -->
        <a class="navbar-brand pt-0" href="<?php echo e(route('home')); ?>">
            <img src="<?php echo e(asset('images/escortssecrets-logo.jpg')); ?>" alt="Escorts Secrets" />
        </a>
        <!-- User -->
        <ul class="nav align-items-center d-md-none">
            <li class="nav-item dropdown">
                <a class="nav-link" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <div class="media align-items-center">
                        <span class="avatar avatar-sm rounded-circle">
                        <img loading="lazy"  alt="escorts secrets" src="<?php echo e(asset('images/coin-icon-black.png')); ?>">
                        </span>
                    </div>
                </a>
                <div class="dropdown-menu dropdown-menu-arrow dropdown-menu-right">
                    <div class=" dropdown-header noti-title">
                        <h6 class="text-overflow m-0"><?php echo e(__('Cuenta')); ?></h6>
                    </div>
                    <a href="#" class="dropdown-item">
                        <i class="ni ni-single-02"></i>
                        <span><?php echo e(__('My account')); ?></span>
                    </a>

                    <a href="#" class="dropdown-item">
                        <i class="ni ni-support-16"></i>
                        <span><?php echo e(__('Support')); ?></span>
                    </a>
                    <div class="dropdown-divider"></div>
                    <a href="<?php echo e(route('logout')); ?>" class="dropdown-item" onclick="event.preventDefault();
                    document.getElementById('logout-form').submit();">
                        <i class="ni ni-user-run"></i>
                        <span><?php echo e(__('Logout')); ?></span>
                    </a>
                </div>
            </li>
        </ul>
        <!-- Collapse -->
        <div class="collapse navbar-collapse" id="sidenav-collapse-main">
            <!-- Collapse header -->
            <div class="navbar-collapse-header d-md-none">
                <div class="row">
                    <div class="col-6 collapse-brand">
                        <a href="<?php echo e(route('home')); ?>">
                            <img src="<?php echo e(asset('images/escortssecrets-logo.jpg')); ?>" alt="Escorts Secrets">
                        </a>
                    </div>
                    <div class="col-6 collapse-close">
                        <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle sidenav">
                            <span></span>
                            <span></span>
                        </button>
                    </div>
                </div>
            </div>
            <!-- Form -->
            <form class="mt-4 mb-3 d-md-none">
                <div class="input-group input-group-rounded input-group-merge">
                    <input type="search" class="form-control form-control-rounded form-control-prepended" placeholder="<?php echo e(__('Search')); ?>" aria-label="Search">
                    <div class="input-group-prepend">
                        <div class="input-group-text">
                            <span class="fa fa-search"></span>
                        </div>
                    </div>
                </div>
            </form>
            <!-- Navigation -->
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('admin-dashboard')); ?>">
                        <i class="ni ni-tv-2 text-primary"></i> <?php echo e(__('Panel')); ?>

                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('admin-users')); ?>">
                        <i class="fa fa-user-circle text-blue" aria-hidden="true"></i> <?php echo e(__('Users')); ?>

                    </a>
                </li>
                <li class="nav-item ">
                    <a class="nav-link" href="<?php echo e(route('admin-profiles',['type'=>1])); ?>" >
                        <i class="fas fa-chess-king mcolor"></i>
                        <span class="nav-link-text" ><?php echo e(__('Escorts')); ?></span>
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('admin-profiles',['type'=>2])); ?>">
                        <i class="fas fa-building text-blue"></i>
                        <span class="nav-link-text" ><?php echo e(__('Agencies')); ?></span>
                    </a>
                </li>
                <li class="nav-item ">
                    <a class="nav-link" href="<?php echo e(route('admin-revisions')); ?>">
                        <i class="fas fa-eye text-purple"></i> <?php echo e(__('Revisiones')); ?>

                    </a>
                </li>

                

                <li class="nav-item ">
                    <a class="nav-link" href="<?php echo e(route('admin-photo-revisions')); ?>">
                        <i class="fas fa-image text-yellow"></i> <?php echo e(__('Revi Photos')); ?>

                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('admin-payments')); ?>">
                        <i class="far fa-credit-card text-green"></i>
                      <span class="nav-link-text"> <?php echo e(__('Payments')); ?></span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('admin-texts')); ?>">
                        <i class="fab fa-google text-black"></i>
                      <span class="nav-link-text"> Textos </span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('admin-seo')); ?>">
                        <i class="fab fa-google text-black"></i>
                      <span class="nav-link-text"> <?php echo e(__('Seo')); ?></span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('posts.index')); ?>">
                        <i class="far fa-newspaper text-orange"></i>
                      <span class="nav-link-text"> <?php echo e(__('Posts')); ?></span>
                    </a>
                </li>


            </ul>
            <!-- Divider -->

        </div>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>