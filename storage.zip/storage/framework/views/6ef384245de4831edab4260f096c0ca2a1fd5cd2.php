<div>
    <textarea id="myeditorinstance" name="content">
        <?php if(isset($content)): ?> <?php echo e($content); ?> <?php endif; ?>

    </textarea>
</div>
<?php /**PATH C:\laragon\www\sodoma\resources\views/components/forms/tinymce-editor.blade.php ENDPATH**/ ?>