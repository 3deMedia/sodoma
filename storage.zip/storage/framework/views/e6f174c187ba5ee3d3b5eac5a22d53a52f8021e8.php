<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <div class="container pb-5">


            <h2 class="fw-bold mb-6 text-center"><?php echo e(__('general.Hello')); ?> <?php echo e($profile->name); ?></h2>


            <div class="col-12 col-md-8 col-lg-6 mt-2 mt-md-5 bg-white rounded-md block center px-4 py-4">
                <div style="float: right"><span class="coinsleft"><?php echo e($coins); ?></span><br /><span class="saldoleft">saldo</span></div>
                                <p><strong>Anuncio: </strong> <i class="fa fa-circle text-green"></i> Activo</p>
                <p><strong>Renovación:</strong> 22/02/2022</p>
            </div>
            <div class="col-12 col-md-6 mt-2 mt-md-5 bg-white rounded-md block center px-4 py-4 border-black border-1">
                <h5 class="text-center">Actualmente tienes<br /><?php echo e(auth()->user()->coins); ?> € de Saldo</h5>
                <p class="text-center mb-5">Para publicar o renovar tu anuncio tienes que disponer de saldo suficiente en tu cuenta, de lo contrario los anuncios se detendrán. Compra saldo ahora.</p>
                <div class="text-center mb-5"><a href="<?php echo e(route('buy-coins')); ?>" class="butbuycoins"><i class="fa fa-coins text-xl pr-3"></i> Comprar Saldo</a></div>
                <div class="text-center mb-5"><a href="<?php echo e(route('my-profile')); ?>" class="butbuycoins"><i class="fa fa-image text-xl pr-3"></i> <?php echo e(__('general.PublishAd')); ?></a></div>
                <div class="text-center mb-5"><a href="<?php echo e(route('payments')); ?>" class="butbuycoins"><i class="fa fa-receipt text-xl pr-3"></i> <?php echo e(__('general.Payments')); ?></a></div>
                <div class="text-center mb-5"><a href="<?php echo e(route('changepassword')); ?>" class="butchangepass"><i class="fa fa-lock text-xl pr-3"></i> <?php echo e(__('general.Change Password')); ?></a></div>
                <div class="text-center mb-3"><a href="<?php echo e(route('logout')); ?>" class="butclose" onclick="event.preventDefault();
                    document.getElementById('logout-form').submit();"><i class="fa fa-power-off text-xl pr-3"></i> <?php echo e(__('general.Logout')); ?></a></div>
            </div>


    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/user/agency/account.blade.php ENDPATH**/ ?>