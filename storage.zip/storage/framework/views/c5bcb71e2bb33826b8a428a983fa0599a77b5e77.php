<div>

    <?php if($admin): ?>
    <form action="<?php echo e(route('admin-profile-store')); ?>" method="post" autocomplete="off"
    enctype="multipart/form-data" id="Escortform">
    <?php elseif($agency): ?>
    <form action="<?php echo e(route('agency.store.escort')); ?>" method="post" autocomplete="off"
    enctype="multipart/form-data" id="NewEscortForm" class="container py-4">
    <?php else: ?>
    <form action="<?php echo e(route('profile.store')); ?>" method="post" autocomplete="off"
    enctype="multipart/form-data" id="NewEscortForm" class="container py-4">
    <?php endif; ?>


    <?php echo csrf_field(); ?>

    <?php if($admin): ?>
        <input type="hidden" name="user_type_id" value="1">
    <?php endif; ?>
    <?php if($agency): ?>
        <input type="hidden" name="for_profile" value="<?php echo e($agency); ?>">
    <?php endif; ?>
        

        <div class="row">
            <h3 class="fs-3 fs-md-1 fw-bold text-mgray border-bottom border-mcolor"><?php echo e(__('forms.profile.Basic')); ?>

            </h3>
            <div class="col-12 d-flex flex-wrap flex-md-nowrap">
                <div class="d-flex flex-wrap w-100">
                    <label for="" class="p-2 d-flex flex-column w-100 form-label">
                        <span class=""><?php echo e(__('forms.profile.Name')); ?> <span
                                class="text-danger">*</span></span>
                        <input required  type="text" name="name" class="form-control"
                            value="<?php echo e(old('name')); ?>" />
                    </label>
                    <label for="" class="p-2 d-flex flex-column w-100 form-label">
                        <span class=""><?php echo e(__('forms.profile.Phone')); ?> <span
                                class="text-danger">*</span></span>
                        <input required  type="text" name="phone" class="form-control"
                        <?php if($agency): ?>
                        <?php
                            $phone= \App\Models\Profile::find($agency)->phone
                        ?>
                        value="<?php echo e($phone); ?>"
                        <?php else: ?>
                        value="<?php echo e(old('phone')); ?>"
                        <?php endif; ?>
                        />
                    </label>
                </div>
                <div class="d-flex flex-wrap w-100">
                    <label for="email" class="p-2 d-flex flex-column w-100 form-label">
                        <span class=""><?php echo e(__('forms.profile.Email')); ?></span>
                        <input required  type="text" name="email"
                        <?php if($agency): ?>
                        <?php
                            $email= \App\Models\Profile::find($agency)->email
                        ?>
                        value="<?php echo e($email); ?>"
                        <?php else: ?>
                            value="<?php echo e(old('email')); ?>"
                        <?php endif; ?>
                            class="form-control" />
                    </label>

                    <label for="email" class="p-2 d-flex flex-column w-100 form-label">
                        <span class=""><?php echo e(__('forms.profile.Gender')); ?> <span class="text-danger">*</span>
                        </span>
                        <select required class="form-control" name="gender">
                            <option value="0" <?php echo e(old('gender')==0 ? 'selected' : ''); ?>>
                                <?php echo e(__('forms.profile.Female')); ?></option>
                            <option value="1 " <?php echo e(old('gender')==1 ? 'selected' : ''); ?>>
                                <?php echo e(__('forms.profile.Male')); ?>

                            </option>
                            <option value="2" <?php echo e(old('gender')==2 ? 'selected' : ''); ?>>
                                <?php echo e(__('forms.profile.Trans')); ?></option>
                        </select>
                    </label>

                </div>
            </div>



            <div class="col-12">
                <label for="" class="w-100">
                    <p class=""><?php echo e(__('forms.profile.Description')); ?> <span class="text-red">*</span></p>
                    <textarea required name="description"
                        class="w-100 rounded"><?php echo e(old('description')); ?></textarea>
                </label>
            </div>
        </div>
        

         
        <div class="row">
            <div class="col-12">
                <h3 class="fs-3 fw-bold border-bottom border-mcolor w-100"><?php echo e(__('forms.profile.Gallery')); ?>

                    <span class="text-danger">*</span></h3>
                    <br>
                <script>
                    const gallery_source = null;
                </script>
                <input required  type="file" name="photos[]" id="escort_photos" accept="image/png, image/jpg, image/jpeg" multiple
                class="w-100">
            </div>
        </div>

        

        
        <div class="row">
            <h3 class="fs-3 fs-md-1 fw-bold text-mgray border-bottom border-mcolor">
                <?php echo e(__('forms.profile.Estetic')); ?></h3>

            <div class="col-12">

                <div class=" d-flex flex-wrap flex-md-nowrap">
                    <label for="" class="p-2 d-flex flex-column w-100 form-label">
                        <span class=""><?php echo e(__('forms.profile.nationality')); ?></span>
                        
                        <select required class="js-example-basic-single" name="nationality_id">
                            <?php $nationalities= DB::table('nationalities')->get() ?>
                             
                            <option value="null">Sin definir</option>

                            <?php $__currentLoopData = $nationalities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $origin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($origin->id); ?>" <?php echo e(old('nationality_id')==$origin->id ? 'selected':''); ?>>
                                <?php echo e(__("geodata.nationalities.$origin->name")); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </label>
                    <label for="" class="p-2 d-flex flex-column w-100 form-label">
                        <span class="m"><?php echo e(__('forms.profile.Ethnicity')); ?> <span
                                class="text-danger">*</span></span>
                        <select required class="js-example-basic-single" name="ethnicity_id">
                            <?php $ethnies= DB::table('ethnicities')->get() ?>
                            <?php $__currentLoopData = $ethnies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eth): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($eth->id); ?>" <?php echo e(old('ethnicity_id')==$eth->id ? 'selected' :''); ?>>
                                <?php echo e(__("forms.profile.$eth->name")); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </label>
                </div>

                <div class="d-flex flex-wrap flex-md-nowrap">
                    <label for="" class="p-2 d-flex flex-column w-100 form-label">
                        <span class=""><?php echo e(__('forms.profile.eye_color')); ?> <span
                                class="text-danger">*</span></span>
                        <select required class="js-example-basic-single" name="eye_color_id">
                            <?php $eyecolors= DB::table('eye_colors')->get() ?>
                            <?php $__currentLoopData = $eyecolors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ecolor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($ecolor->id); ?>" <?php echo e(old('eye_color_id')==$ecolor->id ? 'selected': ''); ?>>
                                <?php echo e(__("forms.profile.$ecolor->name")); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </label>

                    <label for="" class="p-2 d-flex flex-column w-100 form-label">
                        <span class=""><?php echo e(__('forms.profile.Hair_color')); ?> <span
                                class="text-danger">*</span></span>
                        <select required class="js-example-basic-single" name="hair_color_id">
                            <?php $hcolors= DB::table('hair_colors')->get() ?>
                            <?php $__currentLoopData = $hcolors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hcolor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($hcolor->id); ?>" <?php echo e(old('hair_color_id')==$hcolor->id ? 'selected': ''); ?>>
                                <?php echo e(__("forms.profile.$hcolor->name")); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </label>
                </div>
            </div>
        </div>

         

        


        <div class="row">
            <h3 class="fs-3 fs-md-1 fw-bold text-mgray border-bottom border-mcolor col-12">
                <?php echo e(__('forms.profile.Measures')); ?></h3>
            <div class="col-12">
                <div class="d-flex flex-wrap flex-md-nowrap w-100">
                    <label for="" class="p-2 d-flex flex-column w-100 form-label">
                        <span class=""><?php echo e(__('forms.profile.age')); ?> <span
                                class="text-danger">*</span></span>
                        <select required class="js-example-basic-single" name="age" id="age-sel">
                            <?php for($i = 18; $i < 45; $i++): ?> <option value="<?php echo e($i); ?>" <?php echo e(old('age')==$i
                                ? 'selected' : ''); ?>>
                                <?php echo e($i); ?>

                                </option>
                                <?php endfor; ?>
                        </select>
                    </label>
                    <label for="" class="p-2 d-flex flex-column w-100 form-label">
                        <span class=""><?php echo e(__('forms.profile.height')); ?>

                            <span class="text-danger">*</span></span>
                        <select required class="js-example-basic-single" name="height">
                            <?php for($j = 150; $j < 190; $j++): ?> <option value="<?php echo e($j); ?>" <?php echo e(old('height')==$j
                                ? 'selected' : ''); ?>>
                                <?php echo e($j); ?> cm</option>
                                <?php endfor; ?>
                        </select>
                    </label>
                    <label for="" class="p-2 d-flex flex-column w-100 form-label">
                        <span class=""><?php echo e(__('forms.profile.weight')); ?>

                            <span class="text-danger">*</span></span>
                        <select required class="js-example-basic-single" name="weight">
                            <?php for($k = 50; $k < 75; $k++): ?> <option value="<?php echo e($k); ?>" <?php echo e(old('weight')==$k
                                ? 'selected' : ''); ?>>
                                <?php echo e($k); ?> kg</option>
                                <?php endfor; ?>
                        </select>
                    </label>

                </div>
                <div class="w-100 d-flex flex-wrap flex-md-nowrap">

                    <label for="" class="p-2 d-flex flex-column w-100 form-label">
                        <span class=""><?php echo e(__('forms.profile.breast_size')); ?>

                            <span class="text-danger">*</span></span>
                        <select required class="js-example-basic-single" name="breast_size">
                            <?php for($l = 63; $l < 112; $l++): ?> <option value="<?php echo e($l); ?>" <?php echo e(old('breast_size')==$l
                                ? 'selected' : ''); ?>>
                                <?php echo e($l); ?> cm</option>
                                <?php endfor; ?>
                        </select>
                    </label>
                    <label for="" class="p-2 d-flex flex-column w-100 form-label">
                        <span class=""><?php echo e(__('forms.profile.breast_type')); ?>

                            <span class="text-danger">*</span></span>
                        <select required class="js-example-basic-single" name="breast_type">
                            <option value="0" <?php echo e(old('breast_type')==0 ? 'selected' : ''); ?>>
                                -
                            </option>
                            <option value="1" <?php echo e(old('breast_type')==1 ? 'selected' : ''); ?>>
                                Natural
                            </option>
                        </select>
                    </label>
                </div>
            </div>
        </div>

         
        <div class="row mt-5">
            <h3 class="fs-3 fw-bold text-333 border-bottom border-mcolor w-75 my-5">
                <?php echo e(__('forms.profile.Additional')); ?></h3>
            <div class=" col-12">
                <div class="d-flex flex-wrap flex-md-nowrap w-100">
                    <label for="smoker" class="d-flex flex-column p-0 p-md-2 w-100 form-label">
                        <span class=""><?php echo e(__('forms.profile.smoker')); ?></span>
                            <p id="radiooptions" class="mt-3">
                                <label><input type="radio" name="smoker" value="0" <?php echo e(old('smoker') == 0 ? 'checked' : ''); ?>>
                                    <span><?php echo e(__('general.No')); ?></span></label>
                                <label><input type="radio" name="smoker" value="1" <?php echo e(old('smoker') == 1 ? 'checked' : ''); ?>>
                                    <span><?php echo e(__('general.Yes')); ?></span></label>
                            </p>
                    </label>
                    <label for="private_apartament" class="d-flex flex-column p-0 p-md-2 w-100 form-label">
                        <span class=""><?php echo e(__('forms.profile.private_apartament')); ?></span>
                        <p id="radiooptions" class="mt-3">
                            <label><input type="radio" name="private_apartament" value="0" <?php echo e(old('private_apartament')  == 0 ? 'checked' : ''); ?>>
                                <span><?php echo e(__('general.No')); ?></span></label>
                            <label><input type="radio" name="private_apartament" value="1" <?php echo e(old('private_apartament')  == 1 ? 'checked' : ''); ?>>
                                <span><?php echo e(__('general.Yes')); ?></span></label>
                        </p>
                    </label>
                </div>
            </div>
            <div class=" col-12">
                <div class="d-flex flex-wrap flex-md-nowrap w-100">
                    <label for="" class="p-0 p-md-2 d-flex flex-column w-100 form-label">
                        <span class="whatsapp_acceptance"><?php echo e(__('forms.profile.whatsapp_acceptance')); ?></span>
                        <p id="radiooptions" class="mt-3">
                            <label><input type="radio" name="whatsapp_acceptance" value="0" <?php echo e(old('whatsapp_acceptance')  == 0 ? 'checked' : ''); ?>>
                                <span><?php echo e(__('general.No')); ?></span></label>
                            <label><input type="radio" name="whatsapp_acceptance" value="1" <?php echo e(old('whatsapp_acceptance')  == 1 ? 'checked' : ''); ?>>
                                <span><?php echo e(__('general.Yes')); ?></span></label>
                        </p>
                    </label>
                    <label for="creditcard_acceptance" class="p-0 p-md-2 d-flex flex-column w-100 form-label">
                        <span class="creditcard_acceptance"><?php echo e(__('forms.profile.creditcard_acceptance')); ?></span>
                        <p id="radiooptions" class="mt-3">
                            <label><input type="radio" name="creditcard_acceptance" value="0" <?php echo e(old('creditcard_acceptance') == 0 ? 'checked' : ''); ?>>
                                <span><?php echo e(__('general.No')); ?></span></label>
                            <label><input type="radio" name="creditcard_acceptance" value="1" <?php echo e(old('creditcard_acceptance') == 1 ? 'checked' : ''); ?>>
                                <span><?php echo e(__('general.Yes')); ?></span></label>
                        </p>
                    </label>
                </div>
            </div>
            <div class=" col-12">
                <div class="d-flex flex-wrap flex-md-nowrap w-100">
                    <label for="is_pornstar" class="p-0 p-md-2 d-flex flex-column w-100 form-label">
                        <span class="is_pornstar"><?php echo e(__('forms.profile.bizum')); ?></span>
                            <p id="radiooptions" class="mt-3">
                                <label><input type="radio" name="is_pornstar" value="0" <?php echo e(old('is_pornstar') == 0 ? 'checked' : ''); ?>>
                                    <span><?php echo e(__('general.No')); ?></span></label>
                                <label><input type="radio" name="is_pornstar" value="1" <?php echo e(old('is_pornstar')  == 1 ? 'checked' : ''); ?>>
                                    <span><?php echo e(__('general.Yes')); ?></span></label>
                            </p>
                    </label>
            </div>
            </div>


            <div class="col-12">
                <div>

                    <label for="languages[]" class="d-flex flex-column p-0 p-md-2 form-label">
                        <span class=""><?php echo e(__('forms.profile.languages')); ?>

                            <span class="text-danger">*</span></span>
                        <select required class="js-example-basic-multiple w-100" name="languages[]" multiple>
                            <?php $ulangs= DB::table('user_languages')->get() ?>
                            <?php $__currentLoopData = $ulangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ulang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($ulang->id); ?>" <?php if(old('languages')): ?> <?php echo e(in_array($ulang->id,old('languages')) ? 'selected': ''); ?> <?php endif; ?>>
                                <?php echo e(__("geodata.langs.$ulang->name")); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </label>
                </div>
            </div>
        </div>


        


        

        <div class="row">
            <h3 class="fs-3 fs-md-1 fw-bold text-mgray border-bottom border-mcolor col-12">
                <?php echo e(__('forms.profile.services')); ?> <span class="text-danger">*</span></h3>
            <div class="col-12">
                <div class="d-flex flex-wrap p-2">

                    <?php $db_services= DB::table('services')->get() ?>

                    <?php $__currentLoopData = $db_services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $db_serv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label class="d-flex  mx-2 p-2 align-items-center form-label">

                        <input   type="checkbox" value="<?php echo e($db_serv->id); ?>" name="services[]"
                            <?php if(old('services')): ?> <?php echo e(in_array( $db_serv->id ,old('services')) ? 'checked': ''); ?>

                        <?php endif; ?>
                        class="rounded"
                        />
                        &nbsp;
                        <span class="mx-1"><?php echo e(__("forms.services.$db_serv->name")); ?></span>
                    </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>

        


        

        <div class="row">
            <h3 class="fs-3 fs-md-1 fw-bold text-mgray border-bottom border-mcolor col-12">
                <?php echo e(__('forms.prices.prices')); ?></h3>
            <div class="col-12">
                <div class="d-flex flex-wrap flex-md-nowrap">
                    <div class="w-100 ">
                        <label for="half_hour" class="w-100 d-flex flex-column p-2 form-label">
                            <span class="">
                                <?php echo e(__('forms.prices.half_hour')); ?>

                                <span class="text-danger">*</span></span>
                            <input required  type="text" name="half_hour" class="form-control"
                                value="<?php echo e(old('half_hour')); ?>" />
                        </label>
                        <label for="one_hour" class="w-100  d-flex flex-column p-2 form-label">
                            <span class=""> <?php echo e(__('forms.prices.one_hour')); ?>

                                <span class="text-danger">*</span></span>
                            <input required  type="text" name="one_hour" class="form-control"
                                value="<?php echo e(old('one_hour')); ?>" />
                        </label>
                        <label for="added_hour" class="w-100  d-flex flex-column p-2 form-label">
                            <span class=""> <?php echo e(__('forms.prices.added_hour')); ?>

                                <span class="text-danger">*</span></span>
                            <input required  type="text" name="added_hour" class="form-control"
                                value="<?php echo e(old('added_hour')); ?>" />
                        </label>
                    </div>
                    <div class="w-100 ">
                        <label for="half_day" class="w-100  d-flex flex-column p-2 form-label">
                            <span class=""><?php echo e(__('forms.prices.half_day')); ?>

                                <span class="text-danger">*</span></span>
                            <input required  type="text" name="half_day" class="form-control"
                                value="<?php echo e(old('half_day')); ?>" />
                        </label>
                        <label for="one_day" class="w-100  d-flex flex-column p-2 form-label">
                            <span class=""><?php echo e(__('forms.prices.one_day')); ?>

                                <span class="text-danger">*</span></span>
                            <input required  type="text" name="one_day" class="form-control"
                                value="<?php echo e(old('one_day')); ?>" />
                        </label>
                    </div>
                </div>
            </div>
        </div>

        

        
        <div class="row">
            <div class="col-12 ">
                <h3 class="fs-3 fs-md-1 fw-bold text-mgray border-bottom border-mcolor"><?php echo e(__('forms.profile.Address')); ?></h3>
                <div class="w-100">
                    <label for="" class="w-100 d-flex flex-column">
                        <span class=""><?php echo e(__('forms.profile.Travel')); ?> <span
                                class="text-danger">*</span></span>
                        <select required class="js-example-basic-single" name="travel_range_id">
                            <?php $tranges= DB::table('travel_ranges')->get() ?>

                            <?php $__currentLoopData = $tranges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trange): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($trange->id); ?>" <?php echo e(old('travel_range_id')==$trange->id ? 'selected' : ''); ?>>
                                <?php echo e(__("forms.profile.$trange->name")); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </label>
                </div>

                <div class="d-flex flex-wrap flex-md-nowrap">

                    <label for="" class="d-flex flex-column w-100 p-2">
                        <span class=""><?php echo e(__('forms.profile.Country')); ?> <span
                                class="text-danger">*</span></span>
                        <select required class="js-example-basic-single w-full " name="country_id"
                            id="e-country-select">
                            <?php $countries= DB::table('countries')->get() ?>
                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($country->id); ?>" <?php echo e(old('country_id')==$country->id ?'selected' : ''); ?>>
                                <?php echo e(__("geodata.countries.$country->name")); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </label>
                    <label for="" class="d-flex flex-column w-100 p-2">
                        <span class="mx-2"><?php echo e(__('forms.profile.Region')); ?> <span
                                class="text-danger">*</span></span>
                        <select required class="js-example-basic-single w-full " name="region_id"
                            id="e-region-select">

                            <?php if(old('region_id')): ?>
                                <option value="<?php echo e(old('region_id')); ?>" selected>
                                    <?php echo e(DB::table('regions')->where('id',intval(old('region_id')))->first()->name); ?>

                                </option>
                            <?php endif; ?>
                        </select>
                    </label>
                    <label for="" class="d-flex flex-column w-100 p-2">
                        <span class="mx-2"><?php echo e(__('forms.profile.City')); ?> <span
                                class="text-danger">*</span></span>
                        <select required class="js-example-basic-single w-full " name="city_id"
                            id="e-cities-select">
                            <?php if(old('city_id')): ?>
                                <option value="<?php echo e(old('city_id')); ?>" selected>
                                    <?php echo e(DB::table('cities')->where('id', intval(old('city_id')))->first()->name); ?>

                                </option>
                            <?php endif; ?>
                        </select>
                    </label>
                </div>

                <div class="w-100 py-2">
                    <label for="" class="flex-column w-100">
                        <span class="form-label"><?php echo e(__('forms.profile.Address')); ?> <span
                                class="text-danger">*</span></span>
                        <input required  type="text" name="address" class="form-control"
                            value="<?php echo e(old('address')); ?>" />
                    </label>
                </div>

            </div>
        </div>

        <div class="row">
            <div class="col-12">
                <button type="submit"
                class="btn rounded w-100 bg-rosa text-white px-4 py-2 mx-auto btn-submit"><?php echo e(__('general.Create')); ?></button>
            </div>
        </div>
</form>
</div>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/components/forms/create-escort.blade.php ENDPATH**/ ?>