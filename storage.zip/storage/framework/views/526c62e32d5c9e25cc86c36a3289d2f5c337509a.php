    <div class="container">

      <h2>También puede interesarte</h2>
      <?php $__currentLoopData = $grouped_escorts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $escort_group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="row my-4">
          <div class="col-12 d-flex flex-wrap px-0">
              <?php $__currentLoopData = $escort_group->shuffle(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scrt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <?php
                      $mainPhoto = $scrt->MainPhoto();

                  ?>
                      <div class="p-2 rounded text-center profile-view">
                          <div class="bg-white">
                              <a href="<?php echo e(route('show-escorts', [$scrt->Address->City->slug,$scrt->uid])); ?>" class="w-100 ">
                                  <div style="width: 100%; position: relative;"  class="<?php if($scrt->is_vip): ?> corner <?php endif; ?>" >
                                      <div  <?php if($scrt->verified): ?> class="verified" <?php endif; ?>>

                                      <img loading="lazy" src='<?php echo e(asset("storage/escort_photos/$mainPhoto->path/$mainPhoto->filename")); ?>' alt="<?php echo e($scrt->name); ?>" />
                                  </div>

                                  </div>
                              </a>
                              <p class="profile-name"><?php echo e($scrt->name); ?> <br /><span class="profile-under">
                                   <?php if(!empty($scrt->Features->age)): ?> <i class="fa fa-square-full icosquare"></i> <?php echo e($scrt->Features->age); ?> años <?php endif; ?>
                                   <?php if(!empty($scrt->Features->height)): ?> <i class="fa fa-square-full icosquare mleft"></i> <?php echo e($scrt->Features->height); ?> cm <?php endif; ?>
                                   <?php if(!empty($scrt->Rates->one_hour)): ?><i class="fa fa-square-full icosquare mleft"></i> <?php echo e($scrt->Rates->one_hour); ?> €<?php endif; ?> </span></p>
                          </div>
                      </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
      </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

<?php /**PATH C:\laragon\www\sodoma\resources\views/guest/layouts/relacionadas.blade.php ENDPATH**/ ?>