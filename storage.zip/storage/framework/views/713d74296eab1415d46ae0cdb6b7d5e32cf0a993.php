<div>
    <div class="row">
        <div class="col-12 mx-auto">

            <?php if($profile->is_vip): ?>
                <a href="<?php echo e(route('admin-delete-vip', $profile->id)); ?>" class="btn btn-danger">Quitar Vip</a>
            <?php else: ?>
                <button class="btn btn-primary crt-agency-vip" data-id="<?php echo e($profile->id); ?>">Crear Vip</button>
            <?php endif; ?>
            <a href="<?php echo e(route('admin-user-show', $profile->User->id)); ?>" class="btn btn-info">Ver Usuario</a>
            <?php if($profile->type_id == 2): ?>
                <a href="<?php echo e(route('admin-create-escort-for', $profile->id)); ?>" class="btn btn-success">Crear
                    escort</a><br>
                    <?php
                    $escorts_count = $profile->Escorts()->count();
                ?>
                <h3>Nº Escorts: <?php echo e($escorts_count); ?></h3>
                <?php if($escorts_count > 0): ?>
                    <p>
                        <a href="<?php echo e(route('admin-show-agency-escorts', $profile->id)); ?>" class="btn btn-secondary">Ver
                            Escorts</a>
                    </p>
                <?php endif; ?>

            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/components/admin-top-buttons.blade.php ENDPATH**/ ?>