<nav class="navbar navbar-expand-lg navbar-light secrets-nav pl-1">
    <div class="container">
        <a class="navbar-brand pt-0" href="<?php echo e(route('home')); ?>">
            <img src="<?php echo e(asset('images/escortssecrets-logo.jpg')); ?>" style="height: 88px"
                alt="Escorts Secrets Publicidad" />
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-default"
            aria-controls="navbar-default" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbar-default">
            <div class="navbar-collapse-header">
                <div class="row">
                    <div class="col-6 collapse-brand">
                        <a href="javascript:void(0)">
                            <img src="<?php echo e(asset('images/escortssecrets-logo.jpg')); ?>" style="height: 63px"
                                alt="Escorts Secrets Publicidad" />
                        </a>
                    </div>
                    <div class="col-6 collapse-close">
                        <button type="button" class="navbar-toggler" data-toggle="collapse"
                            data-target="#navbar-default" aria-controls="navbar-default" aria-expanded="false"
                            aria-label="Toggle navigation">
                            <span></span>
                            <span></span>
                        </button>
                    </div>
                </div>
            </div>

            <ul class="navbar-nav ml-lg-auto">
                <li class="nav-item">
                    <a class="nav-link nav-link-icon" href="<?php echo e(route('show-escorts', 'barcelona')); ?>">

                        <span class="nav-link-inner--text"><i class="fa fa-caret-right flechika"></i> Escorts Barcelona</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link nav-link-icon" href="<?php echo e(route('show-escorts', 'madrid')); ?>">

                        <span class="nav-link-inner--text"><i class="fa fa-caret-right flechika"></i> Escorts Madrid</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link nav-link-icon" href="<?php echo e(route('show-all-escorts')); ?>">

                        <span class="nav-link-inner--text"><i class="fa fa-caret-right flechika"></i> Más Escorts</span>
                    </a>
                </li>
                <?php if(auth()->check()): ?>
                    <li class="nav-item">
                        <a class="buser" href="<?php echo e(route('login')); ?>">
                            <i class="ni ni-circle-08 text-xl"></i> <span class="nav-link-inner--text d-lg-none pl-2">
                                Acceder</span>
                        </a>
                    </li>
                <?php else: ?>
                <li class="nav-item mt-4 mt-md-1">
                    <a class="bmanun" href="<?php echo e(route('login')); ?>">
                        <span class="nav-link-inner--text"> <?php echo e(__('general.navs.publishads')); ?></span>
                    </a>
                </li>
                <?php endif; ?>
                
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/guest/layouts/navbar.blade.php ENDPATH**/ ?>