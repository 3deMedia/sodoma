<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>