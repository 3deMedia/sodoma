<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminLayout::class, []); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container pt-2 pt-md-5">
        <div class="row">
            <div class="col-12 col-md-10 ">

               <table class="table">
                   <thead>
                       <tr>
                           <th>Ruta</th>
                           <th>Vista</th>
                           <th>Titulo seo</th>
                           <th>Descripción seo</th>
                           <th>Explicacion</th>
                       </tr>
                   </thead>
                   <tbody>
                       <?php $__currentLoopData = $seo_pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seo_page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if (isset($component)) { $__componentOriginal4e8aa1501ca76a1cef5d27cd92668f5f26c56493 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SeoPage::class, ['page' => $seo_page]); ?>
<?php $component->withName('seo-page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal4e8aa1501ca76a1cef5d27cd92668f5f26c56493)): ?>
<?php $component = $__componentOriginal4e8aa1501ca76a1cef5d27cd92668f5f26c56493; ?>
<?php unset($__componentOriginal4e8aa1501ca76a1cef5d27cd92668f5f26c56493); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                   </tbody>
               </table>
            </div>
        </div>
    </div>


 <?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/admin/seo/index.blade.php ENDPATH**/ ?>