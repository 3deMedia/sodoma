<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GuestLayout::class, []); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startPush('meta'); ?>
        <meta name="description" content="<?php echo e(substr($profile->description,0,200)); ?>" />
        <meta name="keywords" content="<?php echo e($seo->seo_keywords); ?>" />
        <title><?php echo e(config('app.name')); ?> | <?php echo e($profile->name); ?>: Escorts en <?php echo e($profile->Address->Region->name); ?></title>
    <?php $__env->stopPush(); ?>
    <div class="pt-2 pt-md-2 container" style="min-height:75vh;">
        <div class="row bg-white">
            <div class="w-100">
                <div class="d-flex flex-wrap putas">
                    <?php
                        $main_images= $profile->Photos->take(2);
                        $other_images= $profile->Photos->skip(2);
                    ?>
                    <?php $__currentLoopData = $main_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$mimage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 col-sm-6 px-0 flex flex-row" data-nav="thumbs">
                            <img src="<?php echo e(asset("/storage/escort_photos/$mimage->path/$mimage->filename")); ?>" alt="" data-fit="contain" data-width="100%" data-height="auto">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        

                </div>
            </div>
                
                <div class="breaddiv w-100 mr-3">
                     <ul class="breadcrumb_scor" itemscope="" itemtype="http://schema.org/BreadcrumbList">
                            <li itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem"><a itemprop="item" href="<?php echo e(route('show-all-escorts')); ?>"><span itemprop="name">Escorts</span></a><meta itemprop="position" content="1"> > </li>
                            <li itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem"><a itemprop="item" href="<?php echo e(route('show-escorts',$profile->Address->City->slug)); ?>"><span itemprop="name"><?php echo e($profile->Address->City->name); ?></span></a><meta itemprop="position" content="2"> > </li>
                            <li class="active"><span><?php echo e($profile->name); ?></span></li>
                     </ul>
                </div>
                <div class="row w-100 px-1 px-md-2">
                   <h1 class="fs-3 fw-bold mcolor"><?php echo e($profile->name); ?></h1>
                </div>
                <div class="row w-100 px-0">
                    <div class="col-md-6 mb-4 mb-md-0 px-2">
                        <div class="pt-2"><strong>Escort en <?php echo e($profile->Address->City->name); ?></strong><br /><?php echo e(__('forms.profile.1h')); ?> <?php echo e($profile->Rates->one_hour); ?> €</span>
                            <?php if($profile->Features->private_apartament == 1): ?>
                            <span> | <i class="fa fa-home"></i> <?php echo e(__('forms.profile.private_apartment')); ?></span>
                             <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-6 px-2 place-items-center"><div class="botsficha bottel"><a href="tel:<?php echo e($profile->phone); ?>"><?php echo e(__('forms.profile.callme')); ?><br /><i class="fa fa-phone"></i> <?php echo e($profile->phone); ?></a></div>
                        <div class="botsficha botwhats"><a href="https://api.whatsapp.com/send?phone=34<?php echo e($profile->phone); ?>&text=Hola"><?php echo e(__('forms.profile.attended')); ?><br /><img src="<?php echo e(asset('images/whatsapp.png')); ?>" /> Whatsapp</a></div></div>
                </div>
                <div class="col-12 pt-4 px-2">
                    <p><?php echo e($profile->description); ?></p>
                </div>

                <div class="d-flex flex pt-2 pb-4 w-100 col-12 col-lg-6 px-2">
                    <div class="w-50">
                        <h4 class="fs-4 fw-bold mcolor border-bottom border-mcolor w-100 pt-3"><?php echo e(__('general.data')); ?></h4>
                        <table class="table">

                            <tbody class="">
                                <tr>
                                    <td scope="row" class="fw-bold border-0"><?php echo e(__('forms.profile.age')); ?></td>
                                    <td class="border-0"><?php echo e($profile->Features->age); ?></td>
                                </tr>
                                <tr>
                                    <td scope="row" class="fw-bold border-0"><?php echo e(__('forms.profile.height')); ?></td>
                                    <td class="border-0"><?php echo e($profile->Features->height); ?></td>
                                </tr>
                                <?php if(!empty($profile->Features->eye_color_id)): ?>
                                <tr>
                                    <td scope="row" class="fw-bold border-0"><?php echo e(__('forms.profile.eye_color')); ?></td>
                                    <td class="border-0"><?php echo e($profile->Features->Eyes()); ?></td>
                                </tr>
                                <?php endif; ?>
                                <?php if(!empty($profile->Features->Hair())): ?>
                                <tr>
                                    <td scope="row" class="fw-bold border-0"><?php echo e(__('forms.profile.Hair_color')); ?></td>
                                    <?php $hair =  $profile->Features->Hair();  ?>
                                    <td class="border-0"> <?php echo e(__("forms.profile.$hair")); ?></td>
                                </tr>
                                <?php endif; ?>
                                <?php if(!empty($profile->Features->Ethnic())): ?>
                                <tr>
                                    <td scope="row" class="fw-bold border-0"><?php echo e(__('forms.profile.Ethnicity')); ?></td>
                                    <?php $etic =  $profile->Features->Ethnic();  ?>
                                    <td class="border-0"><?php echo e(__("forms.profile.$etic")); ?></td>
                                </tr>
                                <?php endif; ?>
                                
                            </tbody>
                        </table>
                    </div>
                    <div class="w-50 pt-5">
                        <table class="table">

                            <tbody class="">
                                <?php if(!empty($profile->Features->weight)): ?>
                                <tr>
                                    <td scope="row" class="fw-bold border-0"><?php echo e(__('forms.profile.weight')); ?></td>
                                    <td class="border-0"><?php echo e($profile->Features->weight); ?></td>
                                </tr>
                                <?php endif; ?>
                                <?php if(!empty($profile->Features->breast_size)): ?>
                                <tr>
                                    <td scope="row" class="fw-bold border-0"><?php echo e(__('forms.profile.breast_size')); ?></td>
                                    <td class="border-0"><?php echo e($profile->Features->breast_size); ?></td>
                                </tr>
                                <?php endif; ?>
                                <?php if($profile->Features->breast_type == 1): ?>
                                <tr>
                                    <td scope="row" class="fw-bold border-0"><?php echo e(__('forms.profile.breast_type')); ?></td>
                                    <td class="border-0">Natural</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                    <div class="col-12 col-lg-6 pb-4 pb-md-0 px-2">
                        <h4 class="fs-4 fw-bold mcolor border-bottom border-mcolor w-100 pt-4"><?php echo e(__('general.rates')); ?></h4>
                        <div class="table-responsive">
                            <table class="table align-items-center table-flush rounded">

                                <tbody class="list">
                                    <?php if(!empty($profile->Rates->half_hour)): ?>
                                    <tr>
                                        <td scope="row" class="fw-bold border-0"><?php echo e(__('forms.profile.30min')); ?></td>
                                        <td class="border-0"><?php echo e($profile->Rates->half_hour); ?> €</td>
                                    </tr>
                                    <?php endif; ?>
                                    <tr>
                                        <td scope="row" class="fw-bold border-0"><?php echo e(__('forms.profile.1h')); ?></td>
                                        <td class="border-0"><?php echo e($profile->Rates->one_hour); ?> €</td>
                                    </tr>
                                    <?php if(!empty($profile->Rates->added_hour)): ?>
                                    <tr>
                                        <td scope="row" class="fw-bold border-0"><?php echo e(__('forms.profile.1h+')); ?></td>
                                        <td class="border-0"><?php echo e($profile->Rates->added_hour); ?> €</td>
                                    </tr>
                                    <?php endif; ?>
                                    <?php if(!empty($profile->Rates->half_day)): ?>
                                    <tr>
                                        <td scope="row" class="fw-bold  border-0"><?php echo e(__('forms.profile.12h')); ?></td>
                                        <td class="border-0"><?php echo e($profile->Rates->half_day); ?> €</td>
                                    </tr>
                                    <?php endif; ?>
                                    <?php if(!empty($profile->Rates->one_day)): ?>
                                    <tr>
                                        <td scope="row" class="fw-bold border-0"><?php echo e(__('forms.profile.24h')); ?></td>
                                        <td class="border-0"><?php echo e($profile->Rates->one_day); ?> €</td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="row px-2">
                            <?php if($profile->Features->creditcard_acceptance == 1): ?>
                            <div class="w-50 featser"><span><i class="fa fa-credit-card"></i> <?php echo e(__('forms.profile.paycard')); ?></span></div>
                            <?php endif; ?>
                            <?php if($profile->Features->is_pornstar == 1): ?>
                            <div class="w-50 featser"><span><i class="fa fa-mobile"></i> <?php echo e(__('forms.profile.paybizum')); ?></span></div>
                            <?php endif; ?>
                          </div>
                    </div>

                <div class="col-12 mb-6 px-2">
                    <h4 class="fs-4 fw-bold mcolor border-bottom border-mcolor w-100 pt-3"><?php echo e(__('forms.profile.services')); ?></h4>
                    <?php
                        $services = DB::table('services')->get();
                    ?>
                    <ul class="ulservices mt-3">
                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(in_array($service->id, $profile->Features->services)): ?>
                            <li> <?php echo e(__("forms.services.$service->name")); ?> </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <div class="w-100">
                  <div class="d-flex flex-wrap putas">

                    <?php $__currentLoopData = $other_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$oimage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="col-12 col-sm-6 px-0 flex flex-row" data-nav="thumbs">
                        <img src="<?php echo e(asset("/storage/escort_photos/$oimage->path/$oimage->filename")); ?>" alt="" data-fit="contain" data-width="100%" data-height="auto">
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                  </div>
                </div>
            </div>
        </div>
        <?php if(auth()->guard()->guest()): ?>
            <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog"
                aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLongTitle">Mensaje Directo</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form action="<?php echo e(route('send.message.to-escort', $profile->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="email" name="email" id="" class="form-control my-4" placeholder="email"
                                    required>
                                <textarea type="text" name="message" class="form-control" required></textarea>
                                <br>
                                <button type="submit" class="btn btn-block btn-primary btn-submit">Send</button>
                            </form>
                        </div>



                    </div>
                </div>
            </div>
        <?php endif; ?>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/guest/escort-show.blade.php ENDPATH**/ ?>