<div>
    name: <?php echo e($data->name); ?> <br><br>
    email: <?php echo e($data->email); ?><br><br>
    message: <?php echo e($data->message); ?>


    <a href="<?php echo e($data->link); ?>" target="_blank">Ver escort</a>
</div>
<?php /**PATH C:\laragon\www\sodoma\resources\views/mails/contact.blade.php ENDPATH**/ ?>