<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GuestLayout::class, []); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startPush('meta'); ?>
        <meta name="description" content="<?php echo e($seo->seo_description); ?>" />
        <meta name="keywords" content="<?php echo e($seo->seo_keywords); ?>" />
        <title><?php echo e(config('app.name')); ?> | <?php echo e($seo->seo_title); ?></title>
    <?php $__env->stopPush(); ?>
    <div class="pt-2 pt-md-2" style="min-height:75vh;">
        <div class="row">
                <div class="d-flex flex-wrap putas">

                        <?php $__currentLoopData = $profile->Photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="w-50 md:w-50 flex flex-row" data-nav="thumbs">
                            <img src="<?php echo e(asset("/storage/escort_photos/$photo->path/$photo->filename")); ?>" alt=""
                            data-fit="contain" data-width="100%" data-height="auto">
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
                


            <div class="col-12 mt-5 bg-white">
                <h1 class="fs-3 fw-bold mcolor border-bottom border-mcolor w-100 pt-4"><?php echo e($profile->name); ?></h1>
                <div class="col-12">
                    <div class="p-2 text-black">
                        <p> <?php echo e($profile->description); ?></p>
                    </div>

                </div>
                <div class="row pt-2 pb-4">
                    <div class="col-6 col-md-3">
                        <table class="table">

                            <tbody class="">
                                <tr>
                                    <td scope="row" class="fw-bold border-0">Age</td>
                                    <td class="border-0"><?php echo e($profile->Features->age); ?></td>
                                </tr>
                                <tr>
                                    <td scope="row" class="fw-bold border-0">Height</td>
                                    <td class="border-0"><?php echo e($profile->Features->height); ?></td>
                                </tr>
                                <tr>
                                    <td scope="row" class="fw-bold border-0">Eyes color</td>
                                    <td class="border-0"><?php echo e($profile->Features->Eyes()); ?></td>
                                </tr>
                                <tr>
                                    <td scope="row" class="fw-bold border-0">Hair</td>
                                    <td class="border-0"><?php echo e($profile->Features->Hair()); ?></td>
                                </tr>
                                <tr>
                                    <td scope="row" class="fw-bold border-0">Etnia</td>
                                    <td class="border-0"><?php echo e($profile->Features->Ethnic()); ?></td>
                                </tr>
                                
                            </tbody>
                        </table>
                    </div>
                    <div class="col-6 col-md-3">
                        <table class="table">

                            <tbody class="">
                                <tr>
                                    <td scope="row" class="fw-bold border-0">Weight</td>
                                    <td class="border-0"><?php echo e($profile->Features->weight); ?></td>
                                </tr>
                                <tr>
                                    <td scope="row" class="fw-bold border-0">Breast Size</td>
                                    <td class="border-0"><?php echo e($profile->Features->breast_size); ?></td>
                                </tr>
                                <tr>
                                    <td scope="row" class="fw-bold border-0">Breast Type</td>
                                    <td class="border-0"><?php echo e($profile->Features->breast_type); ?></td>
                                </tr>
                                <tr>
                                    <td scope="row" class="fw-bold border-0">Orientation</td>
                                    <td class="border-0"><?php echo e($profile->Features->Orientation()); ?></td>
                                </tr>
                                <tr>
                                    <td scope="row" class="fw-bold border-0">Pornstar</td>
                                    <td class="border-0"><?php echo e($profile->Features->is_pornstar); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <div class="col-12 col-sm-6">
                        <h4 class="fs-4 fw-bold mcolor border-bottom border-mcolor w-100 pt-3">Services</h4>
                        <?php
                            $services = DB::table('services')->get();
                        ?>
                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(in_array($service->id, $profile->Features->services)): ?>
                                <p class='text-black'> <?php echo e(__("forms.services.$service->name")); ?> </p>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="col-12 col-md-4 ">
                        <h4 class="fs-4 fw-bold mcolor border-bottom border-mcolor w-100 pt-3">Rates</h4>
                        <div class="table-responsive">
                            <table class="table align-items-center table-flush rounded">

                                <tbody class="list">
                                    <tr>
                                        <td scope="row" class="fw-bold border-0">30 min</td>
                                        <td class="border-0"><?php echo e($profile->Rates->half_hour); ?></td>
                                    </tr>
                                    <tr>
                                        <td scope="row" class="fw-bold border-0">1 Hora</td>
                                        <td class="border-0"><?php echo e($profile->Rates->one_hour); ?></td>
                                    </tr>
                                    <tr>
                                        <td scope="row" class="fw-bold border-0">+ Hora adicional</td>
                                        <td class="border-0"><?php echo e($profile->Rates->added_hour); ?></td>
                                    </tr>
                                    <tr>
                                        <td scope="row" class="fw-bold  border-0">12 Horas</td>
                                        <td class="border-0"><?php echo e($profile->Rates->half_day); ?></td>
                                    </tr>
                                    <tr>
                                        <td scope="row" class="fw-bold border-0">24 Horas</td>
                                        <td class="border-0"><?php echo e($profile->Rates->one_day); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                    </div>

                </div>

            </div>
            <div class="row">
             <div class="d-flex flex-wrap putas">

                <?php $__currentLoopData = $profile->Photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="w-50 md:w-50 flex flex-row" data-nav="thumbs">
                    <img src="<?php echo e(asset("/storage/escort_photos/$photo->path/$photo->filename")); ?>" alt=""
                    data-fit="contain" data-width="100%" data-height="auto">
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

             </div>
            </div>
        </div>
        <?php if(auth()->guard()->guest()): ?>
            <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog"
                aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLongTitle">Mensaje Directo</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form action="<?php echo e(route('send.message.to-escort', $profile->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="email" name="email" id="" class="form-control my-4" placeholder="email"
                                    required>
                                <textarea type="text" name="message" class="form-control" required></textarea>
                                <br>
                                <button type="submit" class="btn btn-block btn-primary btn-submit">Send</button>
                            </form>
                        </div>



                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php $__env->startPush('js'); ?>

            <script src="<?php echo e(asset('js/fotorama.js')); ?>"></script>
            <script>
                $('.fotorama').fotorama({
                    width: 400,
                    maxwidth: '100%',
                    height: 600,

                    allowfullscreen: true,
                    nav: 'thumbs'
                });
            </script>

        <?php $__env->stopPush(); ?>
 <?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/guest/escort-show.blade.php ENDPATH**/ ?>