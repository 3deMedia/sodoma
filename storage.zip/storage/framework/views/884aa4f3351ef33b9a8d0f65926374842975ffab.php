<?php $attributes = $attributes->exceptProps(['active']); ?>
<?php foreach (array_filter((['active']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div>
    <div>

        <div class="row">
            <div class="col-12">
                <div class="table-responsive">
                    <table class="table align-items-center table-flush">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col" class="sort" data-sort="name"></th>
                                <th scope="col" class="sort" data-sort="name"><?php echo e(__('agency.Escort_name')); ?></th>
                                <th scope="col">Estado</th>
                                <th scope="col"><?php echo e(__('general.Visits')); ?> / mes</th>
                                <th scope="col" class="sort" data-sort="budget"><?php echo e(__('general.Edit')); ?></th>
                                <th scope="col" class="sort" data-sort="status"> <?php echo e(__('general.agency.hide_escort')); ?> </th>
                                <th scope="col"><?php echo e(__('general.agency.create_vip')); ?></th>


                            </tr>
                        </thead>
                        <tbody class="list">
                            <?php $__currentLoopData = $active; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act_scrt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td scope="row">
                                    <div class="">
                                        <?php
                                        $mfoto = $act_scrt->MainPhoto();
                                        ?>
                                        <?php if($mfoto): ?>
                                        <a href="#" class="mavatar mr-3">
                                            <img loading="lazy" style="border-radius:8px"  alt="" src="<?php echo e(asset("storage/escort_photos/$mfoto->path/$mfoto->filename")); ?>">
                                        </a>
                                        <?php endif; ?>

                                    </div>
                                </td>
                                <td>
                                    <div class="media-body">
                                        <span class="name mb-0 text-sm"><?php echo e($act_scrt->name); ?></span>
                                    </div>
                                </td>
                                <td>
                                    <div class="media-body">
                                        <span class="name mb-0 text-sm">

                                            <?php if(!$act_scrt->approved): ?>
                                            <i class="fa fa-circle text-red"></i>Sin aprobar <strong><a
                                                href="<?php echo e(route('my-profile')); ?>">Actualiza tu perfil</a></strong>

                                            <?php elseif(!$act_scrt->active): ?>
                                                <i class="fa fa-circle text-gray"></i> Oculto
                                            <?php elseif($act_scrt->active): ?>
                                                <i class="fa fa-circle text-green"></i> Activo
                                            <?php endif; ?>

                                        </span>
                                    </div>
                                </td>
                                <td class="text-center mcolor fw-bold">
                                    <?php echo e($act_scrt->vzt()->period('month')->count()); ?>

                                </td>
                                <td>
                                    <button class="btn btn-warning edit-scrt" data-render="<?php echo e($act_scrt->id); ?>">
                                        <i class="fas fa-user-edit"></i>
                                    </button>
                                </td>
                                <td>
                                    <button class="btn btn-dark hide-prof" data-render="<?php echo e($act_scrt->id); ?>">
                                        <i class="fas fa-eye-slash"></i>

                                    </button>
                                </td>
                                <td>
                                    <?php if(!$act_scrt->is_vip): ?>
                                    <button class="btn btn-info ae-make-vip text-white"
                                        data-render="<?php echo e($act_scrt->id); ?>">
                                        <i class="fas fa-gem" aria-hidden="true"></i>
                                    </button>
                                    <?php else: ?>
                                    <p class="p-2"><?php echo e(__('general.vip.ends_at_message')); ?>

                                        <?php echo e($act_scrt->Vip()->ends_at->format('d-m-Y')); ?></p>
                                    <?php endif; ?>
                                </td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/user/agency/tabs/active-escorts.blade.php ENDPATH**/ ?>