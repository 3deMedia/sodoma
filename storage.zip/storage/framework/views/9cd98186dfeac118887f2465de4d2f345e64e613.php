<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminLayout::class, []); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container pt-5 px-2">
        <div class="row">
            <?php if(session('success')): ?>
                <div class="col-12">
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                </div>

            <?php endif; ?>
            <div class="col-12 col-md-10 ">
                <table id="reviews_table" class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>Fecha</th>
                            <th>Nombre</th>
                            <th>Email</th>
                            <th>Tipo</th>
                            <th>Ver</th>
                            <th>Mensaje</th>
                            <th>Aprovar</th>
                            <th>Borrar</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td scope="row"><?php echo e($profile->created_at->format('d-m-Y')); ?></td>
                                <td><?php echo e($profile->name); ?> </td>
                                <td><?php echo e($profile->email); ?> </td>
                                <td><?php echo e($profile->type_id == 1 ? 'Escort' : 'Agencia'); ?> </td>
                                <td>
                                        <a href="<?php echo e(route('admin-profile-show', $profile->id)); ?>" target="_blank"
                                            class="btn btn-info"><i class="fa fa-eye" aria-hidden="true"></i></a>
                                </td>
                                <td> <button class="btn btn-warning"><i class="fa fa-envelope-open btn-profile-msg" data-id="<?php echo e($profile->id); ?>"  aria-hidden="true"></i></button></td>

                                <td><a href="<?php echo e(route('approve-profile',$profile->id)); ?>" class="btn btn-success btn-approve-profile" >
                                        <i class="fa fa-check-circle" aria-hidden="true"></i></button></td>
                                <td><a href="<?php echo e(route('admin-profile-delete',$profile->id)); ?>" class="btn btn-danger" >
                                    <i class="fa fa-trash" aria-hidden="true"></i></button></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/admin/profiles/pending.blade.php ENDPATH**/ ?>