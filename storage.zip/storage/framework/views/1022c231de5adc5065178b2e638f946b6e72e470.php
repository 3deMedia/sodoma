<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GuestLayout::class, []); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container pb-5 pt-5 pt-md-1">
        <!-- Table -->
        <div class="row justify-content-center">
            <div class="col-lg-6 col-md-8">
                <div class="card bg-secondary shadow border-0">
                    <div class="card-header bg-black pb-4">
                        <h2 class="text-xl text-center text-white">Regístrate ahora</h2>
                    </div>
                    <div class="card-body px-lg-5 py-lg-5">

                        <form role="form" method="POST" action="<?php echo e(route('register')); ?>" id="register-form">
                            <?php echo csrf_field(); ?>
                            <div>
                                <?php if($errors->has('user_type_id')): ?>
                                    <span class="invalid-feedback" style="display: block;" role="alert">
                                        <strong><?php echo e($errors->first('user_type_id')); ?></strong>
                                    </span>
                                <?php endif; ?>
                                <div class="form-group d-flex justify-content-around">
                                    <div class="form-group form-check">
                                        <input type="radio" class="form-check-input" id="" name="user_type_id" value="1"
                                            checked required>
                                        <label class="form-check-label"
                                            for="exampleCheck1"><?php echo e(__('general.Escort')); ?></label>
                                    </div>
                                    <div class="form-group form-check">
                                        <input type="radio" class="form-check-input" id="" name="user_type_id"
                                            value="2">
                                        <label class="form-check-label" for=""><?php echo e(__('general.Agency')); ?></label>
                                    </div>

                                </div>
                            </div>


                            <div class="form-group<?php echo e($errors->has('email') ? ' has-danger' : ''); ?>">
                                <div class="input-group input-group-alternative mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="ni ni-email-83"></i></span>
                                    </div>
                                    <input class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>"
                                        placeholder="<?php echo e(__('Email')); ?>" type="email" name="email"
                                        value="<?php echo e(old('email')); ?>" required>
                                </div>
                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" style="display: block;" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group<?php echo e($errors->has('password') ? ' has-danger' : ''); ?>">
                                <div class="input-group input-group-alternative">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="ni ni-lock-circle-open"></i></span>
                                    </div>
                                    <input class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>"
                                        placeholder="Contraseña" type="password" name="password" required>
                                </div>
                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" style="display: block;" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <div class="input-group input-group-alternative">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="ni ni-lock-circle-open"></i></span>
                                    </div>
                                    <input class="form-control" placeholder="Confirmar Contraseña"
                                        type="password" name="password_confirmation" required>
                                </div>
                            </div>

                            <div class="row my-4">
                                <div class="col-12">
                                    <div class="custom-control custom-control-alternative custom-checkbox">
                                        <input class="custom-control-input" id="accept_policy" type="checkbox"
                                            name="accept_policy" required checked>
                                        <label class="custom-control-label" for="customCheckRegister">
                                            <span class="text-muted">Estoy de acuerdo con la <a
                                                    href="#!">Política de Privacidad</a></span>
                                        </label>
                                    </div>
                                    <span class="invalid-feedback d-none" style="display: block;" role="alert"
                                        id="policy-check">
                                        <strong><?php echo e(__('general.must_accept_policy')); ?></strong>
                                    </span>

                                </div>
                            </div>
                            <div class="text-center">
                                <button type="submit"
                                    class="btn btn-primary mt-4 btn-submit">Crear Cuenta</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->startPush('js'); ?>
        <script>
            $('#register-form').on('submit', function(e) {
                if ($('#accept_policy:checked').length === 0) {
                    $('#policy-check').removeClass('d-none')
                    e.preventDefault();
                }
            });
        </script>
    <?php $__env->stopPush(); ?>

 <?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/auth/register.blade.php ENDPATH**/ ?>