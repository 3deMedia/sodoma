<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <div class="container pb-5">

        <div class="row">
            <div class="col-12">
                <h2 class="fw-bold mb-4 text-center"><?php echo e(__('general.Hello')); ?> <?php echo e($profile->name); ?></h2>
            </div>
        </div>

        <div class="row">
            <div class="col-12 col-md-10 mt-2 mt-md-5 bg-white rounded-md mx-auto p-4">
                <div style="float: right"><span class="coinsleft"><?php echo e($coins); ?></span><br /><span
                        class="saldoleft">saldo</span></div>
                <p><strong>Anuncio: </strong> <i class="fa fa-circle text-green"></i> Activo</p>
                <p>
                    <?php if($profile->Vipsubscription()): ?>
                        <strong>Renovación:</strong> 22/02/2022
                    <?php else: ?>
                        <?php echo e(__('general.susbscriptions.no_subscriptions')); ?>

                    <?php endif; ?>

                </p>
            </div>
            <div class="col-12 col-md-10 mt-2 mt-md-5 bg-white rounded-md mx-auto">
                <h5 class="text-center p-2">Actualmente tienes<br /><?php echo e($coins); ?> € de Saldo</h5>
                <p class="text-center mb-5">Para publicar o renovar tu anuncio tienes que disponer de saldo
                    suficiente en tu cuenta, de lo contrario los anuncios se detendrán. Compra saldo ahora.</p>
                <div class="row">
                    <div class="col-8 col-md-6 col-lg-3 mx-auto">
                        <p><a href="<?php echo e(route('buy-coins')); ?>" class="butbuycoins"><i
                                    class="fa fa-coins text-xl pr-3"></i> Comprar Saldo</a></p>
                        <p><a href="<?php echo e(route('my-profile')); ?>" class="butbuycoins"><i
                                    class="fa fa-image text-xl pr-3"></i> <?php echo e(__('general.PublishAd')); ?></a></p>
                        <p><a href="<?php echo e(route('payments')); ?>" class="butbuycoins"><i
                                    class="fa fa-receipt text-xl pr-3"></i> <?php echo e(__('general.Payments')); ?></a></p>
                        <p><a href="<?php echo e(route('changepassword')); ?>" class="butchangepass"><i
                                    class="fa fa-lock text-xl pr-3"></i> <?php echo e(__('general.Change Password')); ?></a></p>
                        <p><a href="<?php echo e(route('logout')); ?>" class="butclose"
                                onclick="event.preventDefault();document.getElementById('logout-form').submit();"><i
                                    class="fa fa-power-off text-xl pr-3"></i> <?php echo e(__('general.Logout')); ?></a>
                    </div>

                </div>
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/user/escort/account.blade.php ENDPATH**/ ?>