<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <div class="container pb-8">

            <div class="row">
                <div class="col-12 col-md-10 col-lg-8 mx-auto ">
                    <h2 class="fw-bold"><?php echo e(__('Passwords.Change Password')); ?></h2>
                    <form method="post" action="<?php echo e(route('profile.password')); ?>" autocomplete="off"
                    class="card p-4 shadow">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>



                    <?php if(session('password_status')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(session('password_status')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>

                    <div class="pl-lg-4">
                        <div class="form-group<?php echo e($errors->has('old_password') ? ' has-danger' : ''); ?>">
                            <label class="form-control-label"
                                for="input-current-password"><?php echo e(__('Passwords.Current Password')); ?></label>
                            <input type="password" name="old_password" id="input-current-password"
                                class="form-control form-control-alternative<?php echo e($errors->has('old_password') ? ' is-invalid' : ''); ?>"
                                placeholder="<?php echo e(__('Passwords.Current Password')); ?>" value="" required>

                            <?php if($errors->has('old_password')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('old_password')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group<?php echo e($errors->has('password') ? ' has-danger' : ''); ?>">
                            <label class="form-control-label"
                                for="input-password"><?php echo e(__('Passwords.New Password')); ?></label>
                            <input type="password" name="password" id="input-password"
                                class="form-control form-control-alternative<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>"
                                placeholder="<?php echo e(__('Passwords.New Password')); ?>" value="" required>

                            <?php if($errors->has('password')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label class="form-control-label"
                                for="input-password-confirmation"><?php echo e(__('Passwords.Confirm New Password')); ?></label>
                            <input type="password" name="password_confirmation" id="input-password-confirmation"
                                class="form-control form-control-alternative"
                                placeholder="<?php echo e(__('Passwords.Confirm New Password')); ?>" value="" required>
                        </div>

                        <div class="text-center">
                            <button type="submit"
                                class="btn rounded w-100 bg-rosa text-white px-4 py-2 mx-auto btn-submit"><?php echo e(__('Passwords.Change Password')); ?></button>
                        </div>
                    </div>
                </form>
                </div>
            </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\sodoma\resources\views/user/changepassword.blade.php ENDPATH**/ ?>