<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container " style="min-height: 75vh;">
        <div class="row">
            <div class="col-12">
                <h2 class="fw-bold mb-4 text-center pb-4">Mensajes</h2>
            </div>
        <div class="row">
            <div class="col-12 col-md-10 mx-auto">
                <div class="">
                    <?php if($messages && count($messages) > 0): ?>
                    <table class="table" id="users_table">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col" class="w-25"><?php echo e(__('general.Date')); ?></th>
                                <th scope="col" class="w-25"><?php echo e(__('general.To')); ?></th>
                                <th scope="col" class="w-25"><?php echo e(__('general.from')); ?></th>
                                <th scope="col" class="w-25"><?php echo e(__('general.Message')); ?></th>
                                <th scope="col" class="w-25"><?php echo e(__('general.remove')); ?></th>
                            </tr>
                        </thead>
                        <tbody class="table-hover">
                            <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr style="">
                                <td scope="row"><?php echo e($msg->created_at->format('d-m-Y')); ?></td>
                                <td><p><?php echo e($msg->Profile->name); ?> </p> </td>
                                <td><p><?php echo e($msg->email); ?> </p> </td>
                                <td style="white-space: inherit;"><p> <?php echo e($msg->message); ?></p> </td>
                                <td> <button class="btn btn-danger del-msg" data-render="<?php echo e($msg->id); ?>"> <i class="fa fa-trash" aria-hidden="true"></i></button> </td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </tbody>
                    </table>
                    <?php else: ?>
                        <p>No tienes ningun mensaje</p>
                    <?php endif; ?>

                </div>

            </div>
        </div>
        <?php $__env->startPush('js'); ?>
        <script defer>
            $('table').DataTable();
        </script>

        <?php $__env->stopPush(); ?>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/user/messages.blade.php ENDPATH**/ ?>