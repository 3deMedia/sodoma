<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GuestLayout::class, []); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startPush('meta'); ?>
        <meta name="description" content="<?php echo e($seo->seo_description); ?>" />
        <meta name="keywords" content="<?php echo e($seo->seo_keywords); ?>" />
        <title><?php echo e(config('app.name')); ?> | <?php echo e($seo->seo_title); ?></title>
    <?php $__env->stopPush(); ?>
    <div class="container py-4">
        <div class="row">
            <div class="col-12 mx-auto bg-white p-4">

                        <h1 class="h3 mb-4 fw-bold">Aviso Legal</h1>
                        <p class="text-sm m-1 p-2">En cumplimiento de lo dispuesto en la Ley Orgánica 15/1999, de 13 de Diciembre, de Protección de Datos de Carácter Personal (LOPD) se informa al usuario que todos los datos que nos proporcione serán incorporados a un fichero, creado y mantenido bajo la responsabilidad de Escorts Secrets.</p>

                        <p class="text-sm m-1 p-2">Siempre se va a respetar la confidencialidad de sus datos personales que sólo serán utilizados con la finalidad de gestionar los servicios ofrecidos, atender a las solicitudes que nos plantee, realizar tareas administrativas, así como remitir información técnica, comercial o publicitaria por vía ordinaria o electrónica.</p>

                        <p class="text-sm m-1 p-2">Para ejercer sus derechos de oposición, rectificación o cancelación deberá dirigirse a la sede de la empresa en Conde Salvatierra 08006 Barcelona, escribirnos al siguiente correo info @escortssecrets.com.</p>
                    <p class="text-sm m-1 p-2">Navegar y utilizar los servicios de Escorts Secrets www.escortssecrtes.com le atribuye le compromete como usuario a la aceptación de todas las condiciones publicadas en este aviso legal.</p>


                </div>
         </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/legal/privacy.blade.php ENDPATH**/ ?>