<?php echo e($slot); ?>

<?php /**PATH C:\laragon\www\sodoma\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>