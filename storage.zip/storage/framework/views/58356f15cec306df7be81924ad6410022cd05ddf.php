<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 mx-auto">
                <?php
                $is_admin=false;
                ?>

                <?php if(!$profile): ?>
                    <?php if (isset($component)) { $__componentOriginal70b3115f20724bd4fbf3055ab93bdb5fdea5d392 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Forms\CreateEscortForm::class, ['admin' => $is_admin]); ?>
<?php $component->withName('forms.create-escort-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal70b3115f20724bd4fbf3055ab93bdb5fdea5d392)): ?>
<?php $component = $__componentOriginal70b3115f20724bd4fbf3055ab93bdb5fdea5d392; ?>
<?php unset($__componentOriginal70b3115f20724bd4fbf3055ab93bdb5fdea5d392); ?>
<?php endif; ?>
                <?php else: ?>
                    <?php if (isset($component)) { $__componentOriginalb9385431c152401c2822334b22ab571722e82a06 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Forms\UpdateEscortForm::class, ['profile' => $profile,'admin' => $is_admin]); ?>
<?php $component->withName('forms.update-escort-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb9385431c152401c2822334b22ab571722e82a06)): ?>
<?php $component = $__componentOriginalb9385431c152401c2822334b22ab571722e82a06; ?>
<?php unset($__componentOriginalb9385431c152401c2822334b22ab571722e82a06); ?>
<?php endif; ?>
                <?php endif; ?>

            </div>
        </div>
        <?php $__env->startPush('js'); ?>
        <script>

            $('.profile-image').on('click',function(){
                $('.profile-image').removeClass('profile-main-image');
                $(this).addClass('profile-main-image')
                let photo_id= $(this).attr('data-render');
                $('input[name=main_photo]').val(photo_id)
            });

        </script>

    <?php $__env->stopPush(); ?>
    </div>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/user/escort/profile.blade.php ENDPATH**/ ?>