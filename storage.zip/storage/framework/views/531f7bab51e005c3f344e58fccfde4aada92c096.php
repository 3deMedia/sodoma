<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GuestLayout::class, []); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startPush('meta'); ?>
    <meta name="description" content="<?php echo e($seo->seo_description); ?>" />
    <meta name="keywords" content="<?php echo e($seo->seo_keywords); ?>" />
    <title><?php echo e(config('app.name')); ?> | <?php echo e($seo->seo_title); ?></title>
<?php $__env->stopPush(); ?>
<div class="container">

    


    <?php $__currentLoopData = $grouped_escorts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $escort_group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row my-4">
        <div class="col-12 d-flex flex-wrap px-0">
            <?php $__currentLoopData = $escort_group->shuffle(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scrt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php
                    $mainPhoto = $scrt->MainPhoto();

                ?>

                    <div class="shadow-lg p-2 rounded text-center profile-view">
                        <div class="bg-white">
                            <a href="<?php echo e(route('show-an-escort', $scrt->uid)); ?>" class="w-100 ">
                                <div style="width: 100%; position: relative;" <?php if($scrt->is_vip): ?> class="corner" <?php endif; ?>>
                                    <img loading="lazy"
                                        src='<?php echo e(asset("storage/escort_photos/$mainPhoto->path/$mainPhoto->filename")); ?>'>
                                    <div class="custom-layer" style="display: none">
                                        <div class="description">
                                            <ul>
                                                <li>Age :<span class="text-white">
                                                        <?php echo e($scrt->Features->age); ?></span> </li>
                                                <li>Height :<span class="text-white">
                                                        <?php echo e($scrt->Features->height); ?> cm</span> </li>

                                                <li>Eyes color :<span class="text-white">
                                                        <?php echo e($scrt->Features->Eyes()); ?></span> </li>

                                                <li>Hair :<span class="text-white">
                                                        <?php echo e($scrt->Features->Hair()); ?></span> </li>

                                                <li>Etnia :<span class="text-white">
                                                        <?php echo e($scrt->Features->Ethnic()); ?></span> </li>

                                                <li>Weight :<span class="text-white">
                                                        <?php echo e($scrt->Features->weight); ?> kg</span> </li>

                                                <li>Breast Size :<span class="text-white">
                                                        <?php echo e($scrt->Features->breast_size); ?></span> </li>

                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </a>
                            <p class="profile-name"><?php echo e($scrt->name); ?> </p>
                        </div>
                    </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



    <?php $__env->startPush('js'); ?>
        <script defer>
            $('.profile-view').hover(function() {

                let elem = $(this).find('.custom-layer');

                elem.slideToggle('normal')
            }, function() {
                let elem = $(this).find('.custom-layer');

                elem.slideToggle('normal')
            })
        </script>

    <?php $__env->stopPush(); ?>
</div>
 <?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/guest/escorts.blade.php ENDPATH**/ ?>