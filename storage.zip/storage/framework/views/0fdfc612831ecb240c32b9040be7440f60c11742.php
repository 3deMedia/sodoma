<footer class="container py-5 mt-4" style="background-color: #f0f0f0;">

        <?php echo $__env->make('layouts.footers.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</footer>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/layouts/footers/guest.blade.php ENDPATH**/ ?>