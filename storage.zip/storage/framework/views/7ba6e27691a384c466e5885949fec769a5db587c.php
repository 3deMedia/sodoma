<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminLayout::class, []); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <?php echo $__env->make('admin.layouts.cards',['data' =>$data], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container-fluid mt--7">

        <div class="row my-5">
            <div class="col-12 col-md-6 col-xl-4   mb-5 mb-xl-0">
                <div class="card shadow">
                    <div class="card-header border-0">
                        <div class="row align-items-center">
                            <div class="col">
                                <h3 class="mb-0">Crear</h3>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <p><a href="<?php echo e(route('admin-profile-create',['type'=>2])); ?>">Crear usuario tipo agencia</a></p>
                        <p><a href="<?php echo e(route('admin-profile-create',['type'=>1])); ?>">Crear usuario tipo escort</a></p>

                    </div>

                </div>
            </div>
            <div class="col-12 col-md-6 col-xl-4   mb-5 mb-xl-0">
                <div class="card shadow">
                    <div class="card-header border-0">
                        <div class="row align-items-center">
                            <div class="col">
                                <h3 class="mb-0">Nuevo coste</h3>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('admin.update.costs')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                              <label for="profile_type_id"></label>
                                <select name="profile_type_id" class="form-control" >
                                    <option value="2">Agencia</option>
                                    <option value="1">Escort</option>
                              </select>
                            </div>
                            <div class="form-group">
                                <label for="">Coins</label>
                                <input type="number" name="cost" id="" class="form-control">

                              </div>
                              <button type="submit">Actualizar</button>
                        </form>
                    </div>

                </div>
            </div>
        </div>


    </div>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('argon')); ?>/vendor/chart.js/dist/Chart.min.js"></script>
<script src="<?php echo e(asset('argon')); ?>/vendor/chart.js/dist/Chart.extension.js"></script>
<?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>