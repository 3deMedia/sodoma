<div class="row align-items-center justify-content-xl-between">
    <div class="col-xl-6">
        <div class="copyright text-center text-xl-left">
            <span class="ml-1">  &copy; <?php echo e(now()->year); ?> - <?php echo e(config('app.name')); ?></span>

        </div>
    </div>
    <div class="col-xl-6">
        <ul class="nav nav-footer justify-content-center justify-content-xl-end">
            <li class="nav-item">
                <a href="<?php echo e(route('legal.show','privacy')); ?>" class="p-1 mcolor text-sm" ><?php echo e(__('general.Privacy')); ?></a>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(route('legal.show','terms')); ?>" class="p-1 mcolor text-sm" ><?php echo e(__('general.Terms')); ?></a>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(route('legal.show','usc18')); ?>" class="p-1 mcolor text-sm" >U.S.C. 18</a>
            </li>
            
        </ul>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/layouts/footers/nav.blade.php ENDPATH**/ ?>