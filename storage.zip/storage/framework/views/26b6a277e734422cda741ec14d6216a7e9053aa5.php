<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div>
        <div class="row">
            <div class="col-12 col-md-10 mx-auto">


                <div class="text-xs px-4 mt-2">



                    <?php if($profile->ReviewRequest() && ($profile->ReviewRequest()->status=='pending' ||
                    $profile->ReviewRequest()->status=='request_again') ): ?>

                    <p class="text-xs p-2 fw-bold bg-purple text-white rounded">
                        <?php echo __('general.Request_review_inprocess'); ?>

                    </p>

                    <?php elseif($profile->ReviewRequest() && $profile->ReviewRequest()->status=='processed' ): ?>
                    <div class=" align-items-center bg-warning p-2 rounded my-2">
                        <p class="my-0"> <i class="fas fa-exclamation-triangle"></i> <?php echo e(__('general.Request_review_response')); ?>


                            <span class="p-2 fw-bold "><?php echo e($profile->ReviewRequest()->message); ?></span>
                        </p>
                    </div>



                    <?php elseif(!$profile->approved && !$profile->ReviewRequest()): ?>

                    <p class="text-xs p-2 fw-bold">
                        <?php echo __('general.Request_review_text'); ?>

                    </p>

                    <?php endif; ?>
                </div>




                <form action="<?php echo e(route('Agency.update', auth()->user()->Agency->id)); ?>" method="post"
                    enctype="multipart/form-data" id="agency-form" class="pt-3 mx-auto ">

                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <!-- LBasic-->
                    <div>
                        <div class="row">
                            <div class="col-12">
                                <h3 class="fs-3 fw-bold text-mgray border-bottom border-mcolor w-100">
                                    <?php echo e(__('forms.profile.Basic')); ?></h3>
                            </div>

                            <div class="col-12 ">
                                <div class="d-flex flex-wrap flex-md-nowrap">

                                    <label for="" class="p-2 d-flex flex-column w-100 ">
                                        <span class="form-label"><?php echo e(__('forms.profile.Name')); ?></span>
                                        <input required name="name" type="text" class="w-100 form-control"
                                            value="<?php echo e($profile->name ? $profile->name : old('name')); ?>" />
                                    </label>
                                    <label for="" class="p-2 d-flex flex-column w-100">
                                        <span class="form-label"><?php echo e(__('forms.profile.Email')); ?></span>
                                        <input required type="text" name="email" class="form-control"
                                            value="<?php echo e($profile->email ? $profile->email : old('email')); ?>" />
                                    </label>
                                </div>
                                <div class="d-flex flex-wrap flex-md-nowrap">
                                    <label for="" class="p-2 d-flex flex-column w-100">
                                        <span class="form-label"><?php echo e(__('forms.profile.Phone')); ?></span>
                                        <input required type="text" name="phone" class="form-control"
                                            value="<?php echo e($profile->phone ? $profile->phone : old('phone')); ?>" />
                                    </label>
                                    <label for="" class="p-2 d-flex flex-column w-100">
                                        <span class="form-label"><?php echo e(__('forms.profile.web')); ?></span>
                                        <input type="text" name="website" class="form-control"
                                            value="<?php echo e($profile->website ? $profile->website : old('website')); ?>" />
                                    </label>
                                </div>
                            </div>

                        </div>

                        <div class="row ">
                            <div class="col-12">

                                <label for="" class="form-label w-100">
                                    <p class="mx-2"><?php echo e(__('forms.profile.Description')); ?></p>
                                    <textarea required required  name="description" id=""
                                        class="w-100 rounded  form-control"><?php echo e($profile->description ? $profile->description : old('description')); ?></textarea>
                                </label>

                            </div>
                            <div class="col-12 py-4">


                                <?php
                                    $photo=$profile->Photo()
                                ?>
                                <?php if($photo): ?>
                                <img src="<?php echo e(asset("/storage/agency_photos/$photo->path/$photo->filename")); ?>" height="100" width="300"  >
                                <hr>

                                <script>
                                    const main_source = "<?php echo e(url("/storage/agency_photos/$photo->path/$photo->filename")); ?>"
                                    </script>
                                <?php else: ?>

                                <script>
                                    const main_source = null
                                </script>

                                <?php endif; ?>
                                <input type="file" name="agency_photo" id="agency_photo"  class=" w-100">


                            </div>

                        </div>
                        <div class="row">
                            <div class="col-12">
                                <!--Direccion -->
                                <h3 class="fs-3 fw-bold text-mgray border-bottom border-mcolor w-100">
                                    <?php echo e(__('forms.profile.Address')); ?></h3>
                            </div>

                            <div class="col-12 ">
                                <div class="d-flex flex-wrap flex-md-nowrap">
                                    <label for="" class="w-100 w-md-25 d-flex flex-column px-2">
                                        <span class="form-label"><?php echo e(__('forms.profile.Country')); ?></span>
                                        <select required  class="js-example-basic-single w-100 " name="country_id"
                                            id="a-country-select">
                                            <?php $countries= DB::table('countries')->get() ?>
                                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($country->id); ?>" <?php echo e(($profile->country_id ?
                                                $profile->country_id : old('country_id')) == $country->id ? 'selected' :
                                                ''); ?>>
                                                <?php echo e(__("geodata.countries.$country->name")); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </label>
                                    <label for="" class="w-100 w-md-25 d-flex flex-column px-2">
                                        <span class="form-label"><?php echo e(__('forms.profile.Region')); ?></span>
                                        <select required  class="js-example-basic-single w-100" name="region_id"
                                            id="a-region-select">

                                            <?php if(isset($profile->region_id)): ?>
                                            <option value="<?php echo e($profile->region_id); ?>" selected>
                                                <?php echo e(DB::table('regions')->where('id', $profile->region_id)->first()->name); ?>

                                            </option>
                                            <?php endif; ?>
                                        </select>
                                    </label>

                                    <label for="" class="w-100 d-flex flex-column px-2">
                                        <span class="form-label"><?php echo e(__('forms.profile.City')); ?></span>
                                        <select required class="js-example-basic-single w-100" name="city_id"
                                            id="a-cities-select">
                                            <?php if(isset($profile->city_id)): ?>
                                            <option value="<?php echo e($profile->city_id); ?>" selected>
                                                <?php echo e(DB::table('cities')->where('id', $profile->city_id)->first()->name); ?>

                                            </option>
                                            <?php endif; ?>
                                        </select>
                                    </label>
                                </div>

                            </div>
                            <div class="col-12 ">
                                <div class="w-100 p-2 my-2">
                                    <label for="" class="w-100">
                                        <span><?php echo e(__('forms.profile.Address')); ?> <span
                                                class="text-red-400">*</span></span>
                                        <input required  type="text" name="address" class="w-100"
                                            value="<?php echo e($profile ? $profile->address : old('address')); ?>" />
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-12">

                                <div class="p-2 text-center py-4 w-100 d-flex">
                                    <input type="submit" name="save"
                                    class=" btn rounded w-100 bg-mcolor text-white px-4 py-2 mx-auto btn-submit" value="<?php echo e(__('general.Save')); ?>">
                                    <?php if(!$profile->ReviewRequest() && $profile->approved == 0 && $profile->can_be_reviewed == 1): ?>
                                    <input type="submit"  name="save_review" class="btn rounded w-100 mcolor bg-white ml-2 px-4 py-2 border-mcolor"  value=" Guardar y <?php echo e(__('general.Request_review_title')); ?>">

                                    <?php elseif($profile->ReviewRequest() && $profile->ReviewRequest()->status=='processed' ): ?>
                                    <input type="submit"  name="save_review" class="btn rounded w-100 mcolor bg-white ml-2 px-4 py-2 border-mcolor"  value=" Guardar y <?php echo e(__('general.Request_review_title')); ?>">

                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                    </div>
            </div>
            <!-- LBasic-->

            </form>
        </div>
    </div>
    </div>

    <?php $__env->startPush('js'); ?>
    <script>

    </script>

<?php $__env->stopPush(); ?>


 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/user/agency/agency-profile-form.blade.php ENDPATH**/ ?>