<div class="container d-flex justify-content-sm-between">

        <div class="copyright text-center text-xl-left">
            <span class="ml-1 text-black">  &copy; <?php echo e(now()->year); ?> - <?php echo e(config('app.name')); ?></span>

        </div>

    <div >
        <ul class="nav nav-footer justify-content-center justify-content-xl-end">
            <li class="nav-item">
                <a href="<?php echo e(route('legal.show','privacy')); ?>" class="p-1 mcolor text-sm" ><?php echo e(__('general.Privacy')); ?></a>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(route('legal.show','terms')); ?>" class="p-1 mcolor text-sm" ><?php echo e(__('general.Terms')); ?></a>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(route('legal.show','usc18')); ?>" class="p-1 mcolor text-sm" >U.S.C. 18</a>
            </li>
            
        </ul>
    </div>
</div>
<?php /**PATH C:\laragon\www\sodoma\resources\views/layouts/footers/nav.blade.php ENDPATH**/ ?>