<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminLayout::class, []); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container pt-5 px-2 mt-5">
        <div class="row">
            <div class="col-12 col-md-10 py-5">
                <table id="notis_table" class="table table-striped ">

                    <thead>
                        <tr>
                            <th>Tipo</th>
                            <th>usuario</th>
                            <th>datos</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $notis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $noti_data=json_encode($noti['data']) ?>
                        <tr>
                            <td scope="row"><?php echo e($noti['created_at']->format('d-m-Y H:i:s')); ?></td>
                            <td> <?php echo e($noti['type']); ?> </td>
                            <td><?php echo e($noti_data); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </tbody>

            </table>
            </div>
        </div>
    </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/admin/notifications/index.blade.php ENDPATH**/ ?>