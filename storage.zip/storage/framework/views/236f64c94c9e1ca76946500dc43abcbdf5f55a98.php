<div class="row align-items-center justify-content-xl-between">
    <div class="col-xl-6">
        <div class="copyright text-center text-xl-left text-muted">
            <span class="ml-1">  &copy; <?php echo e(now()->year); ?> - <?php echo e(config('app.name')); ?></span>

        </div>
    </div>
    
</div>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/layouts/footers/nav.blade.php ENDPATH**/ ?>