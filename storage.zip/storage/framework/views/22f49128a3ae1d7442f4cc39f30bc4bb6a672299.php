<nav class="navbar navbar-expand-lg navbar-light">
    <div class="container">
        <a class="navbar-brand pt-0" href="<?php echo e(route('home')); ?>">
            <img src="<?php echo e(asset('images/escortssecrets-logo.png')); ?>" style="height: 63px" alt="Escorts Secrets Publicidad"/>
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-default" aria-controls="navbar-default" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbar-default">
            <div class="navbar-collapse-header">
                <div class="row">
                    <div class="col-6 collapse-brand">
                        <a href="javascript:void(0)">
                            <img src="<?php echo e(asset('images/escortssecrets-logo.png')); ?>" style="height: 63px" alt="Escorts Secrets Publicidad"/>
                        </a>
                    </div>
                    <div class="col-6 collapse-close">
                        <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbar-default" aria-controls="navbar-default" aria-expanded="false" aria-label="Toggle navigation">
                            <span></span>
                            <span></span>
                        </button>
                    </div>
                </div>
            </div>

            <ul class="navbar-nav ml-lg-auto">
                <li class="nav-item">
                    <a class="nav-link nav-link-icon" href="<?php echo e(route('buy-coins')); ?>" data-title="Comprar Saldo">
                        <i class="fa fa-coins text-xl pr-2"></i>
                        <span class="nav-link-inner--text d-lg-none"> <?php echo e(__('general.Buy_coins_title')); ?></span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link nav-link-icon" href="<?php echo e(route('my-profile')); ?>" data-title="<?php echo e(__('general.Manage_profile')); ?>">
                        <i class="ni ni-image text-xl pr-2"></i>
                        <span class="nav-link-inner--text d-lg-none"> <?php echo e(__('general.Manage_profile')); ?></span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link nav-link-icon" href="<?php echo e(route('my-account')); ?>" data-title="<?php echo e(__('general.My account')); ?>">
                        <i class="ni ni-circle-08 text-xl pr-2"></i>
                        <span class="nav-link-inner--text d-lg-none"> <?php echo e(__('general.My account')); ?></span>
                    </a>
                </li>
                <?php if(auth()->user()->user_type_id ==2): ?>
                <li class="nav-item">
                    <a class="nav-link nav-link-icon" href="<?php echo e(route('my-escorts')); ?>" data-title="<?php echo e(__('general.My_escorts')); ?>">
                        <i class="fa fa-users text-xl pr-2"></i>
                        <span class="nav-link-inner--text d-lg-none"><?php echo e(__('general.My_escorts')); ?></span>
                    </a>
                </li>
                <?php endif; ?>
                <li class="nav-item">
                    <a class="nav-link nav-link-icon" href="<?php echo e(route('my-messages')); ?>" data-title="<?php echo e(__('general.Messages')); ?>">
                        <i class="ni ni-email-83 text-xl pr-2"></i>
                        <span class="nav-link-inner--text d-lg-none"><?php echo e(__('general.Messages')); ?></span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link nav-link-icon" href="<?php echo e(route('contact-us')); ?>" data-title="<?php echo e(__('general.Support')); ?>">
                        <i class="ni ni-support-16 text-xl pr-2"></i>
                        <span class="nav-link-inner--text d-lg-none"><?php echo e(__('general.Support')); ?></span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('logout')); ?>" class="nav-link nav-link-icon" onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();" data-title="<?php echo e(__('general.Logout')); ?>">
                        <i class="ni ni-button-power text-xl pr-2"></i>
                        <span class="nav-link-inner--text d-lg-none"><?php echo e(__('general.Logout')); ?></span>
                    </a>
                </li>
            </ul>

        </div>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/layouts/navbar2.blade.php ENDPATH**/ ?>