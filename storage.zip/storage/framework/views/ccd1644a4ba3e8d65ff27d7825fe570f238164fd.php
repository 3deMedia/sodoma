<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminLayout::class, []); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container pt-5 px-2">
        <h1><?php echo e(request()->routeIs('admin-approved-escorts') ? 'Escorts Aprovadas': 'Escorts sin aprovar'); ?></h1>
        <div class="row">

            <div class="col-12 col-md-10 ">
                <table id="users_table" class="table table-striped ">

                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Fecha creacion</th>
                            <th>Nombre</th>
                            <th>Email</th>
                            <th>Is Vip</th>
                            <th>Activo</th>
                            <th>Agencia</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $escorts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $escort): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($escort->id); ?></td>
                            <td><?php echo e($escort->created_at->format('d-m-Y')); ?></td>
                            <td scope="row"> <?php echo e($escort->name); ?></td>
                            <td> <a href="<?php echo e(route('admin-escort-show',$escort->id)); ?>"><?php echo e($escort->email); ?> </a></td>
                            <td><?php echo e($escort->is_vip ? 'si':'no'); ?></td>
                            <td><?php echo e($escort->active ? 'si':'no'); ?></td>
                            <td>
                                <?php if($escort->Agency): ?>
                                <a href="<?php echo e(route('admin-agency-show',$escort->Agency->id)); ?>"><?php echo e($escort->Agency->name); ?></a>
                                <?php else: ?>
                                No
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </tbody>

            </table>
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/admin/escorts/index.blade.php ENDPATH**/ ?>