<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminLayout::class, []); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container pt-5 px-2">
        <h1><?php echo e(request()->routeIs('admin-approved-agencies') ? 'Agencias Aprovadas': 'Agencias sin aprovar'); ?></h1>
        <h1></h1>
        <div class="row">
            <div class="col-12 col-md-10 ">
                <table id="users_table" class="table table-striped ">

                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Fecha creacion</th>
                            <th>Nombre</th>
                            <th>Email</th>
                            <th>Es Vip?</th>
                            <th>Escorts</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $agencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($agency->id); ?></td>
                            <td><?php echo e($agency->created_at->format('d-m-Y')); ?></td>
                            <td scope="row"> <?php echo e($agency->name); ?></td>
                            <td><a href="<?php echo e(route('admin-agency-show',$agency->id)); ?>"> <?php echo e($agency->email); ?> </a></td>
                            <td><?php echo e($agency->is_vip ? 'si':'no'); ?></td>
                            <td>
                              <?php echo e($agency->Escorts->count()); ?>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

            </table>
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/admin/agencies/index.blade.php ENDPATH**/ ?>