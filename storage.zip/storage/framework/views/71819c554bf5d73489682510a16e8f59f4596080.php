<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GuestLayout::class, []); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startPush('meta'); ?>
    <meta name="description" content="<?php echo e($seo->seo_description); ?>" />
    <meta name="keywords" content="<?php echo e($seo->seo_keywords); ?>" />
    <title><?php echo e($profile->name); ?></title>
<?php $__env->stopPush(); ?>
<?php
$photo=$profile->MainPhoto()
 ?>
    <div class="container pt-5 pt-md-6">
        <div class="col-12">
            <img id="previewer" src=<?php echo e(asset("storage/agency_photos/$photo->path/$photo->filename")); ?> alt="<?php echo e($profile->name); ?>"  class="w-100" />
      </div>
        <div class="row">
            <div class="col-12 fw-bold mt-4">
                <div class="row">
                    <div class="col-12 col-lg-6">

                          <img id="previewer" height="100"
                          src=<?php echo e(asset("storage/agency_photos/$photo->path/$photo->filename")); ?>  alt="<?php echo e($profile->name); ?>" />

                    </div>
                    <div class="col-12 col-lg-6 pt-4 pt-lg-0">
                        <h1><?php echo e($profile->name); ?></h1>
                        <p><a href="tel:<?php echo e($profile->phone); ?>"><i class="fa fa-phone"></i> <?php echo e($profile->phone); ?></a></p>
                        <p><a href="<?php echo e($profile->web); ?>" target="_blank" rel="nofollow noopener noreferer"><?php echo e($profile->web); ?></a></p>
                    </div>
                </div>
                <div class="mt-4">
                <p><?php echo e($profile->description); ?></p>
                </div>
                <div class="col-12 col-lg-4">
                    <h4 class="fs-4 fw-bold mcolor border-bottom border-mcolor w-100 pt-4"><?php echo e(__('general.map')); ?></h4>
                    
                    <?php if (isset($component)) { $__componentOriginalf2f5f86d089043fc8ec39dc6cdcbc9e52d25a543 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MapaEscort::class, ['center' => $center]); ?>
<?php $component->withName('mapa-escort'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf2f5f86d089043fc8ec39dc6cdcbc9e52d25a543)): ?>
<?php $component = $__componentOriginalf2f5f86d089043fc8ec39dc6cdcbc9e52d25a543; ?>
<?php unset($__componentOriginalf2f5f86d089043fc8ec39dc6cdcbc9e52d25a543); ?>
<?php endif; ?>
                </div>

                <?php if($profile->Escorts()->count()>0): ?>
                <div class="row">

                    <h4 class=" mcolor display-4 w-100 border-bottom pt-4 mb-2">Escorts</h4>
                    <div class="col-12 d-flex flex-wrap">
                        <?php $__currentLoopData = $profile->Escorts(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scrt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($scrt->approved && $scrt->active): ?>
                        <p class="profile-name"><?php echo e($scrt->name); ?> </p>
                        <div class="shadow-lg p-2 rounded text-center profile-view">
                            <div>
                                <a href="<?php echo e(route('show-escorts', $scrt->Address->Region->slug,$scrt->uid)); ?>" class="w-100 ">
                                    <div style="width: 100%; position: relative;" <?php if($scrt->is_vip): ?> class="corner" <?php endif; ?>>
                                        <?php
                                            $image=$scrt->Mainphoto()->filename;
                                            $path= $scrt->Mainphoto()->path;
                                        ?>
                                        <img loading="lazy" src='<?php echo e(asset("storage/escort_photos/$path/$image")); ?>'>
                                          <p class="profile-name"><?php echo e($scrt->name); ?> </p>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php else: ?>
                    no tiene escorts
                <?php endif; ?>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\sodoma\resources\views/guest/agency-show.blade.php ENDPATH**/ ?>