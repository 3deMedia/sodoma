<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

<div class="container-fluid" style="min-height: 70vh;">
    <div class="row mb-4">
        <div><h2 class="fw-bold mb-4 text-center"><?php echo e(__('general.yourads')); ?></h2></div>

        <p><?php echo e(__('general.youradstxt')); ?></p>

    </div>
    <ul class="nav nav-tabs" id="myTab" role="tablist" class="w-100">
        <li class="nav-item " role="presentation">
            <button class="nav-link active" id="actived-tab" data-bs-toggle="tab" data-bs-target="#actived"
                type="button" role="tab" aria-controls="actived" >
              <span class="panel-link">  <?php echo e(__('agency.all')); ?></span>
            </button>

        </li>

        <li class="nav-item" role="presentation">
            <button class="nav-link nav-link-new" id="newescort-tab" data-bs-toggle="tab" data-bs-target="#newescort"
                type="button" role="tab" aria-controls="newescort" aria-selected="">
               <span class="panel-link"><?php echo e(__('agency.addEscort')); ?></span>
            </button>

        </li>

    </ul>

    <div class="tab-content w-100 overflow-auto" id="myEscortTabs">
        <div class="tab-pane active" id="actived" role="tabpanel" aria-labelledby="actived-tab">
            <table class="table align-items-center table-flush table-striped">
                <thead class="thead-light">
                    <tr>
                        <th scope="col" class="sort" data-sort="name"></th>
                        <th scope="col" class="sort" data-sort="name"><?php echo e(__('agency.Escort_name')); ?></th>
                        <th scope="col">Estado</th>
                        <th scope="col" class="sort" data-sort="budget"><?php echo e(__('general.Edit')); ?></th>
                        <th scope="col" class="sort" data-sort="status"> <?php echo e(__('general.visible')); ?> </th>
                        <th scope="col"><?php echo e(__('general.agency.create_vip')); ?></th>


                    </tr>
                </thead>
                <tbody class="list">
                    <?php $__currentLoopData = $escorts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act_scrt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <td scope="row">
                            <div class="">
                                <?php
                                $mfoto = $act_scrt->MainPhoto();
                                ?>
                                <?php if($mfoto): ?>
                                <a href="#" class="mavatar mr-3">
                                    <img loading="lazy" style="border-radius:8px"  alt="" src="<?php echo e(asset("storage/escort_photos/$mfoto->path/$mfoto->filename")); ?>">
                                </a>
                                <?php endif; ?>

                            </div>
                        </td>
                        <td>
                            <div class="media-body">
                                <span class="name mb-0 text-sm"><?php echo e($act_scrt->name); ?></span>
                            </div>
                        </td>
                        <td>
                            <div class="media-body">
                                <span class="name mb-0 text-sm">

                                    <?php if(!$act_scrt->approved): ?>
                                    <i class="fa fa-circle text-red"></i> <?php echo e(__('general.notaprove')); ?>


                                    <?php elseif(!$act_scrt->active): ?>
                                        <i class="fa fa-circle text-gray"></i> <?php echo e(__('general.hidden')); ?>

                                    <?php elseif($act_scrt->active): ?>
                                        <i class="fa fa-circle text-green"></i> <?php echo e(__('general.active')); ?>

                                    <?php endif; ?>

                                </span>
                            </div>
                        </td>

                        <td>
                            <button class="btn btn-warning edit-scrt" data-render="<?php echo e($act_scrt->id); ?>">
                                <i class="fas fa-user-edit"></i>
                            </button>
                        </td>
                        <td>
                            <?php if($act_scrt->active): ?>
                            <button class="btn btn-dark hide-prof" data-render="<?php echo e($act_scrt->id); ?>">
                                <i class="fas fa-eye-slash"></i>

                            </button>
                            Ocultar
                            <?php else: ?>
                            <button class="btn btn-success show-prof" data-render="<?php echo e($act_scrt->id); ?>">
                                <i class="fas fa-eye"></i>

                            </button>
                            Mostrar
                            <?php endif; ?>
                        </td>
                        <td>
                           <?php if($act_scrt->approved): ?>
                            <?php if(!$act_scrt->is_vip ): ?>
                            <button class="btn btn-info user-wants-vip text-white"
                                data-render="<?php echo e($act_scrt->id); ?>">
                                <i class="fas fa-gem" aria-hidden="true"></i>
                            </button>
                            <?php else: ?>
                            <p class="p-2"><?php echo e(__('general.vip.ends_at_message')); ?>

                                <?php echo e($act_scrt->Vip()->ends_at->format('d-m-Y')); ?></p>
                            <?php endif; ?>
                            <?php else: ?>
                            <p><?php echo e(__('general.need_profile')); ?></p>
                            <?php endif; ?>
                        </td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>

        <div class="tab-pane fade " id="newescort" role="tabpanel" aria-labelledby="newescort-tab">
            <?php if($can_purchase): ?>

            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.forms.create-escort','data' => ['admin' => false,'agency' => $profile->id]]); ?>
<?php $component->withName('forms.create-escort'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['admin' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false),'agency' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($profile->id)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            <?php else: ?>
            <p class="font-bold text-lg p-2 pt-5">
            <?php echo e(__('general.needs_profile_or_coins')); ?>

            </p>
            <?php endif; ?>

        </div>
    </div>
</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/user/agency/agency-escorts-tabpanel.blade.php ENDPATH**/ ?>