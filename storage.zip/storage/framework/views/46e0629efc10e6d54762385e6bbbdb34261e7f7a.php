<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container pb-5">
        <h2 class="fw-bold mb-4 text-center"><?php echo e(__('general.Buy_coins_title')); ?></h2>
        <div class="col-12 col-md-6 mt-2 mt-md-5 bg-white rounded-md block center px-4 py-4 border-black border-1">
            <h5 class="text-center pt-4 pb-4"><?php echo e(__('general.actuallyhave')); ?><br /><?php echo e(auth()->user()->coins); ?>

                <?php echo e(__('general.coins')); ?> </h5>
            <p class="text-center mb-5"> <?php echo __('general.Coins_explanation'); ?></p>

            <div class="col-12  mx-auto">
                <button " class=" rounded border-purple w-100 my-2 text-center bg-white btn-submit" style="height: 45px"
                    data-toggle="modal" data-target="#modelId"> <?php echo e(__('general.transfers')); ?></button>
                <form action="<?php echo e(route('stripe-checkout')); ?>" method="post" id="stripe-form"
                    class="d-flex flex-wrap flex-lg-nowrap w-full justify-content-between">
                    <?php echo csrf_field(); ?>
                    <div class="d-flex w-100 flex-column text-left py-4">
                        <?php $__currentLoopData = $pay_amounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paya): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label for="">
                                <input type="radio" name="product" class="mx-2  text-mgray" value="<?php echo e($paya->id); ?>"
                                    checked>
                                <span class="text-sm fw-bold"><?php echo e($paya->text); ?></span>
                            </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="w-100 py-4">
                        <button type="submit" class="rounded border-purple w-100 my-2 text-center bg-white btn-submit"
                            style="height: 45px">
                            <img loading="lazy" src="<?php echo e(asset('images/stripe.png')); ?>" alt=""
                                style="height: 40px"></button>
                        <div class="flex-col">

                            <div id="paypal-button-container"></div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Button trigger modal -->
    <!-- Modal -->
    <div class="modal fade" id="modelId" tabindex="-1" role="dialog" aria-labelledby="modelTitleId"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo e(__('general.banktransfer')); ?><</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p><?php echo e(__('general.transfert1')); ?></p>
                    <p><b style="font-weight: 800"><?php echo e(__('general.important')); ?>:</b>  <?php echo e(__('general.howconcept')); ?></p>
                    <p>Concepto: <?php if($profile): ?> <?php echo e($profile->uid); ?> <?php else: ?> Ejemplo:  sara-1234 <?php endif; ?></p>
                    <p><?php echo e(__('general.nrc')); ?></p>
                    <p>ES53 2100 2879 0213 0039 7237</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(__('general.close')); ?></button>
                </div>
            </div>
        </div>
    </div>
    </div>
    <?php $__env->startPush('js'); ?>
        <script
                src="https://www.paypal.com/sdk/js?client-id=AadhVzhHi_EglaHwm1_-DKkYDr-raXI2v127TqX5_ZYeuKMc5EcpN9XBy30vHIea1sKjCbAl2z6BVju5&currency=EUR&components=buttons,funding-eligibility">
        </script>
        <script src="<?php echo e(asset('js/mixin-styles.js')); ?>"></script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\sodoma\resources\views/user/buy-coins.blade.php ENDPATH**/ ?>