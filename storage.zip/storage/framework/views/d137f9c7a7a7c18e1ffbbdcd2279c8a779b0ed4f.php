<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminLayout::class, []); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container pt-5 px-2">
        <div class="row">
            <?php if(session('success')): ?>
                <div class="col-12">
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                </div>

            <?php endif; ?>
            <div class="col-12 col-md-10 ">
                <table id="reviews_table" class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>Fecha</th>
                            <th>Tipo</th>
                            <th>Nombre</th>
                            <th>status</th>
                            <th>Ver</th>
                            <th>Mensaje</th>
                            <th>Aprovar</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $revs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td scope="row"><?php echo e($rev->created_at->format('d-m-Y')); ?></td>
                                <td scope="row"><?php echo e($rev->profile_type == 1 ? 'Escort' : 'Agency'); ?></td>
                                <td>
                                    <a><?php echo e($rev->Profile()->name); ?></a>
                                </td>
                                <td><?php echo e($rev->status); ?></td>
                                <td>
                                    <?php if($rev->profile_type == 1): ?>
                                        <a href="<?php echo e(route('admin-escort-show', $rev->profile_id)); ?>" target="_blank"
                                            class="btn btn-info"><i class="fa fa-eye" aria-hidden="true"></i></a>
                                    <?php elseif($rev->profile_type ==2): ?>
                                        <a href="<?php echo e(route('admin-agency-show', $rev->profile_id)); ?>" target="_blank"
                                            class="btn btn-info"><i class="fa fa-eye" aria-hidden="true"></i></a>
                                    <?php endif; ?>
                                </td>
                                <td><button class="btn btn-warning btn-profile-msg" data-id="<?php echo e($rev->id); ?>">
                                        <i class="fa fa-envelope" aria-hidden="true"></i></button></td>
                                <td><button class="btn btn-success btn-approve-profile" data-id="<?php echo e($rev->profile_id); ?>"
                                        data-type="<?php echo e($rev->profile_type); ?>">
                                        <i class="fa fa-check-circle" aria-hidden="true"></i></button></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>

                <!-- Modal -->

                <div class="modal fade" id="profileModal" tabindex="-1" aria-labelledby="profileModal"
                    aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">

                            <div class="modal-body" id="profileBody">

                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

 <?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/admin/reviews/index.blade.php ENDPATH**/ ?>