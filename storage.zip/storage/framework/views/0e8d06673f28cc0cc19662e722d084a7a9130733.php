<div class="pt-5 pt-md-1">
    <h1 class="text-xl text-center p-4"><?php echo app('translator')->get('general.Contact_us'); ?></h1>
    <?php if(session('success')): ?>
    <div
        class="rounded-lg lg:w-2/6 md:w-1/2 md:ml-auto md:mt-0 px-8 py-2 mx-auto my-2 font-semibold text-white transition duration-500 ease-in-out transform rounded-lg shadow-xl bg-green-400">
        <?php echo session('success'); ?>

    </div>
    <?php endif; ?>


        <form action="<?php echo e(route('contact-us')); ?>" method="post" class="p-4">
            <?php echo csrf_field(); ?>
            <div class="relative p-2 ">
                <input type="text" name="name" style="height: 0;opacity: 0;">
                <input type="name" id="name" name="name2" placeholder=<?php echo app('translator')->get('general.Name'); ?>
                    class="form-control">
            </div>
            <input type="text" name="email" style="height: 0;opacity: 0;">
            <div class="relative p-2 ">
                <input type="name" id="name" name="email2" placeholder=<?php echo app('translator')->get('general.Email'); ?>
                    class="form-control">
            </div>
            <input type="hidden" name="message">
            <div class="relative p-2 ">
                <textarea type="message" id="message" name="message2" class="form-control" placeholder=<?php echo app('translator')->get('general.message'); ?>
                    class="form-control"></textarea>
            </div>

            <div class="mb-4 mt-2">
                <label for="terms">
                    <div class="d-flex align-items-center">
                        <input type="checkbox" name="terms" id="terms" />

                        <div class="ml-2 text-black">
                            <?php echo __('Acepto los :terms_of_service y la Política de :privacy_policy', [
                            'terms_of_service' => '<a target="_blank" href="'.route('legal.show','terms').'"
                                class="underline text-sm text-gray-600 hover:text-gray-900">'.__('general.Terms').'</a>',
                            'privacy_policy' => '<a target="_blank" href="'.route('legal.show','privacy').'"
                                class="underline text-sm text-gray-600 hover:text-gray-900">'.__('general.Privacy').'</a>',
                            ]); ?>

                        </div>
                    </div>
                </label>
            </div>
            <div class="w-100 text-center">
                <button type="submit" id="btn-submit"
                class="btn bg-pink text-white btn-submit"><?php echo app('translator')->get('general.Send'); ?></button>
            </div>


        </form>


</div>
<?php /**PATH C:\xampp\htdocs\sodoma\resources\views/components/contact-us-form.blade.php ENDPATH**/ ?>