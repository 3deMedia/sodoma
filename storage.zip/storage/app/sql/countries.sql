INSERT INTO `countries` (`id`, `name`) VALUES
	(1, 'Spain'),
	(2, 'France'),
	(3, 'England'),
	(4, 'Portugal');
